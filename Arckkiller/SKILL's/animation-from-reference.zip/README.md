# animation-from-reference

Portable skill package. Keep `animation-from-reference` and `shared-animation-kit` as siblings. Read `animation-from-reference/SKILL.md`. All source code, reusable effects and selected visual reviews are included; historical mixed soundtracks and repetitive archival images remain in the [complete GitHub library](https://github.com/lasmidiasplayer20-stack/codex/blob/entrega-animacao-20261014-caf07810/Arckkiller/SKILL%27s/). Run `python3 verify-bundle.py` to verify the archive.
