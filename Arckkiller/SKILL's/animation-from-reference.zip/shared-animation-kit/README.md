# Shared animation kit

This is a source and asset library, not a third active skill. Read the sibling `animation-from-reference/SKILL.md` or `original-stick-animation/SKILL.md` for the chosen workflow.

The kit retains the preserved rig, physics, original/reference production examples, 28 reusable ElevenLabs effects and six Animation vs Physics snapshots. Historical instructions are reference documents. The latest reference example is The Wrong Door R3: faceless body acting, urgent short-step cadence, forward lean, authored 120 Hz planted gait, shared pencil/drawing paths, coherent water depth, original Python music and fresh validation reports. The first traced attempt remains historical evidence and is not the production default.

Full source history is available in the complete ZIP and browsable GitHub folder. Portable ZIPs retain all source code, reusable effects, current reference audio and selected visual reviews; repeated historical mixed soundtracks and large archival contact sheets are omitted from those smaller downloads.
