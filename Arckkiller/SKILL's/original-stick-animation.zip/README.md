# original-stick-animation

Portable skill package. Keep `original-stick-animation` and `shared-animation-kit` as siblings. Read `original-stick-animation/SKILL.md`. All source code, reusable effects and selected visual reviews are included; historical mixed soundtracks and repetitive archival images remain in the [complete GitHub library](https://github.com/lasmidiasplayer20-stack/codex/blob/entrega-animacao-20261014-caf07810/Arckkiller/SKILL%27s/). Run `python3 verify-bundle.py` to verify the archive.
