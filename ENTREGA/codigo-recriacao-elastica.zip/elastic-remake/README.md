# Reconstrução com personagens elásticos

Recriação do MP4 enviado em 14/10/2026: aproximadamente 1min35s, 1920×1080,
60 fps, vários personagens, câmera, armas e efeitos. Motion 14.1.0 é distribuído
localmente. A trilha AAC original é preservada sem recodificação.

## Método

O vídeo original é analisado somente na preparação. O player e o exportador
carregam dados numéricos, Canvas e áudio; não carregam frames, máscaras, contornos
vetorizados, vídeo de fundo ou imagens extraídas da referência.

Os bonecos usam pontos nomeados para cabeça, ombros, quadril, cotovelos, mãos,
joelhos e pés. As articulações são reconstruídas por cinemática direta, com
rotações contínuas e interpolação cúbica limitada. A identidade dos membros é
estabilizada no referencial do tronco. Ossos degenerados são corrigidos por
medidas vizinhas. O filtro local reduz ruído e preserva giros rápidos reais.

Membros mais grossos são desenhados com curvas quadráticas que passam pelas
articulações. Não há cantos angulosos nos cotovelos e joelhos. Contatos com as armas
recebem restrições geométricas quando a captura da mão falha. As armas interpolam
posição, rotação e escala, mantendo seu comprimento durante giros rápidos.

Cabeças vazadas precisam de fechamento adaptativo de falhas de cor e ajuste de
arcos quando os brilhos interrompem o anel. Close-ups com a cabeça fora da câmera
usam controles específicos para os braços visíveis. As cores e os intervalos de
cada personagem seguem a nova referência.

Cenário, cama, acessórios, efeitos e objetos são formas programadas, com dimensões
e transformações medidas. Texturas e peças com detalhes são interpretações em
pixel art geradas pelo código. O aviso de abertura é parte visual da referência.

Esta é uma animação dirigida pela referência, com captura de movimento 2D e
correções; não é uma simulação física autônoma. Poses ocultas ou ambíguas e detalhes
do cenário continuam aproximados. Os testes de posição da cabeça confirmam
alinhamento dos controles, não semelhança perfeita do corpo ou da imagem.

## Usar e exportar

Node 20+, Chromium, FFmpeg e Playwright. No ambiente em nuvem, Chromium está em
`/usr/bin/chromium` e as dependências Node estão instaladas no diretório pai.

```sh
npm ci
node inspect.mjs
node render.mjs --output recriacao-movimento-elastico-1080p60.mp4
python validate-export.py recriacao-movimento-elastico-1080p60.mp4
```

O player pode ser servido por um servidor estático. Reprodução, pausa, busca e
áudio são locais. Nada precisa ser instalado no computador para assistir ao MP4.

## Refazer medições

Use um ambiente Python separado com `requirements.txt` e o MP4 original:

```sh
python capture-scene.py referencia.mp4 --output capture.json
python refine-scene.py referencia.mp4 --capture capture.json --output reviewed.json
python capture-effects.py referencia.mp4 --capture reviewed.json --output effects.json
python prepare-motion.py effects.json --duration 94.598095 --output motion-data.js
```

Os dados prontos da entrega já incluem as revisões. Capturas especializadas podem
ser combinadas com `capture-scene.py --base arquivo.json --only-actor orange`.
Para outra referência, adapte cores, intervalos, câmera, objetos e eventos; os
exemplos desta cena não constituem um detector universal de qualquer vídeo.

`inspect.mjs` verifica todos os rigs a 60 fps, determinismo, personagens presentes,
controles do player e ausência do vídeo original entre os assets. Salva quadros
para comparação visual. `validate-export.py` verifica formato, duração,
decodificação completa e identidade de todos os pacotes AAC do áudio.

O pacote não contém credenciais, sessões de upload nem o arquivo original.
