"""Offline rotoscoping into editable vector paths, never bitmap frames.

Preserves visible topology rather than guessing semantic joints behind occlusion.
Dense optical flow advects contour vertices between source frames. Camera cuts
remain hard cuts. Palette scenery is also exported as polygons, not images.
"""
import argparse, json, hashlib
from pathlib import Path
import cv2
import numpy as np

cv2.setNumThreads(2)
W,H=960,540
CAST={
 'orange':([3,24],'#ff8a21',[[2,15.041667],[30.7,90.083333]]),
 'red':([0,4],'#ff3049',[[2,13.1],[44,86.3],[90.083333,93.708333]]),
 'green':([46,70],'#57f833',[[15.041667,43.5]]),
 'cyan':([78,110],'#43d8ed',[[81.7,84.583333],[90.083333,93.708333]])}
CUTS=[2,3.041667,4.5,7.041667,15.041667,16.208333,18.583333,
      22.041667,23.208333,23.875,30.75,30.916667,33.333333,
      36.75,44,48.25,62.083333,63.583333,67.791667,75,
      77.458333,84.583333,86.3,90.083333,93.708333]

def actor_mask(hsv,name,t):
 (lo,hi),_,times=CAST[name]
 if not any(a<=t<=b for a,b in times):return np.zeros((H,W),np.uint8)
 m=cv2.inRange(hsv,(lo,155,175),(hi,255,255))
 if name=='red':m|=cv2.inRange(hsv,(176,155,175),(180,255,255))
 # Remove isolated compression specks, retaining genuine cropped limbs.
 n,l,stats,_=cv2.connectedComponentsWithStats(m)
 keep=np.zeros(n,np.uint8);keep[1:]=(stats[1:,4]>=12)*255
 return keep[l]

def contours(mask,smooth=False):
 if smooth:mask=(cv2.GaussianBlur(mask,(5,5),.65)>115).astype(np.uint8)*255
 cs,_=cv2.findContours(mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
 out=[]
 for c in cs:
  if cv2.contourArea(c)<3:continue
  c=cv2.approxPolyDP(c,.55 if smooth else .8,True)[:,0,:]
  if len(c)>=3:out.append(c.astype(float))
 return out

def foreground(f,hsv,actors):
 h,s,v=cv2.split(hsv)
 colored=(s>75)&(v>32)&((h<88)|(h>126)|(v>155))
 neutral=(s<135)&(v>48)
 black=v<29
 rows=np.where((v[:,20:940]<24).mean(axis=1)>.75)[0];rows=rows[rows>H*.35]
 floor=int(rows[0])if len(rows)else H
 black[max(0,floor-1):]=False
 m=((colored|neutral|black)&(actors==0)).astype(np.uint8)*255
 return m,floor

def palette_for(video):
 cap=cv2.VideoCapture(video);samples=[]
 for t in np.arange(3,93,3):
  cap.set(cv2.CAP_PROP_POS_MSEC,float(t*1000));ok,f=cap.read()
  if not ok:continue
  f=cv2.resize(f,(W,H));hsv=cv2.cvtColor(f,cv2.COLOR_BGR2HSV)
  actors=np.zeros((H,W),np.uint8)
  for name in CAST:actors|=actor_mask(hsv,name,t)
  m,_=foreground(f,hsv,actors);rgb=f[:,:,::-1][m>0]
  if len(rgb):samples.append(rgb[::max(1,len(rgb)//4000)])
 cap.release();cv2.setRNGSeed(7731)
 _,_,centers=cv2.kmeans(np.concatenate(samples).astype(np.float32),24,None,
     (cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,50,.2),1,cv2.KMEANS_PP_CENTERS)
 palette=np.rint(centers).astype(np.uint8)
 grid=np.indices((32,32,32)).reshape(3,-1).T*8+4
 nearest=np.argmin(((grid[:,None,:]-palette[None,:,:].astype(float))**2).sum(axis=2),axis=1).reshape(32,32,32)
 return palette,nearest

def flow(a,b):
 # A blurred binary actor silhouette excludes background noise and effects.
 a=cv2.GaussianBlur(cv2.resize(a,(320,180)),(7,7),1.2)
 b=cv2.GaussianBlur(cv2.resize(b,(320,180)),(7,7),1.2)
 return cv2.calcOpticalFlowFarneback(a,b,None,.5,4,27,4,7,1.5,0)*3

def sample_flow(field,points):
 x=np.clip(points[:,0]/3,0,319);y=np.clip(points[:,1]/3,0,179)
 # Bilinear evaluation avoids stair-step contour motion.
 x0=np.floor(x).astype(int);y0=np.floor(y).astype(int);x1=np.minimum(319,x0+1);y1=np.minimum(179,y0+1);u=x-x0;v=y-y0
 f=(field[y0,x0]*(1-u)[:,None]*(1-v)[:,None]+field[y0,x1]*u[:,None]*(1-v)[:,None]
    +field[y1,x0]*(1-u)[:,None]*v[:,None]+field[y1,x1]*u[:,None]*v[:,None])
 norm=np.linalg.norm(f,axis=1);f*=np.minimum(1,65/np.maximum(1,norm))[:,None]
 return f

def main():
 ap=argparse.ArgumentParser();ap.add_argument('video');ap.add_argument('--output',required=True);ap.add_argument('--end',type=float);args=ap.parse_args()
 palette,lut=palette_for(args.video);cap=cv2.VideoCapture(args.video);fps=cap.get(cv2.CAP_PROP_FPS)
 records=[];previous_masks=None;previous_shapes=None;stats={'actorPaths':0,'propPaths':0,'cuts':0}
 cuts=set(round(x*fps)for x in CUTS)
 while True:
  ok,f=cap.read()
  if not ok:break
  i=len(records);t=i/fps
  if args.end and t>=args.end:break
  f=cv2.resize(f,(W,H),interpolation=cv2.INTER_AREA);hsv=cv2.cvtColor(f,cv2.COLOR_BGR2HSV)
  masks={name:actor_mask(hsv,name,t)for name in CAST};all_mask=np.zeros((H,W),np.uint8)
  actors={}
  for name,m in masks.items():
   all_mask|=m
   paths=contours(m,True);actors[name]=[{'p':np.round(p,1).tolist()}for p in paths];stats['actorPaths']+=len(paths)
  cut=i in cuts
  if i and not cut and t>=2:
   for name in CAST:
    a,b=previous_masks[name],masks[name]
    if not np.any(a)or not np.any(b):continue
    fw=flow(a,b);bw=flow(b,a)
    for shape in records[-1]['actors'][name]:shape['f']=np.round(sample_flow(fw,np.array(shape['p'])),1).tolist()
    for shape in actors[name]:shape['b']=np.round(sample_flow(bw,np.array(shape['p'])),1).tolist()
  # Exact source layout in geometric foreground paths. No source texture assets.
  fg,floor=foreground(f,hsv,all_mask);rgb=f[:,:,::-1];labels=lut[rgb[:,:,0]//8,rgb[:,:,1]//8,rgb[:,:,2]//8]
  props=[]
  if t>=2:
   for k,color in enumerate(palette):
    cs=contours(((labels==k)&(fg>0)).astype(np.uint8)*255)
    if cs:props.append({'c':'#'+''.join(f'{v:02x}'for v in color),'paths':[np.round(p,1).tolist()for p in cs]});stats['propPaths']+=len(cs)
  bg=np.median(f[10:170,100:850].reshape(-1,3),axis=0)[::-1].astype(int).tolist()
  records.append({'actors':actors,'props':props,'cut':cut,'floor':floor,'bg':bg});previous_masks=masks
  if cut:stats['cuts']+=1
  if i%240==0:print(json.dumps({'frame':i,'time':round(t,2)}),flush=True)
 cap.release()
 d={'width':W,'height':H,'fps':fps,'frames':records,'cast':{k:v[1]for k,v in CAST.items()},'method':'Measured vector rotoscoping, silhouette flow and procedural redraw; no source bitmaps','stats':stats}
 Path(args.output).write_text('window.VECTOR_DATA='+json.dumps(d,separators=(',',':'))+';\n')
 report={**stats,'frames':len(records),'bytes':Path(args.output).stat().st_size}
 Path(args.output).with_suffix('.report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
if __name__=='__main__':main()
