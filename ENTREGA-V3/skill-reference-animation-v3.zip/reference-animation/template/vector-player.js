/* Editable measured silhouettes, drawn solely with Canvas paths.
   No video, frame image, bitmap mask, generic walking cycle or invented bones. */
(()=>{'use strict';
 const D=VECTOR_DATA,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function sample(t){const x=clamp(t*D.fps,0,D.frames.length-1),i=Math.floor(x),a=D.frames[i],b=D.frames[Math.min(i+1,D.frames.length-1)],u=x-i;
  // A source cut never gets a crossfade or an interpolated camera scale.
  if(b.cut)return {row:a,u:0,direction:null,index:i,floor:a.floor};
  return {row:u<=.5?a:b,u:u<=.5?u:1-u,direction:u<=.5?'f':'b',index:u<=.5?i:Math.min(i+1,D.frames.length-1),floor:a.floor+(b.floor-a.floor)*u};}
 function closed(ctx,points,flow,u,soft){
  const p=points.map((p,i)=>[p[0]+(flow?.[i]?.[0]||0)*u,p[1]+(flow?.[i]?.[1]||0)*u]);
  if(!soft){ctx.moveTo(...p[0]);for(let i=1;i<p.length;i++)ctx.lineTo(...p[i]);ctx.closePath();return;}
  const n=p.length,mid=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];ctx.moveTo(...mid(p[n-1],p[0]));
  for(let i=0;i<n;i++)ctx.quadraticCurveTo(...p[i],...mid(p[i],p[(i+1)%n]));ctx.closePath();
 }
 function actors(ctx,t){const s=sample(t);for(const name of ['green','orange','red','cyan']){
  const shapes=s.row.actors[name];if(!shapes?.length)continue;ctx.save();ctx.beginPath();
  for(const shape of shapes)closed(ctx,shape.p,shape[s.direction],s.u,true);
  ctx.fillStyle=D.cast[name];ctx.fill('evenodd');
  // Modest round expansion changes styling without changing limb lengths.
  ctx.lineJoin=ctx.lineCap='round';ctx.lineWidth=name==='orange'?2.5:1.7;ctx.strokeStyle=D.cast[name];ctx.stroke();ctx.restore();
 }}
 function propFlow(field,point){
  if(!field)return [0,0];const x=clamp(point[0]/30-.5,0,31),y=clamp(point[1]/30-.5,0,17),x0=Math.floor(x),y0=Math.floor(y),x1=Math.min(31,x0+1),y1=Math.min(17,y0+1),u=x-x0,v=y-y0;
  return [0,1].map(k=>field[y0*32+x0][k]*(1-u)*(1-v)+field[y0*32+x1][k]*u*(1-v)+field[y1*32+x0][k]*(1-u)*v+field[y1*32+x1][k]*u*v);
 }
 function props(ctx,t){const s=sample(t),field=PROP_FLOW.frames[s.index]?.[s.direction];for(const group of s.row.props){ctx.beginPath();for(const p of group.paths)closed(ctx,p,field?p.map(point=>propFlow(field,point)):null,s.u,false);ctx.fillStyle=group.c;ctx.fill('evenodd');}}
 window.VectorPlayer={sample,actors,props,closed};
})();
