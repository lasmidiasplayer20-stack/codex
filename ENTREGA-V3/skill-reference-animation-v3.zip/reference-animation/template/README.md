# Template de rotoscopia vetorial

Este player tem dados sintéticos pequenos e não contém o vídeo, áudio ou contornos
da referência do exemplo real. Sirva a pasta por HTTP para abrir `index.html`.
Para adaptar, capture `vector-data.js` e `prop-flow.js`, defina `scene-data.js`,
adapte presença/cortes/paleta dos scripts, extraia o áudio autorizado e configure
`src="soundtrack.m4a"` no elemento de áudio. Consulte `../references/workflow.md`.
