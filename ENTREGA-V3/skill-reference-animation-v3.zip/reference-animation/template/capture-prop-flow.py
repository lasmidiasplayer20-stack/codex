"""Compact displacement grids for geometric props; no raster frame assets."""
import argparse,json,importlib.util
from pathlib import Path
import cv2,numpy as np
spec=importlib.util.spec_from_file_location('vector',Path(__file__).with_name('capture-vector.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def compact(f):
 return np.round(cv2.resize(f,(32,18),interpolation=cv2.INTER_AREA),1).reshape(-1,2).tolist()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('video');ap.add_argument('--output',required=True);a=ap.parse_args();cap=cv2.VideoCapture(a.video);fps=cap.get(cv2.CAP_PROP_FPS);cuts=set(round(t*fps)for t in m.CUTS);rows=[];prev=None
 while True:
  ok,f=cap.read()
  if not ok:break
  i=len(rows);f=cv2.resize(f,(320,180),interpolation=cv2.INTER_AREA);gray=cv2.cvtColor(f,cv2.COLOR_BGR2GRAY);rows.append({})
  if prev is not None and i not in cuts and i/fps>=2:
   fw=cv2.calcOpticalFlowFarneback(prev,gray,None,.5,4,27,4,7,1.5,0)*3
   bw=cv2.calcOpticalFlowFarneback(gray,prev,None,.5,4,27,4,7,1.5,0)*3
   for field in [fw,bw]:
    norm=np.linalg.norm(field,axis=2);field*=np.minimum(1,65/np.maximum(1,norm))[:,:,None]
   rows[-2]['f']=compact(fw);rows[-1]['b']=compact(bw)
  prev=gray
  if i%480==0:print(json.dumps({'flowFrame':i}),flush=True)
 cap.release();p=Path(a.output);p.write_text('window.PROP_FLOW='+json.dumps({'width':32,'height':18,'frames':rows},separators=(',',':'))+';\n');print(json.dumps({'frames':len(rows),'bytes':p.stat().st_size}))
if __name__=='__main__':main()
