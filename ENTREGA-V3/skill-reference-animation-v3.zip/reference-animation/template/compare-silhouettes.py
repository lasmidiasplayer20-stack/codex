"""Image-space QA against reference: precision/recall, not self-fit rig tests."""
import argparse,json,importlib.util
from pathlib import Path
import cv2,numpy as np
spec=importlib.util.spec_from_file_location('capture',Path(__file__).with_name('capture-vector.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('reference');ap.add_argument('validation');ap.add_argument('--baseline');ap.add_argument('--output',required=True);a=ap.parse_args();cap=cv2.VideoCapture(a.reference);baseline=cv2.VideoCapture(a.baseline)if a.baseline else None;rows=[]
 for path in sorted(Path(a.validation).glob('frame-*.png')):
  t=float(path.stem[6:])
  if not 2<=t<=93.5:continue
  cap.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,src=cap.read()
  if not ok:continue
  src=cv2.resize(src,(m.W,m.H),interpolation=cv2.INTER_AREA);dst=cv2.resize(cv2.imread(str(path)),(m.W,m.H),interpolation=cv2.INTER_AREA);hsv=cv2.cvtColor(src,cv2.COLOR_BGR2HSV);out=cv2.cvtColor(dst,cv2.COLOR_BGR2HSV)
  old=None
  if baseline:
   baseline.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,v=baseline.read()
   if ok:old=cv2.cvtColor(cv2.resize(v,(m.W,m.H),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2HSV)
  for name in m.CAST:
   s=m.actor_mask(hsv,name,t)>0
   if s.sum()<80:continue
   d=m.actor_mask(out,name,t)>0;inter=(s&d).sum();union=(s|d).sum();row={'t':t,'actor':name,'iou':round(float(inter/max(1,union)),4),'referencePixels':int(s.sum()),'outputPixels':int(d.sum())}
   # Two-pixel tolerance accommodates rounded thickness and temporal subframes.
   dil=cv2.dilate(s.astype(np.uint8),np.ones((5,5),np.uint8))>0;near=cv2.dilate(d.astype(np.uint8),np.ones((5,5),np.uint8))>0
   row['recallWithin2px']=round(float((s&near).sum()/max(1,s.sum())),4);row['precisionWithin2px']=round(float((d&dil).sum()/max(1,d.sum())),4)
   if old is not None:
    b=m.actor_mask(old,name,t)>0;row['v2IoU']=round(float((s&b).sum()/max(1,(s|b).sum())),4)
   rows.append(row)
 assert rows,'No comparison samples ran'
 # Missing final actors or large invented/off-camera bodies would fail here.
 for row in rows:
  assert row['recallWithin2px']>.65,repr(row)
  assert row['precisionWithin2px']>.65,repr(row)
 result={'samples':len(rows),'meanIoU':round(float(np.mean([r['iou']for r in rows])),4),'meanV2IoU':round(float(np.mean([r['v2IoU']for r in rows if'v2IoU'in r])),4),'comparisons':rows,'passed':True,'scope':'Sampled visible color silhouettes; checks projection and presence, not independent physics or hidden anatomy.'}
 Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='comparisons'}))
if __name__=='__main__':main()
