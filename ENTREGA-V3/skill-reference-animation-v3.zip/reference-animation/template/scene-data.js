window.FILM_DATA={"width": 960, "height": 540, "duration": 4, "scenes": [{"t": 0, "floor": 440, "color": [6, 52, 75]}, {"t": 4, "floor": 440, "color": [6, 52, 75]}]};
