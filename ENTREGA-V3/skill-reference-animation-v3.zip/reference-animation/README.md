# Skill reference-animation V3

`SKILL.md` descreve duas opções: rigs anotados para animação independente e
rotoscopia vetorial para reconstrução fiel de animação 2D. O template executável
é pequeno e sintético; não inclui os dados nem a trilha do vídeo real.

Em um novo chat, anexe o ZIP (ou `SKILL.md`) e a referência e peça para seguir as
instruções. Isso permite leitura das instruções, mas não registra automaticamente
uma skill persistente no aplicativo. Instalação persistente depende do suporte
do aplicativo utilizado. A skill não concede autorização de publicação.
