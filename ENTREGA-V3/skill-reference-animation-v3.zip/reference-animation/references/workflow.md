# Fluxo vetorial

O exemplo pressupõe animação 2D com cores separáveis. Examine a referência e adapte
`CAST` e `CUTS` de `capture-vector.py`; o script de fluxo importa essas mesmas
configurações. Os intervalos são exemplos, não uma detecção universal.

1. FFprobe e análise visual densa de cortes/rápidos/final.
2. `python3 capture-vector.py referencia.mp4 --output vector-data.js`.
3. `python3 capture-prop-flow.py referencia.mp4 --output prop-flow.js`.
4. Gere os parâmetros do fundo (`scene-data.js`) e extraia a trilha autorizada:
   `ffmpeg -i referencia.mp4 -vn -c:a copy soundtrack.m4a`.
5. `node inspect-vector.mjs validation-vector`.
6. Renderize clipes representativos antes de exportar tudo:
   `node render.mjs --start 9.3 --duration 3.4 --silent true --output previa.mp4`.
7. Compare anatomia visível e contatos com a referência; corrija a captura.
8. `node render.mjs --output final.mp4`.
9. `python3 validate-export.py final.mp4`.

O template demonstra o player com dados sintéticos pequenos e áudio opcional.
Os testes de presença/cortes são específicos da referência: adapte expectativas
quando trocar de vídeo, mantendo verificações relevantes. Os arquivos de frames
para diagnóstico ficam fora do renderer. Pureza do código e qualidade visual são
verificações diferentes; ambas precisam de evidência.
