import {chromium} from '@playwright/test';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,resolve,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {once} from 'node:events';
import assert from 'node:assert/strict';
const root=dirname(fileURLToPath(import.meta.url)),out=resolve(process.argv[2]||resolve(root,'validation-vector'));
await mkdir(out,{recursive:true});
const server=createServer(async(req,res)=>{try{const p=resolve(root,'.'+(req.url==='/'?'/index.html':req.url));if(!p.startsWith(root+'/'))throw Error();res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.m4a':'audio/mp4'})[extname(p)]||'application/octet-stream');res.end(await readFile(p));}catch{res.writeHead(404);res.end();}});
server.listen(0,'127.0.0.1');await once(server,'listening');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
try{
 const page=await browser.newPage(),errors=[],requests=[];page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>requests.push(r.url()));
 await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>Boolean(window.film));
 const times=[.5,2,3,5,7.5,9.4,10.5,11.9,12.5,15.1,17.7,20,22.05,23,25,31,34,38.75,41.5,42,45,50,55,59,62.2,65,67.8,69,72,75.1,76,77.5,79,82,84,84.6,87,89,90.1,92,93,94.5];
 const report=await page.evaluate(times=>{
  let vertices=0,finite=true,maxWarp=0,cutChecks=0;
  for(let i=0;i<VECTOR_DATA.frames.length;i++){
   const row=VECTOR_DATA.frames[i];
   for(const paths of Object.values(row.actors))for(const shape of paths){
    for(const p of shape.p){vertices++;finite&&=p.every(Number.isFinite);}
    for(const field of ['f','b'])if(shape[field])for(const v of shape[field]){finite&&=v.every(Number.isFinite);maxWarp=Math.max(maxWarp,Math.hypot(...v));}
   }
   if(row.cut&&i){const s=VectorPlayer.sample((i-.01)/VECTOR_DATA.fps);if(s.index!==i-1||s.direction!==null)throw Error('A camera cut was interpolated');cutChecks++;}
  }
  const deterministic=times.every(t=>{film.draw(t);const a=film.canvas.toDataURL();film.draw(t+.03);film.draw(t);return a===film.canvas.toDataURL();});
  return {finite,vertices,maxWarp,cutChecks,deterministic,frames:VECTOR_DATA.frames.length,method:VECTOR_DATA.method,metrics:film.metrics};
 },times);
 assert(report.finite&&report.deterministic);assert(report.maxWarp<65.2);assert(report.cutChecks>=25);
 for(const t of times){const data=await page.evaluate(t=>{film.draw(t);return film.canvas.toDataURL('image/png').split(',')[1];},t);await writeFile(resolve(out,`frame-${t}.png`),Buffer.from(data,'base64'));}
 await page.locator('#seek').fill('25');assert.equal(await page.locator('#seek').inputValue(),'25');await page.locator('#play').click();await page.waitForTimeout(200);assert.equal(await page.locator('#play').textContent(),'Pausar');await page.locator('#play').click();assert.equal(await page.locator('#play').textContent(),'Reproduzir');
 assert.equal(errors.length,0);assert(requests.every(r=>new URL(r).hostname==='127.0.0.1'));assert(requests.every(r=>!r.endsWith('.mp4')&&!/\.(png|jpg|webp)/.test(r)));
 report.playerControlsVerified=true;report.errors=errors;report.assetRequests=requests.map(r=>new URL(r).pathname);
 await writeFile(resolve(out,'player-validation.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await browser.close();await new Promise(r=>server.close(r));}
