# Recriação V3 — contornos animados

Esta revisão substitui a inferência de ossos por rotoscopia vetorial automática.
A referência é analisada offline para extrair contornos de personagens e objetos.
O player desenha esses caminhos com Canvas e os desloca entre quadros usando
fluxo óptico. Ele não carrega o MP4 original, frames, imagens ou máscaras raster.
O projeto contém as formas vetoriais medidas; isso **não** é coreografia manual
nova nem uma simulação física autônoma. Motion 14.1.0 controla as funções de easing
usadas pela apresentação e pelo fundo. O áudio original permanece intacto.

O método evita trocar braço por perna e completar um corpo inexistente quando só
uma mão está visível. Preserva poses, enquadramento, objetos, golpes e oclusões.
Contornos arredondados, leve aumento de espessura e uma nova paleta mudam o estilo
sem impor comprimentos errados aos membros. O cenário azul é gerado por código.
Os objetos de primeiro plano são polígonos de uma paleta reduzida de 24 cores.

## Abrir e exportar

O player não precisa de instalação. Sirva esta pasta com um servidor HTTP, por
exemplo `python3 -m http.server 8000`, e abra a página no navegador. Para renderizar:
instale Node, FFmpeg e Chromium, execute `npm ci`, e rode:

```
node inspect-vector.mjs validation-vector
node render.mjs --output recriacao-elastica-refinada-v3-1080p60.mp4
python3 validate-export.py recriacao-elastica-refinada-v3-1080p60.mp4
```

Os scripts de browser usam `/usr/bin/chromium`. Adapte esse caminho para seu
ambiente. Não é preciso executar nada no computador de trabalho para assistir
ao MP4 entregue. O projeto foi desenvolvido e exportado na máquina em nuvem.

## Regenerar os contornos

Com o vídeo de referência disponível e as dependências de `requirements.txt`:

```
python3 capture-vector.py referencia.mp4 --output vector-data.js
```

Adapte os intervalos, a paleta, os cortes em `capture-vector.py` e os dados de
cenário em `scene-data.js` ao trabalhar com outra referência. O detector depende
de figuras 2D com cores separáveis; não é uma solução universal para qualquer
vídeo. Para imagens complexas, prefira pontos/curvas anotados manualmente.

## Revisão

Compare os trechos rápidos e as oclusões com o original. `inspect-vector.mjs`
confere os dados geométricos, cortes, determinismo e controles. A fidelidade é
avaliada comparando silhuetas e prévias codificadas; comprimentos de ossos
constantes, sozinhos, não provam qualidade de animação. A exportação é validada
por decodificação integral, duração e igualdade de todos os pacotes AAC.

Limites: contornos derivados da compressão podem reter pequenos defeitos. Fluxo
óptico entre quadros rápidos pode produzir leves mudanças de borda. Formas ocultas
não são reconstruídas em 3D; a cena conserva a projeção visível da referência.
