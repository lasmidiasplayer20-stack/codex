"""Named pose annotations for cropped holds and the prone recovery passage.

The original graph cannot classify two feet when only a torso or overlapping
legs are visible. These reference-specific annotations resolve that ambiguity.
Head positions, timing and camera scale still come from the measured source.
"""
import argparse,copy,json
from pathlib import Path

def main():
 ap=argparse.ArgumentParser();ap.add_argument('capture');ap.add_argument('--profile-data',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 d=json.loads(Path(a.capture).read_text());text=Path(a.profile_data).read_text();profiles=json.loads(text[len('window.FILM_DATA='):-2]if text.startswith('window.FILM_DATA=')else text)['morphologyProfiles'];d['morphologyCalibration']=profiles;counts={'closeStanding':0,'closeHeadHold':0,'prone':0}
 profile=profiles['orange'];torso,neck,leg=profile[1],profile[2],profile[7]+profile[8];prone_start=None
 for p in d['tracks']['orange']:
  if p.get('partial'):continue
  t=p['t'];hx,hy=p['head'];r=p['r'];point=lambda x,y:[hx+x*r,hy+y*r]
  if 4.5-1e-6<=t<7.041667-1e-6:
   p['shoulder']=point(-.75,1.18);p['hip']=point(-.82,3.25)
   p['arms']=[[point(-1.27,2.19),point(-1.56,3.1)],[point(-.31,2.18),point(-.08,3.29)]]
   p['legs']=[[point(-1.1,4.9),point(-1.25,6.6)],[point(-.40,4.9),point(-.25,6.6)]]
   p['quality']=.9;counts['closeStanding']+=1
  elif 33.333333-1e-6<=t<36.75-1e-6:
   p['shoulder']=point(1.2,.65);p['hip']=point(2.2,3.2)
   p['arms']=[[point(.45,.95),point(.48,1.95)],[point(2.0,-.50),point(2.75,.78)]]
   p['legs']=[[point(1.75,4.8),point(1.5,6.5)],[point(2.7,4.8),point(3.0,6.5)]]
   p['quality']=.9;counts['closeHeadHold']+=1
  elif 60<=t<77.458333-1e-6:
   floor=min(d['scenes'],key=lambda s:abs(s['t']-t))['floor']
   if hy<floor-r*.8:continue
   old=copy.deepcopy(p)
   if prone_start is None:prone_start=t
   p['shoulder']=point(-neck,-.12);p['hip']=point(-neck-torso,-.15)
   p['arms']=[[point(-.6,-.75),point(.1,-.7)],[point(-1.0,.75),point(.4,1.0)]]
   p['legs']=[[point(-neck-torso-leg*.48,-.25),point(-neck-torso-leg,-.30)],[point(-neck-torso-leg*.48,.08),point(-neck-torso-leg,.12)]]
   p['quality']=.9;counts['prone']+=1
   weight=min(1,max(0,(t-prone_start)/.15));weight=weight*weight*(3-2*weight)
   if weight<1:
    for key in ['shoulder','hip']:p[key]=[a+(b-a)*weight for a,b in zip(old[key],p[key])]
    for key in ['arms','legs']:p[key]=[[[a+(b-a)*weight for a,b in zip(old_point,new_point)]for old_point,new_point in zip(old_limb,new_limb)]for old_limb,new_limb in zip(old[key],p[key])]
 d['poseAnnotations']=counts;Path(a.output).write_text(json.dumps(d,separators=(',',':')));print(json.dumps(counts))

if __name__=='__main__':main()
