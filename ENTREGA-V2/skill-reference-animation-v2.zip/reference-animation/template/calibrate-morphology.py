"""Calibrate the reference's anatomy from clear neutral standing observations."""
import argparse,importlib.util,json
from pathlib import Path
import numpy as np
spec=importlib.util.spec_from_file_location('prepare',Path(__file__).with_name('prepare-motion.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
NEUTRAL={'orange':[7.5,8.5,30.916667,48.583333], 'red':[7.5,8.5,9.0,52.0,54.0], 'green':[30.916667,31.5,36.75,38.0], 'cyan':[83.4,83.9,84.4]}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('capture');ap.add_argument('--output',required=True);a=ap.parse_args();d=json.loads(Path(a.capture).read_text());profiles={};report={}
 for name,values in d['tracks'].items():
  base=m.morphology(values);observations=[]
  for t in NEUTRAL[name]:
   p=min(values,key=lambda p:abs(p['t']-t))
   if p.get('partial')or abs(p['t']-t)>.07 or p['quality']<.8:continue
   leg_lengths=[(np.linalg.norm(np.array(knee)-p['hip'])+np.linalg.norm(np.array(foot)-knee))/p['r']for knee,foot in p['legs']]
   height=(max(foot[1]for _,foot in p['legs'])-p['head'][1])/p['r']
   if 5<height<10:observations.append({'t':p['t'],'height':float(height),'legs':[float(x)for x in leg_lengths]})
  if len(observations)<2:raise ValueError('Need at least two visually verified neutral poses for '+name)
  leg=float(np.clip(np.median([v for o in observations for v in o['legs']]),2.4,4.2));height=float(np.median([o['height']for o in observations]));torso=float(np.clip(height-base[2]-leg*.94,1.6,3.4))
  base[1]=round(torso,5)
  for j in [7,9]:base[j]=round(leg*.48,5);base[j+1]=round(leg*.52,5)
  profiles[name]=base;report[name]={'neutralObservations':observations,'profile':base}
 result={'morphologyProfiles':profiles,'calibration':report};Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':main()
