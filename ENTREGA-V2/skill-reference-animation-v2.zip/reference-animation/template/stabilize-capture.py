"""Re-measure heads with calibrated shot scales and reject cropped false heads.

These shot calibrations belong to this reference. Adapt them for another film.
Only named body joints and partial limb controls are exported, never pixels.
"""
import argparse, copy, hashlib, heapq, importlib.util, json, math
from pathlib import Path
import cv2
import numpy as np

spec=importlib.util.spec_from_file_location('capture',Path(__file__).with_name('capture-scene.py'))
capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
W,H=960,540
# Real camera changes, not the spurious scale changes from the old detector.
SHOTS={
 'orange':[(2.625,4.5,31.8),(4.5,7.041667,88.5),(7.041667,16.2,31.8),
           (30.916667,33.333333,39.8),(33.333333,36.75,107.1),(36.75,44,35.5),
           (48.25,62.083333,35.5),(62.083333,63.583333,89.8),
           (63.583333,67.791667,35.5),(67.791667,75,62.1),(75,81.6,74)],
 'red':[(2.625,3.041667,26.6),(3.041667,7.041667,77.9),(7.041667,13.1,26.6),
        (44,48.25,67.3),(48.25,62.083333,30.6),(62.083333,63.583333,77.4),
        (63.583333,67.791667,30.6),(67.791667,77.458333,53.5),
        (77.458333,84.75,52),(84.75,86.3,110)],
 'green':[(16.208333,18.583333,56.7),(18.583333,22.041667,58.5),
          (22.041667,23.875,149),(23.875,30.75,58.5),(30.75,36.75,35.2),
          (36.75,41.95,35.2)],
 'cyan':[(81.75,84.75,50.5)],
}
CACHE={}

def calibrated(name,t):
 for i,(lo,hi,r) in enumerate(SHOTS[name]):
  if lo-1e-6<=t<hi-1e-6:return i,r
 return None,None

def circle_score(mask,center,r,hollow):
 angles=np.linspace(0,2*np.pi,48,endpoint=False);cx,cy=center
 # Hollow outlines sit around r; filled heads change color at the boundary.
 rings=np.linspace(.84,1.16,9) if hollow else np.linspace(.85,1.13,9)
 xx=np.rint(cx+np.cos(angles)[:,None]*r*rings).astype(int)
 yy=np.rint(cy+np.sin(angles)[:,None]*r*rings).astype(int)
 valid=(xx>=0)&(xx<W)&(yy>=0)&(yy<H);inside=mask[np.clip(yy,0,H-1),np.clip(xx,0,W-1)]>0
 visible=valid.any(axis=1)
 if visible.sum()<14:return -1
 if hollow:support=(inside&valid).any(axis=1)
 else:
  # A head has color on its inner boundary and darkness on its outer boundary.
  support=(inside[:,:4]&valid[:,:4]).any(axis=1)&(~inside[:,5:]&valid[:,5:]).any(axis=1)
 coverage=float(support[visible].mean())
 ix=np.rint(cx+np.cos(angles)*r*.42).astype(int);iy=np.rint(cy+np.sin(angles)*r*.42).astype(int)
 iv=(ix>=0)&(ix<W)&(iy>=0)&(iy<H)
 fill=float((mask[np.clip(iy,0,H-1),np.clip(ix,0,W-1)]>0)[iv].mean())if iv.any()else .5
 if coverage<(.40 if hollow else .32) or (hollow and fill>.38) or (not hollow and fill<.36):return -1
 return coverage+.22*(1-fill if hollow else fill)

def head(mask,r,hollow,old=None,previous=None):
 key=(round(r,2),hollow,hashlib.blake2b(mask.tobytes(),digest_size=12).digest())
 if key in CACHE:return copy.deepcopy(CACHE[key])
 small=cv2.resize(mask,(480,270),interpolation=cv2.INTER_AREA)
 circles=cv2.HoughCircles(cv2.GaussianBlur(small,(5,5),1),cv2.HOUGH_GRADIENT,1,10,
                         param1=65,param2=11,minRadius=max(3,round(r*.36)),maxRadius=round(r*.66))
 candidates=[]
 if old:candidates.append(old['head'])
 if circles is not None:candidates.extend([[float(x*2),float(y*2)]for x,y,_ in circles[0]])
 if not hollow:
  # A held weapon can hide most of a filled head. Fit the surviving external
  # circular arc of a substantial color component instead of deleting the body.
  count,labels,stats,_=cv2.connectedComponentsWithStats(mask)
  for label,(x,y,w,h,area)in enumerate(stats[1:],1):
   if area<r*r*.2:continue
   part=labels==label
   for side in (-1,1):
    points=[]
    for yy in range(y,min(H,y+round(r*1.8))):
     xs=np.where(part[yy])[0]
     if len(xs):points.append([float(xs[0]if side<0 else xs[-1]),float(yy)])
    if len(points)<15:continue
    pts=np.array(points);xx,yy=pts.T;cx,cy,k=np.linalg.lstsq(np.column_stack([2*xx,2*yy,np.ones(len(xx))]),xx*xx+yy*yy,rcond=None)[0]
    fitted=math.sqrt(max(1,k+cx*cx+cy*cy));residual=np.median(abs(np.hypot(xx-cx,yy-cy)-fitted))
    if r*.72<fitted<r*1.25 and residual<max(2,r*.085):candidates.append([float(cx),float(cy)])
 # Border crops need a circle center outside the frame. Fit fixed-radius arcs.
 edges=cv2.Canny(mask,80,160);ys,xs=np.where(edges>0)
 if len(xs)>25 and ((mask[0]>0).any()or(mask[:,0]>0).any()or(mask[:,-1]>0).any()):
  pts=np.column_stack([xs,ys]).astype(float);rng=np.random.default_rng(1381)
  if len(pts)>650:pts=pts[rng.choice(len(pts),650,replace=False)]
  for _ in range(170):
   a,b=pts[rng.choice(len(pts),2,replace=False)];delta=b-a;length=np.linalg.norm(delta)
   if not r*.25<length<r*1.95:continue
   middle=(a+b)/2;normal=np.array([-delta[1],delta[0]])/length;offset=math.sqrt(r*r-length*length/4)
   for sign in (-1,1):
    c=middle+normal*offset*sign
    if -r*1.5<c[0]<W+r*1.5 and -r*1.5<c[1]<H+r*1.5:candidates.append(c.tolist())
 best=None
 for center in candidates:
  score=circle_score(mask,center,r,hollow)
  if score<0:continue
  if old and not hollow:score-=min(5,np.linalg.norm(np.array(center)-old['head'])/r)*.04
  # Only a small tie-breaker: genuine rapid translations are still permitted.
  if previous:score-=min(10,np.linalg.norm(np.array(center)-previous['head'])/r)*.005
  if best is None or score>best[0]:best=(score,center)
 result=None if best is None else {'head':[round(float(x),3)for x in best[1]],'r':r,'headShape':[r,r,0]}
 CACHE[key]=result
 return copy.deepcopy(result)

def partial_limbs(mask,r,t):
 """Visible border limbs have no invented head or torso attached to a foot."""
 count,labels,stats,_=cv2.connectedComponentsWithStats(mask)
 components=[]
 for k,(x,y,w,h,area) in enumerate(stats[1:],1):
  if area<max(40,r*r*.03)or max(w,h)<r*.75:continue
  if not(x<=2 or y<=2 or x+w>=W-2 or y+h>=H-2):continue
  components.append((int(area),k))
 if not components:return None
 chains=[]
 for _,label in sorted(components,reverse=True)[:3]:
  part=(labels==label).astype(np.uint8)*255;small=cv2.resize(part,(240,135),interpolation=cv2.INTER_NEAREST)
  sk=capture.bones.thin(small);ys,xs=np.where(sk>0)
  if len(xs)<5:continue
  coords=np.column_stack([xs,ys]);lookup={(int(x),int(y)):i for i,(x,y)in enumerate(coords)};adj=[[]for _ in coords]
  for i,(x,y)in enumerate(coords):
   for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
    j=lookup.get((int(x+dx),int(y+dy)))
    if j is not None:adj[i].append((j,math.hypot(dx,dy)))
  border=np.minimum.reduce([xs,ys,239-xs,134-ys]);root=int(np.argmin(border));dist=np.full(len(coords),np.inf);parents=np.full(len(coords),-1,int);dist[root]=0;queue=[(0,root)]
  while queue:
   cost,i=heapq.heappop(queue)
   if cost>dist[i]:continue
   for j,w in adj[i]:
    if cost+w<dist[j]:dist[j]=cost+w;parents[j]=i;heapq.heappush(queue,(cost+w,j))
  ends=[i for i,a in enumerate(adj)if len(a)==1 and np.isfinite(dist[i])and dist[i]>r*.2]
  if not ends:continue
  kept=[]
  for end in sorted(ends,key=lambda i:dist[i],reverse=True):
   if any(np.linalg.norm(coords[end]-coords[other])<max(3,r*.2)for other in kept):continue
   kept.append(end);path=[];j=end
   while j>=0:path.append(j);j=parents[j]
   path=path[::-1];middle=path[int(np.argmin(abs(dist[path]-dist[end]*.5)))];chains.append([(coords[q]*4).astype(float).tolist()for q in [root,middle,end]])
   if len(kept)>=2:break
  if len(chains)>=4:break
 if not chains:return None
 origin=chains[0][0];dummy=[origin.copy(),origin.copy()]
 return {'t':round(t,6),'head':origin,'r':r,'headShape':[r,r,0],
         'hip':origin,'shoulder':origin,'arms':[dummy,dummy],'legs':[dummy,dummy],
         'angle':0,'quality':.6,'partial':True,'partialHead':0,'partialChains':chains}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('video');ap.add_argument('--capture',required=True);ap.add_argument('--output',required=True);ap.add_argument('--only-actors');ap.add_argument('--base');a=ap.parse_args()
 d=json.loads(Path(a.capture).read_text());old={name:{round(p['t']*d['fps']):p for p in v}for name,v in d['tracks'].items()};tracks={k:[]for k in old};previous={};stats={k:{'headsCorrected':0,'partialLimbs':0,'falseHeadsRejected':0}for k in old};cap=cv2.VideoCapture(a.video);i=0
 selected=set(a.only_actors.split(','))if a.only_actors else set(old)
 if a.base:
  base=json.loads(Path(a.base).read_text())
  for name in old:
   if name not in selected:tracks[name]=base['tracks'][name];stats[name]=base['headAudit'][name]
 while True:
  ok,frame=cap.read()
  if not ok:break
  frame=cv2.resize(frame,(W,H),interpolation=cv2.INTER_AREA);t=i/d['fps']
  for name,c in capture.CAST.items():
   if name not in selected:continue
   shot,r=calibrated(name,t)
   if r is None:continue
   p=old[name].get(i)
   # This entrance contains a real continuous camera pull-back.
   if name=='green'and(t<18.583333 or 29.75<t<30.916667)and p:r=max(26,float(p['r']))
   # The hospital insert already has explicitly measured cropped arms.
   if name=='green'and 22.041667-1e-6<=t<23.875-1e-6 and p and p.get('partial'):
    q=copy.deepcopy(p);q['r']=149;q['partialHead']=139 if p.get('partialHead')else 0;q['headShape']=[149,149,0];q['cameraShot']=shot;tracks[name].append(q);continue
   m=capture.mask_for(frame,c)
   if np.count_nonzero(m)<25:continue
   # In these measured crops, the visible red/cyan mark is a leg or hand,
   # not a small head. A partial limb must never instantiate a whole actor.
   forced_partial=(name=='red'and(62.083333-1e-6<=t<63.583333-1e-6 or 77.458333-1e-6<=t<82.041667-1e-6 or 84.75-1e-6<=t<86.3))or(name=='cyan'and t<82.041667-1e-6)
   if forced_partial:
    q=partial_limbs(m,r,t)
    if q:q['cameraShot']=shot;tracks[name].append(q);stats[name]['partialLimbs']+=1
    if p:stats[name]['falseHeadsRejected']+=1
    continue
   prior=previous.get(name)
   if prior and prior.get('cameraShot')!=shot:prior=None
   h=head(m,r,c.get('hollow',False),p,prior)
   if h:
    q=capture.fit_actor(frame,m,h,prior)
    if not q:continue
    if p and(np.linalg.norm(np.array(h['head'])-p['head'])>r*.3 or abs(p['r']/r-1)>.12):stats[name]['headsCorrected']+=1
    q.update({'t':round(t,6),'cameraShot':shot});tracks[name].append(q);previous[name]=q
   else:
    if p:stats[name]['falseHeadsRejected']+=1
    q=partial_limbs(m,r,t)
    if q:q['cameraShot']=shot;tracks[name].append(q);stats[name]['partialLimbs']+=1
  if i%240==0:print(json.dumps({'seconds':round(t,1),'counts':{k:len(v)for k,v in tracks.items()}}),flush=True)
  i+=1
 cap.release();d['tracks']=tracks;d['cameraCalibration']=SHOTS;d['headAudit']=stats
 Path(a.output).write_text(json.dumps(d,separators=(',',':')));Path(a.output).with_suffix('.audit.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats),flush=True)

if __name__=='__main__':main()
