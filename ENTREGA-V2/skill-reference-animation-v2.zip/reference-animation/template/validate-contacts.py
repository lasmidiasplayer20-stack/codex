"""Regression: exchanging left/right legs must exchange their contact targets."""
import copy,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('prepare',Path(__file__).with_name('prepare-motion.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
left=[[-1,3],[-2,5]];right=[[1,3],[2,5]];poses=[]
for i,limbs in enumerate([[left,right],[right,left],[left,right]]):
 p={'t':i/24,'r':1,'head':[0,0],'hip':[0,2],'shoulder':[0,1],'legs':copy.deepcopy(limbs),'arms':[[[-1,1],[-1,2]],[[1,1],[1,2]]]}
 p['footTargets']=[limb[1].copy()for limb in p['legs']];p['footWeights']=[.25 if limb[1][0]<0 else .75 for limb in p['legs']];poses.append(p)
swaps=m.stable_sides(poses,'legs');assert swaps>0
for p in poses:
 for limb,target,weight in zip(p['legs'],p['footTargets'],p['footWeights']):
  assert limb[1]==target,'A left/right exchange detached the foot from its own target'
  assert weight==(.25 if limb[1][0]<0 else .75),'A foot inherited the other foot contact weight'
print('Crossed-leg identity/contact regression passed')
