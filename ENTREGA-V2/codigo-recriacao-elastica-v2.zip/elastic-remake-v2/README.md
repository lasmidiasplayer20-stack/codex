# Reconstrução com personagens elásticos — revisão 2

Recriação do MP4 enviado em 14/10/2026: aproximadamente 1min35s, 1920×1080,
60 fps, vários personagens, câmera, armas e efeitos. Motion 14.1.0 é distribuído
localmente. A trilha AAC original é preservada sem recodificação.

## Método

O vídeo original é analisado somente na preparação. O player e o exportador
carregam dados numéricos, Canvas e áudio; não carregam frames, máscaras, contornos
vetorizados, vídeo de fundo ou imagens extraídas da referência.

Os bonecos usam pontos nomeados para cabeça, ombros, quadril, cotovelos, mãos,
joelhos e pés. As articulações são reconstruídas por cinemática direta, com
rotações contínuas e interpolação cúbica limitada. A identidade dos membros é
estabilizada no referencial do tronco. Ossos degenerados são corrigidos por
medidas vizinhas. O filtro local reduz ruído e preserva giros rápidos reais.

Perfis anatômicos foram calibrados em poses neutras claras da referência, incluindo a altura real do corpo em relação à cabeça. A troca de identidade entre as pernas preserva agora o alvo e o peso de contato de cada pé; os alvos não ficam presos à perna anterior. A mão que segura cada arma mantém identidade dentro do plano.

Cada personagem usa uma anatomia compartilhada entre os planos: tronco, pescoço, braços e pernas mantêm proporções estáveis e simétricas. A escala segue a câmera, incluindo os dois recuos contínuos da referência. Cabeças e membros ocultos não são substituídos por um boneco inteiro preso a uma mão ou pé.

Os membros mais grossos usam duas curvas cúbicas que passam pela articulação, com tangentes limitadas e extremidades arredondadas. Curvas muito dobradas ou assimétricas não extrapolam a pose formando laços. Os pés preservam as posições medidas da referência; a borda escura do cenário não é usada como plano obrigatório de apoio. Pés e mãos usam cinemática inversa com comprimento rígido: um alvo fora do alcance não estica os ossos. As armas interpolam posição, rotação e escala, mantendo o comprimento nos giros.

`stabilize-capture.py` reavalia as cabeças por evidência circular e calibração dos planos. `correct-poses.py` contém anotações de articulações para dois close-ups e a passagem em que o personagem laranja está deitado. Essas anotações corrigem a ambiguidade de um esqueleto que não vê os pés ou confunde uma mão com a segunda perna; são específicas desta referência.

Cabeças vazadas precisam de fechamento adaptativo de falhas de cor e ajuste de
arcos quando os brilhos interrompem o anel. Close-ups com a cabeça fora da câmera
usam controles específicos para os braços visíveis. As cores e os intervalos de
cada personagem seguem a nova referência.

Cenário, cama, acessórios, efeitos e objetos são formas programadas, com dimensões
e transformações medidas. Texturas e peças com detalhes são interpretações em
pixel art geradas pelo código. O aviso de abertura é parte visual da referência.

Esta é uma animação dirigida pela referência, com captura de movimento 2D e
correções; não é uma simulação física autônoma. Poses ocultas ou ambíguas e detalhes
do cenário continuam aproximados. Os testes de posição da cabeça confirmam
alinhamento dos controles, não semelhança perfeita do corpo ou da imagem.

## Usar e exportar

Node 20+, Chromium, FFmpeg e Playwright. No ambiente em nuvem, Chromium está em
`/usr/bin/chromium` e as dependências Node estão instaladas no diretório pai.

```sh
npm ci
node inspect.mjs
node render.mjs --output recriacao-elastica-refinada-v2-1080p60.mp4
python validate-export.py recriacao-elastica-refinada-v2-1080p60.mp4
```

O player pode ser servido por um servidor estático. Reprodução, pausa, busca e
áudio são locais. Nada precisa ser instalado no computador para assistir ao MP4.

## Refazer medições

Use um ambiente Python separado com `requirements.txt` e o MP4 original:

```sh
python capture-scene.py referencia.mp4 --output capture.json
python refine-scene.py referencia.mp4 --capture capture.json --output reviewed.json
python stabilize-capture.py referencia.mp4 --capture reviewed.json --output stable.json
# Adapte as calibrações dos planos e as anotações à referência.
# correct-poses.py pode ser aplicado com um perfil anatômico já medido.
python calibrate-morphology.py stable.json --output morphology.json
python correct-poses.py stable.json --profile-data morphology.json --output annotated.json
python capture-effects.py referencia.mp4 --capture annotated.json --output effects.json
python prepare-motion.py effects.json --duration 94.598095 --output motion-data.js
python validate-contacts.py
```

Os dados prontos da entrega já incluem as revisões. Capturas especializadas podem
ser combinadas com `capture-scene.py --base arquivo.json --only-actor orange`.
Para outra referência, adapte cores, intervalos, câmera, objetos e eventos; os
exemplos desta cena não constituem um detector universal de qualquer vídeo.

`inspect.mjs` verifica todos os rigs a 60 fps, determinismo, personagens presentes,
controles do player e ausência do vídeo original entre os assets. Confere comprimentos anatômicos em toda a duração, contatos fora de alcance, curvas dobradas, escalas antes erradas e recortes sem cabeça inventada. Salva quadros
para comparação visual. `validate-export.py` verifica formato, duração,
decodificação completa e identidade de todos os pacotes AAC do áudio.

O pacote não contém credenciais, sessões de upload nem o arquivo original.
