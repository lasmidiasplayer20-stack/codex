"""Optional local speech analysis. Install pocketsphinx==5.0.4 separately."""
from pathlib import Path
from pocketsphinx import AudioFile
import subprocess,json
p=Path(__file__).parent
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'inputs/narration.mp3'),'-ac','1','-ar','16000',str(p/'voice.wav')],check=True)
rows=[]
for utterance in AudioFile(audio_file=str(p/'voice.wav')):
 offset=utterance.start_frame/100
 words=[dict(word=s.word,start=round(offset+s.start_frame/100,3),end=round(offset+s.end_frame/100,3)) for s in utterance.seg()]
 rows.append(dict(start=offset,end=words[-1]['end'],text=str(utterance),segments=words))
(p/'transcript.json').write_text(json.dumps(rows,indent=2))
