import {createRequire} from 'node:module';
import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const require=createRequire(import.meta.url),{createCanvas}=require('@napi-rs/canvas'),{makeFilm}=require('../scene.js'),Matter=require('matter-js');
const root=path.resolve(import.meta.dirname,'../..');process.chdir(root);const plan=JSON.parse(fs.readFileSync('timeline.json'));
const mode=process.argv[2]||'all',selected=process.argv[3]===undefined?null:Number(process.argv[3]);
fs.mkdirSync('qa',{recursive:true});fs.mkdirSync('renders',{recursive:true});
const canvas=createCanvas(plan.width,plan.height),film=makeFilm(canvas.getContext('2d'),plan,Matter);
if(mode==='qa'){
 for(const s of plan.scenes){let t=(s.start+s.end)/2;film.frame(t);fs.writeFileSync(`qa/scene-${String(s.id).padStart(2,'0')}.png`,canvas.toBuffer('image/png'))}
 // Dense samples: whole film at output fps; validate fixed lengths on every drawn pose.
 for(let i=0;i<Math.ceil(plan.duration*plan.fps);i++)film.frame(i/plan.fps);
 fs.writeFileSync('qa/rig.json',JSON.stringify(film.stats,null,2));console.log(film.stats);process.exit(film.stats.maxBoneError>1e-6||film.stats.maxReachExcess>.001||film.stats.maxArmHeadPenetration>1e-6||film.stats.minElbow<20||film.stats.maxElbow>175?1:0);
}
if(mode==='browser-preview'){
 const {default:puppeteer}=await import('puppeteer-core');const b=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await b.newPage();await page.setViewport({width:960,height:540,deviceScaleFactor:1});await page.setContent('<style>body{margin:0;background:#06090b}canvas{display:block}</style><canvas width="960" height="540"></canvas>');
 await page.addScriptTag({path:'node_modules/matter-js/build/matter.min.js'});await page.addScriptTag({path:'src/scene.js'});await page.evaluate(p=>window.film=makeFilm(document.querySelector('canvas').getContext('2d'),p,Matter),plan);
 for(let i=0;i<120;i++){let t=plan.preview_start+i/30;await page.evaluate(t=>film.frame(t),t);await page.screenshot({path:`qa/browser-${String(i).padStart(3,'0')}.png`})}
 await b.close();execFileSync('ffmpeg',['-v','error','-y','-framerate','30','-i','qa/browser-%03d.png','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart','qa/preview.mp4']);console.log('Puppeteer preview: 120 frames / 30fps');process.exit();
}
for(const s of plan.scenes){if(selected!==null&&selected!==s.id)continue;const name=`renders/scene-${String(s.id).padStart(2,'0')}`,mp4=name+'.mp4';if(fs.existsSync(mp4))continue;fs.mkdirSync(name,{recursive:true});const begin=Date.now();for(let f=s.first;f<s.stop;f++){let out=`${name}/${String(f).padStart(6,'0')}.png`;if(!fs.existsSync(out)){film.frame(f/plan.fps);fs.writeFileSync(out,canvas.toBuffer('image/png'))}}
 execFileSync('ffmpeg',['-v','error','-y','-framerate',String(plan.fps),'-start_number',String(s.first),'-i',`${name}/%06d.png`,'-frames:v',String(s.stop-s.first),'-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p',mp4]);console.log(JSON.stringify({scene:s.id,frames:s.stop-s.first,seconds:(Date.now()-begin)/1000}));
}
if(selected===null){fs.writeFileSync('renders/concat.txt',plan.scenes.map(s=>`file 'scene-${String(s.id).padStart(2,'0')}.mp4'`).join('\n'));execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i','renders/concat.txt','-c','copy','-movflags','+faststart','renders/silent.mp4']);fs.writeFileSync('qa/render-rig.json',JSON.stringify(film.stats,null,2))}
