/* Shared geometric language, fixed human proportions, deterministic scene staging. */
function makeFilm(ctx,plan,Matter){
 const C={white:'#f3f4ef',gray:'#788184',dim:'#263033',red:'#ec3c48',yellow:'#e4cb74',bg:'#06090b'};
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v)},mix=(a,b,t)=>a+(b-a)*t;
 let currentTime=0,currentScene=0;
 const stats={maxBoneError:0,maxContactError:0,maxHandContactError:0,maxReachExcess:0,maxTorsoError:0,maxNeckError:0,maxFingerBoneError:0,maxArmHeadPenetration:0,minElbow:180,maxElbow:0,minKnee:180,maxKnee:0};
 function line(points,color=C.white,width=3){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.stroke()}
 function box(x,y,w,h,color=C.white,width=2,fill=null,r=0){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke()}
 function circle(x,y,r,col=C.white,fill=true){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx[fill?'fillStyle':'strokeStyle']=col;fill?ctx.fill():ctx.stroke()}
 function text(str,x,y,size=18,col=C.white,align='center',weight=500){ctx.fillStyle=col;ctx.font=`${weight} ${size}px DejaVu Sans`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(str,x,y)}
 function bone(a,b,len){stats.maxBoneError=Math.max(stats.maxBoneError,Math.abs(Math.hypot(b[0]-a[0],b[1]-a[1])-len))}
 function ik(a,b,L1,L2,side){let dx=b[0]-a[0],dy=b[1]-a[1],raw=Math.hypot(dx,dy),d=clamp(raw,Math.abs(L1-L2)+.001,L1+L2-.001);stats.maxReachExcess=Math.max(stats.maxReachExcess,raw-L1-L2);let angle=Math.acos(clamp((L1*L1+L2*L2-d*d)/(2*L1*L2),-1,1))*180/Math.PI;
  if(L1===30){if(angle<stats.minElbow)stats.minElbowPose={time:currentTime,scene:currentScene,a,b,angle};stats.minElbow=Math.min(stats.minElbow,angle);stats.maxElbow=Math.max(stats.maxElbow,angle)}else{stats.minKnee=Math.min(stats.minKnee,angle);stats.maxKnee=Math.max(stats.maxKnee,angle)}
  let ux=dx/(raw||1),uy=dy/(raw||1),q=(L1*L1-L2*L2+d*d)/(2*d),h=Math.sqrt(Math.max(0,L1*L1-q*q));const end=[a[0]+ux*d,a[1]+uy*d],joint=[a[0]+ux*q-uy*h*side,a[1]+uy*q+ux*h*side];bone(a,joint,L1);bone(joint,end,L2);return [a,joint,end]}
 function segmentDistance(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],q=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy));return Math.hypot(p[0]-a[0]-q*dx,p[1]-a[1]-q*dy)}
 function actor(x,y,t,opt={}){
  const scale=opt.scale||1.35,dir=opt.dir||1,lean=opt.lean??.08,rot=([a,b])=>[a*Math.cos(lean)-b*Math.sin(lean),a*Math.sin(lean)+b*Math.cos(lean)];
  ctx.save();ctx.translate(x,y);ctx.scale(scale*dir,scale);ctx.globalAlpha*=opt.alpha??1;
  let feet=[[-12,0],[13,0]],pelvis=[0,-67];
  if(opt.walk){const speed=28,period=.92,g=opt.gaitTime??t,sgn=opt.walkSign??1,settle=opt.walkSettle??0;for(let i=0;i<2;i++){let phase=g/period+i*.5,cycle=Math.floor(phase),u=phase-cycle,local=(cycle-i*.5)*speed*period-g*speed;if(u<.62)feet[i]=[local,0];else{let v=(u-.62)/.38;feet[i]=[local+speed*period*ease(v),-9*Math.sin(Math.PI*v)]}}for(let i=0;i<2;i++)feet[i][0]=sgn*(feet[i][0]+6.44*settle);pelvis=[0,mix(-60+1.2*Math.cos(g/.92*4*Math.PI),-66.5,settle)]}
  let top=rot([0,-43]),shoulder=[pelvis[0]+top[0],pelvis[1]+top[1]],ha=lean+(opt.headTilt??-.1),head=[shoulder[0]+23*Math.sin(ha),shoulder[1]-23*Math.cos(ha)];
  stats.maxTorsoError=Math.max(stats.maxTorsoError,Math.abs(Math.hypot(top[0],top[1])-43));stats.maxNeckError=Math.max(stats.maxNeckError,Math.abs(Math.hypot(head[0]-shoulder[0],head[1]-shoulder[1])-23));
  for(let i=0;i<2;i++){const leg=ik([pelvis[0]+(i?6:-6),pelvis[1]],feet[i],34,34,-1);stats.maxContactError=Math.max(stats.maxContactError,Math.hypot(leg[2][0]-feet[i][0],leg[2][1]-feet[i][1]));line(leg,C.white,5.5);line([[leg[2][0]-3,leg[2][1]],[leg[2][0]+8,leg[2][1]]],C.white,5)}
  let nearOffset=[12,59],farOffset=[-12,59];if(opt.walk){let g=opt.gaitTime??t;nearOffset=[12+7*Math.sin(g/.92*2*Math.PI),54];farOffset=[-12-7*Math.sin(g/.92*2*Math.PI),54]}
  if(opt.pose==='visible'){nearOffset=[25,25];farOffset=[-22,28]}
  if(opt.pose==='point'){nearOffset=[29,50]}
  if(opt.pose==='hidden'){nearOffset=[-1,35];farOffset=[1,35]}
  let near=rot(nearOffset),far=rot(farOffset);near=[near[0]+shoulder[0],near[1]+shoulder[1]];far=[far[0]+shoulder[0],far[1]+shoulder[1]];
  if(opt.pose==='imperfect'){const q=clamp(opt.gesture??0);near=[mix(17,39,q),mix(-56,-111,q)];far=[shoulder[0]-20,shoulder[1]+45]}
  if(opt.hand)near=opt.hand;if(opt.farHand)far=opt.farHand;
  if(opt.handMotion){const m=opt.handMotion;near=[mix(near[0],m.near[0],m.q),mix(near[1],m.near[1],m.q)];if(m.far)far=[mix(far[0],m.far[0],m.q),mix(far[1],m.far[1],m.q)]}
  const sj0=rot([-6,3]),sj1=rot([6,3]),armF=ik([shoulder[0]+sj0[0],shoulder[1]+sj0[1]],far,30,29,1),armN=ik([shoulder[0]+sj1[0],shoulder[1]+sj1[1]],near,30,29,opt.armSide??-1);
  for(const arm of [armF,armN])for(let j=0;j<2;j++){let pen=14.8-segmentDistance(head,arm[j],arm[j+1]);if(pen>stats.maxArmHeadPenetration)stats.headCollisionPose={time:currentTime,scene:currentScene,head,arm,pen};stats.maxArmHeadPenetration=Math.max(stats.maxArmHeadPenetration,pen)};
  function arms(){line(armF,C.gray,4.5);line(armN,C.white,5.5)}if(opt.pose==='hidden')arms();
  const w=rot([8,0]);ctx.fillStyle=C.white;ctx.beginPath();ctx.moveTo(shoulder[0]-w[0],shoulder[1]-w[1]);ctx.lineTo(shoulder[0]+w[0],shoulder[1]+w[1]);ctx.lineTo(pelvis[0]+w[0],pelvis[1]+w[1]);ctx.lineTo(pelvis[0]-w[0],pelvis[1]-w[1]);ctx.closePath();ctx.fill();
  line([[shoulder[0],shoulder[1]],head],C.white,6);circle(...head,12);if(opt.pose!=='hidden')arms();
  ctx.save();ctx.translate(...head);ctx.rotate(ha);if(opt.eyesClosed)line([[3,0],[7,0]],C.bg,1.6);else circle(5,0,1.5,C.bg);
  if(opt.smile){ctx.strokeStyle=C.bg;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(2,5);ctx.quadraticCurveTo(5,5+clamp(opt.smile)*3,8,5);ctx.stroke()}ctx.restore();
  if(opt.clothes){const q=ease((opt.clothesTime??0)/2);let a=[shoulder[0]-6,shoulder[1]+5+q*2],b=[shoulder[0],shoulder[1]+9],c=[shoulder[0]+6,shoulder[1]+5+q*2];line([a,b,c],C.bg,1.2);line([[near[0]-4,near[1]-3-q*2],[near[0]+4,near[1]-3-q*2]],C.gray,1.5)}
  if(opt.fan){for(const h of [near,far])for(let i=0;i<4;i++)line([h,[h[0]-4+i*3,h[1]-6-(i%2)]],C.white,1.4)}
  if(opt.pose==='point')line([near,[near[0]+3,near[1]+7]],C.white,2);
  ctx.restore();return {feet,pelvis,shoulder,head,arms:[armF,armN],hands:[far,near],worldHands:[far,near].map(p=>[x+p[0]*scale*dir,y+p[1]*scale])};
 }
 function hand(x,y,scale=2,bend=0,opt={}){ctx.save();ctx.translate(x,y);ctx.rotate(opt.angle||0);ctx.scale((opt.dir||1)*scale,scale);line([[0,47],[0,14]],C.white,9);box(-11,-12,22,27,C.white,2,C.bg,5);
  for(let i=0;i<4;i++){let a=[-8+i*5.4,-12],ang=[-.17,-.04,.08,.22][i]*(opt.spread??1),b=[a[0]+Math.sin(ang)*12,a[1]-Math.cos(ang)*12],flex=(i===1?bend:0),c=[b[0]+Math.sin(ang+flex)*9,b[1]-Math.cos(ang+flex)*9];line([a,b,c],C.white,2.8);stats.maxFingerBoneError=Math.max(stats.maxFingerBoneError,Math.abs(Math.hypot(b[0]-a[0],b[1]-a[1])-12),Math.abs(Math.hypot(c[0]-b[0],c[1]-b[1])-9))}
  line([[-9,3],[-18,-2],[-21,-8]],C.white,3);ctx.restore()}
 function mirror(t,opt={}){const x=520,y=185,w=280,h=225;box(x,y,w,h,C.white,2,'#0d1518',5);line([[x+14,405],[x+w-14,405]],C.gray,1);
  ctx.save();ctx.beginPath();ctx.rect(x+3,y+3,w-6,h-6);ctx.clip();let figure=null;if(!opt.noFigure)figure=actor(661,405,t,{dir:-1,lean:0,headTilt:0,alpha:.82,...opt.reflection});
  if(opt.cover!==undefined){const q=clamp(opt.cover);ctx.fillStyle='#b6bdb8';ctx.fillRect(x+1,y+3-h*(1-q),w-2,h-4);for(let i=1;i<7;i++)line([[x+6+i*38,y+8-h*(1-q)],[x+9+i*38,y+h-8-h*(1-q)]],C.gray,1);if(q>.99)line([[x+9,y+h-10],[x+w-9,y+h-10]],C.gray,1)}ctx.restore();return {x,y,w,h,figure}}
 function pair(t,real={},ref={},options={}){line([[135,410],[450,410]],C.gray,1);const m=mirror(t,{reflection:ref,...options});const a=actor(options.realX??290,410,t,real);return {real:a,mirror:m}}
 function shouldersGuide(a,x,y,scale=1.35,dir=1,color=C.yellow){let h=a.shoulder;line([[x+dir*(h[0]-20)*scale,y+h[1]*scale],[x+dir*(h[0]+20)*scale,y+h[1]*scale]],color,1)}
 function step(t,start=290,sign=-1,duration=1.15){const g=.92*ease(t/duration),settle=ease((t-duration)/.55);return {x:start+sign*(28*g-6.44*settle)*1.35,options:{walk:true,gaitTime:g,walkSign:sign,walkSettle:settle}}}
 function coverDiagram(t,stage){
  const cover=stage==='cover'?ease(t/2.6):1;mirror(t,{reflection:{pose:'visible',fan:true}});
  const gripY=mix(269,194,cover),left=521,right=799,bottom=409;
  ctx.fillStyle='#b6bdb8';ctx.beginPath();ctx.moveTo(left,gripY-6);ctx.lineTo(right,188);ctx.lineTo(right,bottom);ctx.lineTo(left,bottom);ctx.closePath();ctx.fill();
  for(let i=1;i<7;i++){let xx=left+i*(right-left)/7,top=mix(gripY-6,188,i/7);line([[xx,top+2],[xx+2,bottom-3]],C.gray,1)}
  if(cover<.99)line([[left,gripY+(bottom-gripY)*.5],[right,299]],C.gray,1);
  let release=stage==='release'?ease((t-.65)/1.2):['cough','straightcloth'].includes(stage)?1:0;
  let near=[(528-490)/1.35,(gripY-410)/1.35],far=[(526-490)/1.35,(gripY+14-410)/1.35];
  near=[mix(near[0],25,release),mix(near[1],-85,release)];
  const farStart=far;let u=release;if(u<.34){let q=ease(u/.34);far=[mix(farStart[0],45,q),mix(farStart[1],-118,q)]}else if(u<.73){let q=ease((u-.34)/.39);far=[mix(45,28,q),mix(-118,-65,q)]}else{let q=ease((u-.73)/.27);far=[mix(28,-22,q),mix(-65,-82,q)]}
  const holding=actor(490,410,t,{pose:'visible',hand:near,farHand:far,armSide:1,headTilt:-.1+.025*Math.sin(t),fan:release>.95});
  if(release===0){for(const [a,b] of [[holding.worldHands[1],[528,gripY]],[holding.worldHands[0],[526,gripY+14]]])stats.maxHandContactError=Math.max(stats.maxHandContactError,Math.hypot(a[0]-b[0],a[1]-b[1]))}
  if(stage==='release'&&t>.65){line([[507,240],[516,234]],C.red,2);text('RELEASE',389,170,12,C.red)}
  if(stage==='cough'){for(let i=0;i<3;i++){const pulse=(t*.6+i/3)%1;ctx.globalAlpha=.32*(1-pulse);ctx.beginPath();ctx.arc(660,278,34+pulse*36,-.6,.6);ctx.strokeStyle=C.red;ctx.stroke()}ctx.globalAlpha=1}
  if(stage==='straightcloth'){const q=ease(t/2);line([[531,397-q*3],[791,394]],C.gray,2);text('LEAVE IT',390,170,13,C.white)}
 }
 let dustSamples=[];if(Matter){let e=Matter.Engine.create({gravity:{x:0,y:1}}),floor=Matter.Bodies.rectangle(480,420,960,20,{isStatic:true}),bits=[0,1,2,3,4].map(i=>Matter.Bodies.circle(300+i*2,262-i,1.6,{restitution:.05,friction:.8}));Matter.Composite.add(e.world,[floor,...bits]);for(let f=0;f<300;f++){Matter.Engine.update(e,1000/60);dustSamples.push(bits.map(b=>({x:b.position.x,y:b.position.y})))}}
 function office(){box(356,160,248,214,C.white,2);text('OHC',480,214,58,C.white,'center',700);line([[400,259],[560,259]],C.red,2);text('HOUSEHOLD CONTINUITY',480,299,13);text('EVENING ADVISORY',480,339,11,C.gray)}
 function bedroom(time){box(245,164,470,243,C.gray,2,'#10171a',8);for(let i=0;i<8;i++)line([[255,183+i*29],[705,183+i*29]],C.dim,1);let stack=ease((time-292.5)/2),release=ease((time-296.58)/1.7),bend=ease((time-298.0)/1.4)*1.12;if(time>300.48)bend=1.12-.3*Math.sin(Math.PI*clamp((time-300.48)/3.6));hand(450,303,2,0,{angle:-.1});hand(mix(mix(559,475,stack),573,release),mix(279,289,stack),2,bend,{angle:.08});if(time>298){circle(573-6,246,18,C.red,false)}}
 function frame(time){const s=plan.scenes.find(s=>time>=s.start&&time<s.end)||plan.scenes.at(-1),t=time-s.start,k=s.kind;currentTime=time;currentScene=s.id;ctx.globalAlpha=1;ctx.fillStyle=C.bg;ctx.fillRect(0,0,960,540);for(let i=0;i<16;i++){ctx.fillStyle=i%2?'#0b0f11':'#090d0f';ctx.fillRect(i*64,60,1,376)}
  text('OHC / DOMESTIC ANOMALIES',42,28,10,C.gray,'left');text('CASE 02   •   REFLECTION',918,28,10,C.gray,'right');circle(47,61,3,C.red);text('REC',60,61,10,C.gray,'left');text(`${String(Math.floor(time/60)).padStart(2,'0')}:${String(Math.floor(time%60)).padStart(2,'0')}:${String(Math.floor(time*30)%30).padStart(2,'0')}`,918,61,10,C.gray,'right');
  if(k==='rule'){text(s.caption,480,169,15,C.gray);text(s.rule,480,262,100,C.white,'center',700);line([[405,329],[555,329]],C.red,3);text(s.title,480,379,s.title.length>28?22:27,C.white,'center',600)}else{
   if(['opening','correction','unchanged','uneven','demonstrate','patience','relief'].includes(k)){
    let q=ease(t/3);if(k==='demonstrate')q=.5-.5*Math.cos(Math.PI*2*clamp(t/7));const r=k==='unchanged'||k==='patience'?1:q;
    let real={lean:k==='relief'?mix(.08,0,ease(t/4)):.08,headTilt:k==='uneven'?-.1-.04*ease(t/2):-.1};let ref={lean:mix(.08,0,r),headTilt:mix(-.1,.045,r),smile:k==='unchanged'?ease(t/2)*.7:0};
    if(k==='correction'||k==='demonstrate'){ref.handMotion={near:[34,-104],q:Math.sin(Math.PI*clamp(t/5))*.85};ref.armSide=1}
    if(k==='patience'){ref.handMotion={near:[32,-91],q:ease(t/2)};ref.headTilt=.06*Math.sin(t*1.3)}
    if(k==='unchanged'){ref.headTilt=.04+.06*ease(t/3);ref.pose='visible'}
    if(k==='relief'){real.pose='imperfect';real.gesture=.5*ease((t-4.7)/.7)}
    let a=pair(time,real,ref);
    if(['correction','uneven','demonstrate'].includes(k)){shouldersGuide(a.real,290,410);line([[617,258],[701,258]],C.yellow,1)}if(k==='relief'){text('ARCHIVE / DO NOT REPEAT',290,168,12,C.red)}
   }else if(k==='index'){for(let i=1;i<=7;i++){box(220+(i-1)*78,230,52,58,C.white,2,null,3);text(i,246+(i-1)*78,259,25)}text('07',480,350,40,C.red)}
   else if(k==='point'){pair(time,{headTilt:-.1+.03*ease(t/3)}, {pose:'neutral',handMotion:{near:[32,-58],q:ease((t-1)/2)},headTilt:.12*Math.sin(t*1.8)})}
   else if(k==='eyes'){pair(time,{headTilt:-.1-.04*ease(t/2)}, {eyesClosed:t>1,headTilt:.06*ease(t/3),handMotion:{near:[29,-90],q:ease(t/3)}});box(230,158,120,35,C.gray,1);text('NO REPLY',290,175,12)}
   else if(k==='silence'){pair(time,{headTilt:-.1+.03*Math.sin(t*.8),handMotion:{near:[26,-87],q:.35*Math.sin(Math.PI*clamp(t/5))}}, {eyesClosed:false,headTilt:.04*Math.sin(t*.5)});line([[230,164],[350,164]],C.red,2);text('NO APOLOGY',290,190,14,C.gray)}
   else if(k==='sleep'){box(177,250,319,128,C.gray,2);box(203,269,94,68,C.white,2,null,8);ctx.save();ctx.translate(470,311);ctx.rotate(-Math.PI/2);actor(0,0,time,{scale:1.45,lean:0,headTilt:.02*Math.sin(t),handMotion:{near:[22,-60],q:.3+.15*Math.sin(t*.8)}});ctx.restore();mirror(time,{reflection:{headTilt:.03*Math.sin(t*.6),pose:'visible'}});text('OBSERVED',661,165,13,C.red)}
   else if(['visible','nohide','hidden','alone','neck','clothing','dust'].includes(k)){
    let real={pose:'visible',clothes:k==='clothing'||k==='neck',clothesTime:t,headTilt:-.1-.055*ease(t/2)+.018*Math.sin(t*.7),fan:true},ref={pose:'visible',fan:true,headTilt:.025*Math.sin(t*.8)};
    if(k==='visible'){real.pose='neutral';ref.pose='neutral';real.handMotion={near:[25,-85],far:[-22,-82],q:ease(t/1.6)};ref.handMotion={near:[25,-85],far:[-22,-82],q:ease((t+.3)/1.6)};real.fan=t>1.5;ref.fan=t>1.2}
    if(k==='hidden'){ref.pose='visible';ref.handMotion={near:[0,-75],far:[0,-75],q:ease(t/1.8)}}
    if(k==='clothing'||k==='dust'){ref.handMotion={near:[34,-108],q:Math.sin(Math.PI*clamp(t/4))};ref.armSide=1}
    if(k==='nohide'){ref.handMotion={near:[26,-63],q:.55*Math.sin(Math.PI*clamp(t/4))}}
    let a=pair(time,real,ref);
    if(k==='nohide'){line([[247,319],[269,337]],C.red,2);line([[269,319],[247,337]],C.red,2)}
    if(k==='alone'){text('01 PERSON',290,163,14,C.gray);text('01 REFLECTION',660,163,14,C.gray)}
    if(k==='neck'){circle(296,253,17,C.red,false)}
    if(k==='dust'){const f=Math.min(299,Math.floor(Math.max(0,t-1.1)*60));if(t>1.1)for(const p of dustSamples[f]||[])circle(p.x,p.y,1.6,C.yellow);line([[267,410],[336,410]],C.red,1)}
   }else if(k==='object'){let st=step(Math.max(0,t-.7));let a=pair(time,{pose:'visible',fan:true,...st.options},{pose:'hidden',handMotion:{near:[25,-85],q:ease(t/1.3)}},{realX:st.x});let h=a.mirror.figure.worldHands[1];box(h[0]-8,h[1]-27,16,27,C.gray,1,C.bg);for(let i=0;i<4;i++)line([[h[0]-5+i*3,h[1]-24],[h[0]-5+i*3,h[1]-16]],C.white,1);text('STEP AWAY',291,163,13,C.red)}
   else if(k==='ruler'||k==='measure'){hand(371,296,2.9,.2*(1-ease(t/1.8)),{angle:-.07,spread:mix(.55,1.4,ease(t/2))});hand(557,296,2.9,.2*(1-ease(t/1.8)),{dir:-1,angle:.07,spread:mix(.55,1.4,ease(t/2))});box(733,176,35,202,C.white,2);for(let i=0;i<17;i++)line([[734,188+i*11],[i%5===0?756:745,188+i*11]],C.gray,1);if(k==='measure'){line([[713,176],[785,378]],C.red,2);text('NOT LENGTH',480,174,15,C.red)}}
   else if(['smile','angle','disagree'].includes(k)){pair(time,{pose:'visible',smile:0,headTilt:-.1+.025*Math.sin(t*.7),fan:true},{pose:'visible',smile:ease(t/2),headTilt:k==='angle'?.05+.12*ease(t/3):.025*Math.sin(t*.8),handMotion:{near:[26,-90],q:.4*Math.sin(t*.5)**2}});if(k==='disagree')text('KEEP YOUR OWN EXPRESSION',290,163,12,C.gray)}
   else if(k==='camera'){box(368,181,224,166,C.white,2,C.bg,8);circle(480,266,44,C.white,false);circle(480,266,28,C.gray,false);box(386,170,58,22,C.white,2,C.bg,4);line([[357,165],[606,365]],C.red,3);text('NO SELECTION',480,393,14,C.gray)}
   else if(k==='faces'){for(let i=0;i<3;i++){box(238+i*174,184,139,185,C.gray,2,C.bg,3);ctx.save();ctx.beginPath();ctx.rect(240+i*174,186,135,181);ctx.clip();actor(308+i*174,482,time,{scale:1.95,lean:0,headTilt:.08*Math.sin(t*.6+i),smile:i/2*ease(t/2)});ctx.restore()}text('DO NOT CHOOSE',480,406,15,C.red)}
   else if(k==='still'){let st=step(t,464,1,1.25);pair(time,{pose:'visible',...st.options},{pose:'visible'},{realX:st.x});text(t<1.8?'WAIT':'STILL',390,165,13,C.gray);text('STILL',660,165,13,C.gray)}
   else if(['cover','release','cough','straightcloth'].includes(k))coverDiagram(t,k);
   else if(['lift','half','lower','resist','awkward','predict'].includes(k)){
    mirror(time,{cover:1});line([[113,410],[456,410]],C.gray,1);let g=k==='lift'?ease((t-3.5)/1.6)*.6:k==='half'?.6:k==='lower'?mix(.6,.27,ease(t/1.7)):k==='resist'?.27+.045*Math.sin(clamp(t/4)*Math.PI):.27;
    actor(270,410,time,{pose:'imperfect',gesture:g,lean:.08+.008*Math.sin(t*.7),headTilt:-.1+.025*Math.sin(t*.6)});if(k==='half'||k==='awkward')text('STOP',356,220,14,C.red);if(k==='resist'){line([[328,298],[347,298]],C.red,2);line([[328,298],[335,292]],C.red,2);line([[328,298],[335,304]],C.red,2)}
   }else if(k==='leave'){mirror(time,{cover:1});line([[103,410],[452,410]],C.gray,1);box(65,201,70,209,C.gray,2,C.bg);ctx.save();ctx.beginPath();ctx.rect(135,153,800,263);ctx.clip();actor(326-28*1.35*t,410,t,{walk:true,dir:-1});ctx.restore();text('UNTIL MORNING',661,166,11,C.bg)}
   else if(k==='office')office();
   else if(k==='surfaces'){box(150,178,180,174,C.gray,2,'#101719',4);line([[240,178],[240,352]],C.gray,2);line([[150,265],[330,265]],C.gray,2);text('WINDOW',240,383,13,C.gray);line([[422,331],[540,331]],C.white,4);line([[445,329],[445,261],[467,238],[504,238],[504,263]],C.white,5);circle(483,236,8,C.gray,false);text('TAP',480,383,13,C.gray);box(635,184,191,137,C.gray,3,'#0d1417',6);line([[696,324],[683,343],[780,343],[767,324]],C.gray,2);text('TV',731,383,13,C.gray);let sx=t<2.4?240:t<4.1?480:731;let yy=t<2.4?260:t<4.1?276:250;let q=ease((t%(t<2.4?2.4:2))/1.7);line([[sx-42+q*60,yy-35],[sx-20+q*60,yy+35]],C.red,1)}
   else if(k==='inspect'||k==='level'){let a=pair(time,{pose:'visible',...(k==='level'?{walk:true}:{}),headTilt:-.1+.03*Math.sin(t*.8)},{lean:k==='level'?0:.08,headTilt:.02*Math.sin(t*.6),pose:'visible'},{realX:k==='level'?290-28*1.35*t:290});shouldersGuide(a.real,k==='level'?290-28*1.35*t:290,410);line([[618,257],[703,k==='level'?257:264]],C.yellow,1)}
   else if(k==='walk'){box(546,159,268,251,C.gray,2,'#0d1518');line([[111,410],[851,410]],C.gray,1);actor(250+28*1.35*t,410,t,{walk:true});ctx.save();ctx.beginPath();ctx.rect(549,162,262,245);ctx.clip();actor(830-28*1.35*t,410,t,{walk:true,dir:-1,alpha:.45});ctx.restore()}
   else if(['bed','finger','ending'].includes(k))bedroom(time);
   text(s.title,480,462,s.title.length>35?20:s.title.length>29?23:27,C.white,'center',600);text(s.caption,480,498,15,C.gray);
  }
  for(let n=1;n<=7;n++){box(397+(n-1)*25,76,18,17,n===s.rule?C.white:C.dim,1,n===s.rule?C.white:null,2);text(n,406+(n-1)*25,85,10,n===s.rule?C.bg:C.gray)}
  line([[42,520],[918,520]],C.dim,1);line([[42,520],[42+876*time/plan.duration,520]],C.red,1);return s.id;
 }
 return {frame,actor,step,stats};
}
if(typeof module!=='undefined')module.exports={makeFilm};
