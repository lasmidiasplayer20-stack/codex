# Bradikinin / 02 — The Correct Reflection

Filme original a partir do novo MP3 fornecido: 304,666122 segundos de referência temporal, 960×540, 30 fps, 9140 quadros, 54 cenas. A linguagem visual segue a referência: fundo escuro, silhuetas brancas, detalhes vermelhos e diagrama de monitoramento. Os personagens têm atuação por articulações, movimentos independentes do reflexo, passos, recuo, contato com a toalha e resistência no gesto final.

## Dependências

Node.js 24.19.0, Python 3.12.14, NumPy conforme requirements.txt, FFmpeg/ffprobe 7.1.5, Chromium e DejaVu Sans. Canvas nativo 0.1.100, Matter.js 0.20.0 e Puppeteer Core 25.14.0 estão fixados pelo package-lock.json.

```sh
npm ci
python -m pip install -r requirements.txt
mkdir -p inputs
# Coloque o novo MP3 original em inputs/narration.mp3.
# Coloque o MP4 visual original em inputs/reference.mp4 (somente análise).
npm run analyse
npm run music
npm run qa
node src/node/audit-walk.mjs
node src/node/audit-step.mjs
node src/node/audit-motion.mjs
npm run preview
npm run render
npm run mix
npm run validate
python build-delivery.py
```

`npm run all` orquestra análise, música, QA, auditorias, prévia, render, mix e validação. `python build-delivery.py` monta a entrega depois disso. Ajuste o caminho `/usr/bin/chromium` em render.mjs se necessário.

Para uma cena: `node src/node/render.mjs all 34`. PNGs globais em `renders/scene-XX/` e MP4s por cena permitem retomar. Após mudar desenho ou encenação, remova o MP4 e os PNGs apenas da cena alterada. Execute `npm run render` para remontar a concatenação. Os intervalos `[first,stop)` são semiabertos e não repetem o frame do corte. Os PNGs completos não estão no ZIP para evitar duplicação desnecessária.

## Atuação e rig

Cabeça circular de raio 12; pescoço 23; tronco rígido 43; braços 30+29; pernas 34+34 unidades. Ombros e cabeça giram por transformações rígidas, sem mudar comprimento ou escala do corpo. IK de dois segmentos, dobra escolhida por pose. A auditoria inclui erro de segmentos, ângulos, contato dos pés, contato das mãos com a toalha e afastamento entre braços e cabeça considerando espessura dos traços.

O passo para trás e a aproximação usam fases de apoio ancoradas no mundo, aceleração, desaceleração e acomodação do peso. A toalha é uma ilustração de tecido dobrando/desdobrando; não é uma simulação física completa de pano. As mãos permanecem em contato com a ponta até a soltura. Matter.js movimenta somente partículas de poeira. A física não altera os ossos.

A tomada de sono usa o mesmo rig, girado inteiro sobre a cama. Os close-ups das mãos usam falanges de comprimentos fixos. O reflexo tem os mesmos comprimentos do personagem, com atuação temporal independente. Cartelas de regra e algumas vistas de objetos mantêm pausas gráficas, como na referência; o filme não é animação corporal contínua em todos os quadros.

## Som e análise da fala

`music.py` compõe uma nova trilha com seed 1702, drones, pulso e notas; exporta três stems, music.wav e effects.wav. Os efeitos de passos e tecido estão em effects-plan.json. Voz em ganho 1; música em 0,15 e efeitos em 0,3. Não se mistura áudio da referência nem se modifica o andamento da narração. A duração visual cobre o MP3 completo; diferenças de milissegundos entre durações de faixa e contêiner decorrem de delay/padding e codecs.

Nenhuma chamada ElevenLabs foi realizada: a chave não estava configurada. Os efeitos são locais. O passo opcional `npm run effects` usa segredo de ambiente `ELEVENLABS_API_KEY`, cache por hash e registra custo apenas se informado pelo provedor. Ele cria um asset em audio/cache; sua integração ao mix é explícita. Render e mix nunca disparam geração paga.

Para refazer a transcrição opcional: instale `pocketsphinx==5.0.4` e execute `python transcribe.py`. A análise da voz usa transcrição automática PocketSphinx, registrada em transcript.json; ela contém erros. Os textos de tela são rótulos editoriais, não legendas literais. Não houve escuta humana nem garantia de sincronização exata. O roteiro visual limita objetos e ações ao conteúdo identificável da narração.

## Entrega e publicação

MP4 final, capa e 02-README.md ficam em delivery/. O ZIP inclui fontes, configuração, manifests, stems sintetizados, prévias, folha de contato e relatório. Os originais, a voz, o mix com voz, node_modules e caches ficam fora do bundle e fora do GitHub. Reproduzir a voz exige recolocar o novo MP3 fornecido em inputs/narration.mp3.

`node src/node/github-export.mjs /caminho/do/checkout` publica quatro arquivos específicos em Bradikinin/, usando nomes do episódio 02 e preservando o episódio 01. Verifica MP4, hash, tamanho, branch, push sem force e compara o SHA-256 do conteúdo recuperado pelo Git. Recusa substituir arquivos existentes diferentes. A presença do script não prova envio: o registro é produzido em qa/github-export.json após execução bem-sucedida.
