"""Original deterministic suspense score + local foley. No remote generation."""
import json,wave
from pathlib import Path
import numpy as np
P=Path(__file__).parent;sr=24000;D=json.load(open(P/'timeline.json'))['duration'];N=int(np.ceil(D*sr));rng=np.random.default_rng(1702)
(P/'audio').mkdir(exist_ok=True)
def write(name,a):
 a=np.clip(a,-.98,.98)
 with wave.open(str(P/'audio'/name),'wb') as w:w.setnchannels(1 if a.ndim==1 else a.shape[1]);w.setsampwidth(2);w.setframerate(sr);w.writeframes((a*32767).astype('<i2').tobytes())
def add(a,time,sound,gain=1):
 i=round(time*sr);n=min(len(sound),len(a)-i)
 if n>0:a[i:i+n]+=sound[:n]*gain
n=np.arange(N,dtype=np.float64)/sr
fade=np.minimum(np.clip(n/3,0,1),np.clip((D-n)/4,0,1))
# Smooth additive drone, phase continuous; subtle motion follows the seven rules.
roots=[41.2034,36.7081,46.2493,43.6535,38.8909,41.2034,30.8677]
starts=[0,56.52,84.27,117.42,151.26,185.94,219.41,D]
freq=np.full(N,roots[0])
for j in range(1,7):
 q=np.clip((n-starts[j])/3,0,1);q=q*q*(3-2*q);freq=freq*(1-q)+roots[j]*q
phase=2*np.pi*np.cumsum(freq)/sr
drone=(np.sin(phase)*.15+np.sin(phase*1.501)*.07+np.sin(phase*2+.05*np.sin(n*.3))*.045)*(1+.13*np.sin(n*.23))*fade
write('stem-drone.wav',drone)
pulse=np.zeros(N,dtype=np.float32);tones=np.zeros(N,dtype=np.float32)
for time in np.arange(2.4,D-3,1.62):
 x=np.arange(int(sr*.55))/sr;env=np.sin(np.pi*np.clip(x/.55,0,1))**2*np.exp(-x*7)
 add(pulse,time,np.sin(2*np.pi*(53*x-13*x*x))*env,.12)
notes=[164.814,184.997,146.832,246.942,174.614,123.471,155.563]
for i,time in enumerate(np.arange(8,D-5,7.3)):
 x=np.arange(sr*4)/sr;env=(1-np.exp(-x*40))*np.exp(-x*1.4)*np.clip((4-x)*8,0,1);f=notes[i%len(notes)]
 sound=(np.sin(2*np.pi*f*x)+.25*np.sin(2*np.pi*2.003*f*x))*env*.1
 add(tones,time,sound)
 for delay,g in [(0.32,.25),(.67,.12)]:add(tones,time+delay,sound,g)
write('stem-pulse.wav',pulse*fade);write('stem-tones.wav',tones*fade)
write('music.wav',(drone+pulse+tones)*.45)
fx=np.zeros(N,dtype=np.float32);events=[]
def event(time,kind):
 if kind=='step':
  x=np.arange(int(sr*.14))/sr;s=(np.sin(2*np.pi*95*x)*.5+rng.normal(0,.2,len(x)))*np.exp(-x*32)*np.clip(x/.005,0,1);gain=.12
 elif kind=='cloth':
  x=np.arange(int(sr*.7))/sr;noise=rng.normal(0,.16,len(x));noise=np.convolve(noise,np.ones(5)/5,mode='same');s=noise*np.sin(np.pi*x/.7)**2;gain=.35
 elif kind=='knock':
  x=np.arange(int(sr*.22))/sr;s=(np.sin(2*np.pi*180*x)+rng.normal(0,.3,len(x)))*np.exp(-x*30);s*=np.clip(x/.003,0,1);gain=.15
 elif kind=='beep':
  x=np.arange(int(sr*.16))/sr;s=np.sin(2*np.pi*880*x)*np.sin(np.pi*x/.16)**2;gain=.12
 elif kind=='click':
  x=np.arange(int(sr*.035))/sr;s=rng.normal(0,1,len(x))*np.exp(-x*160)*np.clip(x/.002,0,1);gain=.09
 else:
  x=np.arange(int(sr*.8))/sr;s=(np.sin(2*np.pi*(120*x+90*x*x))*.3+rng.normal(0,.1,len(x)))*np.sin(np.pi*x/.8)**2;gain=.06
 add(fx,time,s,gain);events.append(dict(time=time,kind=kind,source='local-synthesis',gain=gain))
for time in [104.505,105.08,190.615,191.24]:event(time,'step')
for time in np.arange(257.2,262.4,.46):event(float(time),'step')
for time in [194.1,195.2,196.2,201.2,212.4,296.8,301.0]:event(time,'cloth')
for time in [27.96,56.52,84.27,117.42,151.26,185.94,219.41]:event(time,'transition')
write('effects.wav',fx)
(P/'effects-plan.json').write_text(json.dumps(dict(seed=1702,sample_rate=sr,provider='local fallback; ElevenLabs key not configured',events=events),indent=2))
print('Score, 3 stems and local effects:',N,'samples')
