"""Package only the explicit episode deliverables; exclude original user media."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,zipfile,shutil,math
P=Path(__file__).parent;plan=json.load(open(P/'timeline.json'));v=json.load(open(P/'qa/validation.json'));q=json.load(open(P/'qa/rig.json'));walk=json.load(open(P/'qa/walk-audit.json'));step=json.load(open(P/'qa/step-audit.json'));base=plan['basename'];d=P/'delivery';d.mkdir(exist_ok=True)
# Probe actual encoded frames for the contact sheet.
rows=[]
for s in plan['scenes']:
 f=P/f"qa/encoded-{s['id']:02d}.png";subprocess.run(['ffmpeg','-v','error','-y','-ss',str((s['start']+s['end'])/2),'-i',str(d/(base+'.mp4')),'-frames:v','1',str(f)],check=True);rows.append(f)
sheet=Image.new('RGB',(1280,162*((len(rows)+4)//5)),'#101417');draw=ImageDraw.Draw(sheet)
for i,f in enumerate(rows):
 x=i%5*256;y=i//5*162;sheet.paste(Image.open(f).convert('RGB').resize((256,144)),(x,y));draw.text((x+5,y+145),f"{i:02d} / {plan['scenes'][i]['start']:.2f}s",fill='white')
sheet.save(P/'qa/contact-sheet.jpg',quality=92);shutil.copy(rows[0],d/(base+'-cover.png'))
# Compact review video from actual final scenes, with their own narration segments.
starts=[103.3,193.74,227.0,293.6]
for i,t in enumerate(starts):subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(d/(base+'.mp4')),'-t','4','-c:v','libx264','-preset','fast','-crf','20','-c:a','aac',str(P/f'qa/preview-part-{i}.mp4')],check=True)
(P/'qa/preview-concat.txt').write_text('\n'.join(f"file 'preview-part-{i}.mp4'" for i in range(4)))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(P/'qa/preview-concat.txt'),'-c','copy','-movflags','+faststart',str(P/'qa/preview-final.mp4')],check=True)
# Dense motion sequences from final renderer frames.
for scene,t,crop in [(18,103.3,(200,200,790,420)),(34,193.74,(440,140,810,420)),(35,200.24,(440,140,810,420)),(39,227,(170,170,440,420)),(52,297,(330,170,650,415))]:
 o=Image.new('RGB',(1200,600),'#101417');dr=ImageDraw.Draw(o)
 for i in range(12):
  frame=math.ceil((t+i*.17)*30);f=P/f'renders/scene-{scene:02d}/{frame:06d}.png'
  if not f.exists():continue
  im=Image.open(f).crop(crop);im.thumbnail((300,180));x=i%4*300;y=i//4*200;o.paste(im,(x,y));dr.text((x+5,y+184),f'{frame/30:.3f}s',fill='white')
 o.save(P/f'qa/dense-{scene}.jpg')
# Objective audio peak/RMS information, without claiming listening.
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(P/'audio/mix.wav'),'-af','astats=metadata=0:reset=0','-f','null','-'],capture_output=True,text=True,check=True);(P/'qa/audio-stats.txt').write_text(r.stderr)
report=f'''# Relatório / episódio 02 — The Correct Reflection

MP3: MiniMax_2026-10-16_22_09_14_Deep_Storyteller.mp3, duração de contêiner 304,666122 s. Referência visual: videoplayback (12).mp4, a mesma do primeiro episódio. Hashes/metadados em inputs-manifest.json. Os originais não foram alterados nem incluídos no ZIP ou no commit.

## Resultado

- 54 cenas, {v['read_frames']} quadros, 960×540, 30 fps, H.264/yuv420p, AAC 192 kbps, faststart.
- Duração de vídeo: {v['video_duration']:.6f} s. Áudio final: {v['audio_duration']:.6f} s. Contêiner: {v['container_duration']:.6f} s. As diferenças de padding/codec não cortam o conteúdo decodificado da voz.
- Tamanho: {v['bytes']} bytes. SHA-256: `{v['sha256']}`.
- Voz importada uma única vez, em velocidade original. Nenhum áudio ou frame da referência foi incorporado ao filme.
- Música inédita local em Python/NumPy, seed 1702, três stems. Efeitos de tecido e passos locais; plano de eventos incluído. Zero chamadas pagas à ElevenLabs; chave não configurada, consumo informado pelo provedor: não aplicável.

## Atuação e decisões visuais

O novo pedido de movimentos e interação foi aplicado às cenas: correção de ombro/cabeça pelo reflexo, gesto demonstrativo e reprovação, mãos trazidas à frente, recuo com transferência de peso, retorno da mão com objeto, dedos afastados, sorrisos e ângulos da cabeça, ajustes na roupa, poeira caindo, aproximação com parada, contato e soltura da toalha, braço levantado até a metade e abaixado sem completar o gesto, saída pela porta e rearranjo das mãos no cobertor.

O cenário e os personagens são diagramas de suspense, como na referência. Há pausas em cartelas e ícones. O reflexo age antes ou de modo diferente da pessoa quando a fala pede; não há pessoa extra atrás do protagonista. O sono usa o mesmo modelo corporal girado; os close-ups de mãos usam falanges rígidas. A toalha se desdobra graficamente; não se afirma simulação física completa de tecido. Matter.js é usado apenas para a poeira.

A curva de soltura foi corrigida depois de detectar flexão excessiva e passagem da mão perto da cabeça. A mão distante agora recua por um arco exterior antes de baixar. As soluções IK mantêm o lado de dobra e não alongam segmentos.

## Verificações automáticas

- Timeline com intervalos semiabertos, contagem completa de PNGs e {v['read_frames']} frames confirmados no MP4. Decodificação integral: {v['full_decode']}.
- Erro máximo dos membros: {q['maxBoneError']:.3g}; torso: {q['maxTorsoError']:.3g}; pescoço: {q['maxNeckError']:.3g}; falanges: {q['maxFingerBoneError']:.3g} unidades.
- Excesso de alcance pedido ao IK: {q['maxReachExcess']}. Penetração dos braços na cabeça considerando a espessura do traço: {q['maxArmHeadPenetration']}.
- Cotovelos: ângulos internos {q['minElbow']:.2f}°–{q['maxElbow']:.2f}°. Joelhos: {q['minKnee']:.2f}°–{q['maxKnee']:.2f}°. Não há hiperextensão na amostragem de todos os frames.
- Erro de posição dos pés em relação ao alvo: {q['maxContactError']:.3g}. Erro de contato das mãos na ponta da toalha antes de soltar: {q['maxHandContactError']:.3g} px.
- Caminhada contínua: deriva em apoio {walk['max_world_foot_drift_px']:.3g} px, {walk['samples']} comparações. Passos com desaceleração/acomodação: {step['max_world_foot_drift_px']:.3g} px, {step['comparisons']} comparações a 30 fps nos dois sentidos.
- Pico e RMS do mix em qa/audio-stats.txt. Verificar picos não equivale a escutar a mixagem.

## Inspeção e limites

Prévia de quatro segundos gerada em Chromium/Puppeteer; PNGs finais pelo Canvas 2D nativo em Node. Folha de contato extraída do MP4 final. Sequências densas mostram recuo, toalha, soltura, braço interrompido e dedos. A inspeção visual é por quadros/sequências; não houve reprodução audiovisual humana nem escuta humana. Não se afirma perfeição ou naturalidade irrestrita.

A análise de fala é PocketSphinx local, com erros registrados em transcript.json. Os títulos são rótulos editoriais e não legendas literais. A encenação segue os marcos de frase; não foi feito alinhamento fonético exato. Onde a palavra do objeto retornado não foi reconhecida com segurança, o texto visual usa descrição genérica.

O guia anexado começa no trecho anterior à seção 15; foram seguidas as instruções disponíveis. API ElevenLabs sem chave: efeitos locais e módulo opcional de geração com cache. Render/mix não disparam cobrança. Os stems e fontes estão no bundle; é necessário recolocar o novo MP3 original para reconstruir a voz. Render temporário observado: cerca de 250–350 MB de PNGs, mantendo somente uma cópia por frame. O diretório output do cliente não existe neste executor; entregas são organizadas em delivery/ e no destino GitHub autorizado.

## Publicação

O exportador adiciona apenas os quatro arquivos do episódio 02 em Bradikinin/, preservando os arquivos do episódio 01. Confere hash e tamanho, faz commit/push comum e verifica o conteúdo recuperado pelo Git. O registro de execução é escrito em qa/github-export.json somente após o envio. A presença deste bundle não substitui a confirmação de publicação e links na resposta de entrega.
'''
(P/'report.md').write_text(report)
(d/'02-README.md').write_text(f'''# Bradikinin / 02 — The Correct Reflection

Filme completo original com o segundo áudio: ~5min05s, 960×540, 30 fps, H.264/AAC. Voz na velocidade original; música e efeitos locais. Personagens articulados, movimentos independentes do reflexo, recuo, contato com a toalha e gesto interrompido.

[Baixar MP4]({base}.mp4) — abra o arquivo e use **Download raw file** no GitHub.

[Capa]({base}-cover.png) · [Projeto, prévias, folha de contato e relatório]({base}-project.zip).

SHA-256: `{v['sha256']}`.

O ZIP exclui os originais pessoais. Para reproduzir a narração, coloque o novo MP3 fornecido em inputs/narration.mp3. Os efeitos são locais por ausência de chave ElevenLabs. A validação inclui geometria, contatos, timeline e decodificação; não houve escuta humana nem garantia de sincronização exata.
''')
items=['README.md','report.md','requirements.txt','package.json','package-lock.json','timeline.json','make-plan.py','music.py','build-delivery.py','inputs-manifest.json','effects-plan.json','transcript.json','guide.md','transcribe.py']
items += [str(f.relative_to(P)) for f in (P/'src').rglob('*') if f.is_file()]
items += [str(f.relative_to(P)) for f in (P/'audio').glob('*.wav') if f.name!='mix.wav']
items += [str(f.relative_to(P)) for f in (P/'qa').glob('*') if f.is_file() and (f.suffix in ['.json','.jpg','.txt'] or f.name in ['preview.mp4','preview-final.mp4']) and not f.name.startswith('preview-concat')]
with zipfile.ZipFile(d/(base+'-project.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for item in sorted(set(items)):
  if (P/item).is_file():z.write(P/item,'bradikinin-02/'+item)
print('Delivery prepared:',[(f.name,f.stat().st_size) for f in d.iterdir()])
