# Relatório / episódio 02 — The Correct Reflection

MP3: MiniMax_2026-10-16_22_09_14_Deep_Storyteller.mp3, duração de contêiner 304,666122 s. Referência visual: videoplayback (12).mp4, a mesma do primeiro episódio. Hashes/metadados em inputs-manifest.json. Os originais não foram alterados nem incluídos no ZIP ou no commit.

## Resultado

- 54 cenas, 9140 quadros, 960×540, 30 fps, H.264/yuv420p, AAC 192 kbps, faststart.
- Duração de vídeo: 304.666667 s. Áudio final: 304.639000 s. Contêiner: 304.666667 s. As diferenças de padding/codec não cortam o conteúdo decodificado da voz.
- Tamanho: 9595774 bytes. SHA-256: `0f8cdab672c71bd4b23e240b8447871494b318128bc65d1f5c4009c5b37a8614`.
- Voz importada uma única vez, em velocidade original. Nenhum áudio ou frame da referência foi incorporado ao filme.
- Música inédita local em Python/NumPy, seed 1702, três stems. Efeitos de tecido e passos locais; plano de eventos incluído. Zero chamadas pagas à ElevenLabs; chave não configurada, consumo informado pelo provedor: não aplicável.

## Atuação e decisões visuais

O novo pedido de movimentos e interação foi aplicado às cenas: correção de ombro/cabeça pelo reflexo, gesto demonstrativo e reprovação, mãos trazidas à frente, recuo com transferência de peso, retorno da mão com objeto, dedos afastados, sorrisos e ângulos da cabeça, ajustes na roupa, poeira caindo, aproximação com parada, contato e soltura da toalha, braço levantado até a metade e abaixado sem completar o gesto, saída pela porta e rearranjo das mãos no cobertor.

O cenário e os personagens são diagramas de suspense, como na referência. Há pausas em cartelas e ícones. O reflexo age antes ou de modo diferente da pessoa quando a fala pede; não há pessoa extra atrás do protagonista. O sono usa o mesmo modelo corporal girado; os close-ups de mãos usam falanges rígidas. A toalha se desdobra graficamente; não se afirma simulação física completa de tecido. Matter.js é usado apenas para a poeira.

A curva de soltura foi corrigida depois de detectar flexão excessiva e passagem da mão perto da cabeça. A mão distante agora recua por um arco exterior antes de baixar. As soluções IK mantêm o lado de dobra e não alongam segmentos.

## Verificações automáticas

- Timeline com intervalos semiabertos, contagem completa de PNGs e 9140 frames confirmados no MP4. Decodificação integral: passed.
- Erro máximo dos membros: 2.49e-14; torso: 1.42e-14; pescoço: 2.13e-14; falanges: 5.33e-15 unidades.
- Excesso de alcance pedido ao IK: 0. Penetração dos braços na cabeça considerando a espessura do traço: 0.
- Cotovelos: ângulos internos 32.87°–149.08°. Joelhos: 99.16°–168.43°. Não há hiperextensão na amostragem de todos os frames.
- Erro de posição dos pés em relação ao alvo: 3.97e-15. Erro de contato das mãos na ponta da toalha antes de soltar: 2.84e-14 px.
- Caminhada contínua: deriva em apoio 1.14e-13 px, 700 comparações. Passos com desaceleração/acomodação: 5.68e-14 px, 684 comparações a 30 fps nos dois sentidos.
- Pico e RMS do mix em qa/audio-stats.txt. Verificar picos não equivale a escutar a mixagem.

## Inspeção e limites

Prévia de quatro segundos gerada em Chromium/Puppeteer; PNGs finais pelo Canvas 2D nativo em Node. Folha de contato extraída do MP4 final. Sequências densas mostram recuo, toalha, soltura, braço interrompido e dedos. A inspeção visual é por quadros/sequências; não houve reprodução audiovisual humana nem escuta humana. Não se afirma perfeição ou naturalidade irrestrita.

A análise de fala é PocketSphinx local, com erros registrados em transcript.json. Os títulos são rótulos editoriais e não legendas literais. A encenação segue os marcos de frase; não foi feito alinhamento fonético exato. Onde a palavra do objeto retornado não foi reconhecida com segurança, o texto visual usa descrição genérica.

O guia anexado começa no trecho anterior à seção 15; foram seguidas as instruções disponíveis. API ElevenLabs sem chave: efeitos locais e módulo opcional de geração com cache. Render/mix não disparam cobrança. Os stems e fontes estão no bundle; é necessário recolocar o novo MP3 original para reconstruir a voz. Render temporário observado: cerca de 250–350 MB de PNGs, mantendo somente uma cópia por frame. O diretório output do cliente não existe neste executor; entregas são organizadas em delivery/ e no destino GitHub autorizado.

## Publicação

O exportador adiciona apenas os quatro arquivos do episódio 02 em Bradikinin/, preservando os arquivos do episódio 01. Confere hash e tamanho, faz commit/push comum e verifica o conteúdo recuperado pelo Git. O registro de execução é escrito em qa/github-export.json somente após o envio. A presença deste bundle não substitui a confirmação de publicação e links na resposta de entrega.
