# If Your Elevator Shows Your Name, Don't Press It

Projeto vetorial original em Canvas 2D, Node.js, Puppeteer e Matter.js. Final: 1920×1080, 30 fps, 8.360 quadros, aproximadamente 4min39s. A referência foi usada para linguagem visual: fundo escuro, pictogramas brancos, acentos contidos e interferência discreta. Não se reutilizou sua faixa sonora.

## Dependências verificadas

Node 24.19.0, Chromium 154.0.8037.57 (`/usr/bin/chromium`), FFmpeg 7.1.5, Python 3.12, NumPy 2.3.5, Pillow 12.3.0. Versões npm em `package-lock.json`; reconhecimento local: sherpa-onnx 1.13.8 / Whisper base.en, alinhamento: PocketSphinx 5.0.4.

```bash
npm ci --cache work/npm-cache
python -m pip install -r requirements.txt
```

O ZIP público não inclui a gravação original, o vídeo de referência, o mix com a voz, modelos de reconhecimento, segredos nem caches. Para reproduzir o episódio com voz, use o mesmo MP3 que você anexou. Os efeitos gerados e os stems musicais estão incluídos; a timeline e a transcrição local já estão em cache.

## Análise local do áudio

```bash
npm run analyze -- "/caminho/MiniMax_2026-10-16_21_49_07_Deep_Storyteller.mp3"
```

Esse comando cria `assets/audio/narration.wav`, `work/narration16.wav`, os metadados e o mapa de silêncios. Não faz chamadas externas. Para reproduzir apenas render/mix, não é necessário transcrever novamente.

Transcrição opcional, inteiramente local, depois de baixar o modelo público (o download não envia áudio):

```bash
curl -L --fail -o work/model.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.en.tar.bz2
tar -xjf work/model.tar.bz2 -C work
ELEVATOR_MODEL_DIR="$PWD/work/sherpa-onnx-whisper-base.en" python src/python/transcribe.py
python src/python/align.py
python src/python/timeline.py
```

As legendas são automáticas, com alinhamento local por palavra; não houve revisão humana da transcrição. Elas podem conter erros de reconhecimento. O áudio original não é alterado por essas etapas.

## Efeitos, música e mix

```bash
# Opcional: usa a ElevenLabs apenas se um efeito estiver ausente do cache.
# A chave deve existir no ambiente; nunca a escreva no projeto.
npm run effects

# Composição local original, seed 42017; três stems WAV para remixagem.
npm run music

# Usa somente a narração importada, a música e os efeitos em cache.
npm run mix
```

Gerar efeitos é separado do build padrão. `npm run build`, renderizar e mixar não fazem novas gerações pagas. `manifests/effects-plan.json` documenta prompts, `assets/audio/sfx/*.json` documenta hashes e consumo informado; cinco efeitos gerados, 180 créditos informados no cabeçalho `character-cost`.

## Prévia e inspeção do gesto

```bash
npm run preview
npm run audit
node src/node/render.mjs --draft --scene=25-cab
ffmpeg -y -framerate 30 -start_number 3612 -i renders-draft/25-cab/%07d.png -frames:v 121 -c:v libx264 -pix_fmt yuv420p work/gesture-preview-960.mp4
```

Prévia: 960×540. O modo `--preview` salva cinco poses por cena; `--audit` amostra a cada três frames nos primeiros seis segundos de cada cena; `--draft` salva todos os frames a 30 fps. Os diretórios são separados dos PNGs finais em 1080p.

## Render e montagem final

```bash
npm run render
# Uma cena isolada, com os mesmos números globais de frames:
node src/node/render.mjs --scene=25-cab

ELEVATOR_OUTPUT="$PWD/output/Bradikinin" npm run assemble
ELEVATOR_OUTPUT="$PWD/output/Bradikinin" npm run validate
ELEVATOR_OUTPUT="$PWD/output/Bradikinin" npm run delivery
```

Os intervalos são semiabertos `[firstFrame, endFrameExclusive)`. Cada frame pertence a uma única cena; nenhum frame de corte é duplicado. `renders-final/<cena>/<frame>.png` permite retomar um render interrompido. Ao mudar o código ou a timeline, remova os PNGs e arquivos `work/encoded` das cenas afetadas antes de renderizar novamente.

O assemble codifica cada cena em H.264/yuv420p, concatena um vídeo silencioso, confere a cobertura de vídeo/mix e associa explicitamente a faixa já mixada. O áudio é AAC 192 kb/s e o contêiner recebe `+faststart`. Não há uso de `-shortest`.

Orquestração completa com efeitos em cache e narração previamente importada:

```bash
ELEVATOR_OUTPUT="$PWD/output/Bradikinin" npm run build
```

## Rig e validação

Cabeça e tronco rígidos; braços 35+33 unidades e pernas 46+43; IK sem stretch; ramo de dobra definido por gesto. Os pés permanecem nas mesmas posições durante gestos em pé. A física Matter.js atua apenas no carrinho vazio, com amortecimento determinístico, sem ragdoll nos humanos.

`validate.py` verifica todos os números e dimensões dos PNGs, a cobertura da timeline, a decodificação integral do MP4, a presença de conteúdo em cada frame, a integridade dos segmentos, a constância dos pixels dos pés no gesto de apoio e a correlação temporal da narração em oito pontos. Isso não substitui uma avaliação humana de naturalidade nem uma audição integral em tempo real; essas avaliações não foram realizadas.

## Exportação Git binária

```bash
node src/node/github-export.mjs /caminho/checkout-exclusivo /caminho/output/Bradikinin entrega-elevator-20261016
```

O exportador foi implementado para um clone exclusivo `--no-checkout` do repositório conectado `lasmidiasplayer20-stack/codex`. Confere o destino, formato, duração, tamanho e SHA-256, preserva a árvore base, recusa sobrescrever entregas existentes, adiciona somente os arquivos nomeados, faz commit e push comum para a nova branch. A validação do payload remoto é uma etapa posterior; não se considera o hash de commit como hash do MP4.
