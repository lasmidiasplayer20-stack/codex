import os,json,subprocess,shutil,glob
from PIL import Image,ImageDraw
cfg=json.load(open('manifests/timeline.json'));out=os.environ.get('ELEVATOR_OUTPUT','/workspace/work/output/Bradikinin');os.makedirs(out,exist_ok=True);video=out+'/'+cfg['title']+'.mp4'
shutil.copyfile('renders-final/01-title/0000060.png',out+'/'+cfg['title']+'-cover.png')
pick=[0,5,7,10,15,16,20,24,28,30,33,34,36,39,49,54]
sheet=Image.new('RGB',(1920,4*296),'#131313');draw=ImageDraw.Draw(sheet)
for j,i in enumerate(pick):
 s=cfg['scenes'][i];f=(s['firstFrame']+s['endFrameExclusive'])//2
 im=Image.open(f'renders-final/{s["id"]}/{f:07}.png').resize((480,270),Image.Resampling.LANCZOS);x=j%4*480;y=j//4*296;sheet.paste(im,(x,y));draw.text((x+9,y+275),f'{s["start"]:06.2f}s  {s["id"]}',fill='#dddddd')
sheet.save(out+'/contact-sheet.jpg',quality=93)
subprocess.run(['ffmpeg','-v','error','-y','-i',video,'-filter_complex','[0:v]trim=start=119:end=126,setpts=PTS-STARTPTS,scale=960:540[v0];[0:a]atrim=start=119:end=126,asetpts=PTS-STARTPTS[a0];[0:v]trim=start=141.5:end=148.5,setpts=PTS-STARTPTS,scale=960:540[v1];[0:a]atrim=start=141.5:end=148.5,asetpts=PTS-STARTPTS[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]','-map','[v]','-map','[a]','-c:v','libx264','-crf','20','-preset','veryfast','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',out+'/preview.mp4'],check=True)
print('Cover, contact sheet and 14s preview exported.')
