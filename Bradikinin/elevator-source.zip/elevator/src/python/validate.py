import json,os,sys,hashlib,subprocess,re,struct,wave
import numpy as np
from PIL import Image
cfg=json.load(open('manifests/timeline.json'));out=os.environ.get('ELEVATOR_OUTPUT','/workspace/work/output/Bradikinin');video=out+'/'+cfg['title']+'.mp4'
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',video]));v=next(s for s in p['streams']if s['codec_type']=='video');a=[s for s in p['streams']if s['codec_type']=='audio']
assert(v['width'],v['height'],v['codec_name'],v['pix_fmt'],v['avg_frame_rate'])==(1920,1080,'h264','yuv420p','30/1')
assert len(a)==1 and a[0]['codec_name']=='aac';assert float(p['format']['duration'])>=278.5979
expected=0
for s in cfg['scenes']:
 assert s['firstFrame']==expected
 for f in range(s['firstFrame'],s['endFrameExclusive']):
  name=f'renders-final/{s["id"]}/{f:07}.png'
  with open(name,'rb') as z:h=z.read(24)
  assert h[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',h[16:24])==(1920,1080)
 expected=s['endFrameExclusive']
assert expected==cfg['frameCount']
if '--reuse-decode' not in sys.argv:
 subprocess.run(['ffmpeg','-v','error','-xerror','-y','-i',video,'-vf','scale=480:270,signalstats,metadata=print:key=lavfi.signalstats.YMAX:file=work/luma.txt','-an','-f','null','-'],check=True)
lum=[float(x)for x in re.findall(r'YMAX=([\d.]+)',open('work/luma.txt').read())];assert len(lum)==expected and min(lum)>170
# Verify planted feet in the rail gesture by pixel equality in source PNGs.
s=next(s for s in cfg['scenes']if s['id']=='25-cab');fset=[s['firstFrame'],(s['firstFrame']+s['endFrameExclusive'])//2,s['endFrameExclusive']-1]
feet=[np.asarray(Image.open(f'renders-final/25-cab/{f:07}.png').crop((894,640,1004,764)))for f in fset]
footdiff=max(int(np.max(np.abs(x.astype(int)-feet[0].astype(int))))for x in feet)
assert footdiff==0
with wave.open('assets/audio/narration.wav')as z:voice=np.frombuffer(z.readframes(z.getnframes()),'<i2').astype(np.float32)/32768;sr=z.getframerate()
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',video,'-map','0:a:0','-ar',str(sr),'-ac','1','-f','f32le','-']),'<f4')
cor=[];lags=[]
for second in [3,34,77,121,164,211,245,276]:
 start=int(second*sr);length=sr;pad=sr//25
 ref=voice[start:start+length:8];win=audio[start-pad:start+length+pad:8];r=np.correlate(win,ref,'valid');ix=int(np.argmax(r));coarse=ix*8-pad
 # Refine the coarse 8-sample grid at full rate; a 4-sample phase error can
 # otherwise depress waveform correlation despite correct playback timing.
 full=voice[start:start+length];candidates=[]
 for lag in range(coarse-8,coarse+9):candidates.append((float(np.corrcoef(full,audio[start+lag:start+lag+length])[0,1]),lag))
 best,lag=max(candidates);lags.append(lag/sr);cor.append(best)
print('Voice alignment diagnostics:',{'correlations':cor,'lags':lags},flush=True)
assert max(abs(x)for x in lags)<.01 and min(cor)>.85
rig=json.load(open('manifests/rig-render.json'));assert rig['unreachableTargets']==0 and rig['maxLengthError']<1e-9
r={'resolution':[v['width'],v['height']],'fps':v['avg_frame_rate'],'codec':v['codec_name'],'pixelFormat':v['pix_fmt'],'audioCodec':a[0]['codec_name'],'audioStreams':len(a),'duration':float(p['format']['duration']),'originalDecodedAudioDuration':len(voice)/sr,'narrationSpeed':1,'framesExpected':expected,'framesDecoded':len(lum),'allPngDimensionsVerified':True,'noMissingCutFrames':True,'minFramePeakLuma':min(lum),'rig':rig,'plantedFootPixelDifference':footdiff,'voiceCorrelationSamples':cor,'voiceAlignmentLagSeconds':lags,'sha256':hashlib.sha256(open(video,'rb').read()).hexdigest(),'bytes':os.path.getsize(video),'inspection':'Visual contact sheet and dense gesture sequence inspected. Full real-time audiovisual playback was not performed. Captions are automatic local transcription + forced alignment.'}
json.dump(r,open('manifests/validation.json','w'),indent=2);json.dump(r,open(out+'/validation.json','w'),indent=2);print(json.dumps(r,indent=2))
