import json,os,hashlib,glob,zipfile,shutil
from pathlib import Path
from urllib.parse import quote
out=Path(os.environ.get('ELEVATOR_OUTPUT','/workspace/work/output/Bradikinin'))
cfg=json.load(open('manifests/timeline.json'));v=json.load(open('manifests/validation.json'));title=cfg['title']
versions=json.load(open('manifests/versions.json'));versions['rendererSHA256']=hashlib.sha256(open('src/node/renderer.js','rb').read()).hexdigest();json.dump(versions,open('manifests/versions.json','w'),indent=2)
readme=f'''# {title}

[Baixar o MP4 em 1080p]({quote(title+'.mp4')}?raw=true)

- Duração: {v['duration']:.3f} s (aproximadamente 4min39s).
- Resolução: 1920×1080, 30 fps; H.264/yuv420p; AAC 192 kb/s; faststart.
- Narração original, uma única vez, na velocidade original; música local original e efeitos em cache.
- [Prévia de 14 segundos](preview.mp4?raw=true), [folha de contato](contact-sheet.jpg), [projeto reproduzível](elevator-source.zip?raw=true), [relatório](report.md).
- Legendas automáticas locais: arquivo SRT ao lado do MP4; podem conter erros de reconhecimento.

Para baixar no GitHub, abra o arquivo e use **Download raw file**. O ZIP do projeto requer o MP3 original já fornecido pelo usuário; o original e a referência não foram publicados separadamente.

SHA-256 do MP4: `{v['sha256']}`.
'''
(out/'README.md').write_text(readme)
report=f'''# Relatório de produção

Episódio: **{title}**. Produção em 16/10/2026 (data do cliente, America/Sao_Paulo).

## Inputs e privacidade

O TXT anexado inicia na etapa de verificação de prévia e contém as seções 15–18 e um pedido reutilizável. Foi seguido como guia de produção. O nome de saída e o pedido posterior de 1080p do usuário substituem o nome de exemplo sobre micro-ondas.

O roteiro foi extraído do MP3 anexado por Whisper base.en local, usando sherpa-onnx 1.13.8; as palavras foram alinhadas localmente com PocketSphinx 5.0.4. Nenhum envio de áudio a serviço de transcrição ocorreu. A tentativa de preparar esse envio foi bloqueada antes da execução pela revisão automática; após o usuário optar por processamento local, baixou-se apenas o modelo público. Os hashes dos três inputs constam em `manifests/inputs.json` do projeto. Originais preservados em attachments; a referência não foi usada como fonte de imagem nem de áudio no episódio.

## Resultado e escolhas visuais

{len(cfg['scenes'])} cenas originais em Canvas 2D: painel, cabine, espelho, carrinho, corredor, etiquetas e encerramento. Fundo preto, figuras brancas, linhas simples, acentos amarelo/vermelho/verde e ruído discreto seguem a linguagem da referência. A encenação mantém os humanos em poses estáveis, com movimentos pequenos de braço. O protagonista permanece dentro da cabine nas vistas do corredor. Não há ragdoll, deformação de tronco ou alongamento de membros.

Final: {v['resolution'][0]}×{v['resolution'][1]}, 30 fps, {v['framesDecoded']} frames, {v['duration']:.6f} s, {v['bytes']/1048576:.2f} MiB. O MP3 tem duração de contêiner de 278.648163 s; a fala decodificada cobre {v['originalDecodedAudioDuration']:.6f} s. O mix foi preenchido até a duração de contêiner. A quantização do vídeo em 30 fps explica os milissegundos adicionais. Nenhum fim de fala foi cortado.

## Música e efeitos

Música original sintetizada localmente em Python/NumPy, seed 42017, três stems separados e mix de música. Drone grave e pulsos discretos com fades de entrada/saída. Cinco efeitos ElevenLabs gerados a partir de descrições de texto: campainha, portas, motor, batidas e botão. Consumo informado pelo provedor: **180 créditos**, somados dos cabeçalhos `character-cost`; não se infere cobrança monetária. Sete colocações na timeline reutilizam esses cinco arquivos. Prompts, posições, ganhos e hashes estão nos manifests e nos metadados do cache. Render e mix não fazem novas chamadas pagas.

A voz foi importada uma única vez, sem alteração de velocidade; o vídeo de referência não entra no grafo de áudio. Música e efeitos usam níveis contidos. O mix usa limiter a 0,95, sem ganho automático de normalização. Não houve audição humana integral do mix, portanto não se declara avaliação perceptual completa de clareza ou naturalidade.

## Verificações automáticas executadas

- Todos os {v['framesExpected']} PNGs finais existem, têm dimensões 1920×1080 e pertencem a intervalos semiabertos contíguos, sem cortes duplicados.
- Decodificação integral do MP4 com FFmpeg `-xerror` concluída. Uma única faixa AAC e vídeo H.264/yuv420p a 30 fps.
- Conteúdo claro presente em cada frame: menor pico de luminância amostrado a 480×270 = {v['minFramePeakLuma']:.0f}; nenhum frame vazio/preto acidental detectado por esse critério.
- Maior erro numérico no comprimento dos segmentos: {v['rig']['maxLengthError']:.3g} unidades; alvos IK inalcançáveis: {v['rig']['unreachableTargets']}.
- Pixels da região dos pés idênticos no começo, meio e fim do gesto de apoio: diferença máxima {v['plantedFootPixelDifference']}. Esse teste cobre o gesto representativo; não é uma prova geral de anatomia.
- Correlação da voz original com o áudio AAC final em oito trechos: mínimo {min(v['voiceCorrelationSamples']):.4f}; maior desvio temporal medido {max(abs(x)for x in v['voiceAlignmentLagSeconds'])*1000:.3f} ms. Isso verifica preservação temporal nesses pontos, sem prometer alinhamento perfeito de todas as palavras das legendas.
- SHA-256 local: `{v['sha256']}`.

## Inspeção visual e limites

A folha de contato da referência foi examinada; depois, poses de início/meio/fim e uma sequência densa do gesto de apoio foram inspecionadas visualmente. Corrigiram-se braços em repouso, flexão dos joelhos e o símbolo de pessoa deitada. Foi produzido também um trecho a 960×540 e 30 fps. A prévia entregue tem 14 segundos de dois trechos do MP4 final.

Não houve reprodução audiovisual integral em tempo real. As legendas são uma transcrição automática alinhada localmente e podem conter erros de palavras ou pontuação. A estética é de pictogramas e movimentos contidos; não se promete realismo humano. Os números do teste de IK não constituem aprovação estética ou anatômica por si só.

## Reprodutibilidade e exportação

O ZIP inclui JavaScript, scripts Python, versões, seed, timeline, transcrição/alinhamento, manifests, legendas, efeitos em cache e stems musicais. Exclui o áudio original, o vídeo de referência, mix com voz, modelos, frames temporários, node_modules e segredos. A reprodução com voz requer o MP3 original que o usuário já forneceu. O README do projeto contém comandos implementados e uma orquestração completa sem novas gerações pagas.

A raiz de saída `/codex/browser/projectless/0005-files-mentioned-by-the-user-uploaded-file-pointe/output` não pôde ser criada neste executor (diretório pai sem permissão). Os arquivos foram produzidos em `/workspace/work/output/Bradikinin` para exportação binária ao repositório conectado. O checkout original permanece preservado; usa-se um clone exclusivo do mesmo remoto para a entrega em uma nova branch, sem force push. A publicação só é considerada concluída após o push e a conferência posterior do payload remoto; consulte a resposta final para o estado real da exportação.
'''
(out/'report.md').write_text(report)
Path('proof').mkdir(exist_ok=True)
if Path('/workspace/work/gesture-dense.jpg').exists():shutil.copyfile('/workspace/work/gesture-dense.jpg','proof/gesture-dense.jpg')
with zipfile.ZipFile(out/'elevator-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in [Path('README.md'),Path('package.json'),Path('package-lock.json'),Path('requirements.txt'),Path('.gitignore'),Path('captions.srt')]:z.write(p,Path('elevator')/p)
 for folder in ['src','manifests','assets/audio/music','assets/audio/sfx','proof']:
  for p in Path(folder).rglob('*'):
   if p.is_file():z.write(p,Path('elevator')/p)
 z.write(out/'report.md','elevator/report.md')
lines=[]
for p in sorted(out.iterdir()):
 if p.is_file()and p.name not in ['SHA256SUMS.txt','export.json']:lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(out/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
print('Delivery packaged:',out)
for p in out.iterdir():print(p.name,p.stat().st_size)
