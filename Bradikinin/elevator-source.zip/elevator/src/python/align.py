"""Force-align locally recognized text against the original audio with PocketSphinx."""
import json,re,wave
from pocketsphinx import Decoder
chunks=json.load(open('manifests/transcript-local.json'))
with wave.open('work/narration16.wav','rb') as w:pcm=w.readframes(w.getnframes());sr=w.getframerate()
d=Decoder(samprate=16000,loglevel='ERROR')
out=[]
for ch in chunks:
 txt=re.sub(r'\([^)]*\)','',ch['text'].lower())
 txt=re.sub(r'[^a-z0-9\s\']',' ',txt)
 for k,v in {'1':'one','2':'two','3':'three','4':'four','5':'five','6':'six','7':'seven'}.items():txt=re.sub(r'\b'+k+r'\b',v,txt)
 words=txt.split();unknown=[w for w in words if not d.lookup_word(w)]
 if unknown:raise ValueError('OOV '+str(unknown))
 d.set_align_text(' '.join(words));d.start_utt();d.process_raw(pcm[int(ch['start']*sr)*2:int(ch['end']*sr)*2],False,True);d.end_utt()
 ss=[]
 for s in d.seg():
  if s.word.startswith('<')or s.word.startswith('['):continue
  ss.append({'word':s.word,'start':ch['start']+s.start_frame/100,'end':ch['start']+(s.end_frame+1)/100})
 out+=ss;print(round(ch['start'],2),len(ss),'words aligned',flush=True)
json.dump(out,open('manifests/words.json','w'),indent=2)
