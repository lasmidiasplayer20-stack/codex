import json,re,math
w=json.load(open('manifests/words.json'))
for x in w:x['word']=re.sub(r'\(\d+\)$','',x['word'])
def at(phrase,after=0):
 q=phrase.lower().split()
 for i in range(len(w)-len(q)+1):
  if w[i]['start']>=after and [x['word'] for x in w[i:i+len(q)]]==q:return w[i]['start']
 raise ValueError((phrase,after))
sc=[]
def scene(phrase,type,after=0,**kw):
 start=0 if phrase is None else at(phrase,after)
 sc.append(dict(start=start,type=type,**kw))
scene(None,'title')
scene('do not photograph','panel',action='avoid')
scene('the button will usually','panel')
scene('there are seven rules','diagram',items=['01 — 07','YOUR NAME','DO NOT PRESS'])
scene('rule one','rule',rule=1,label='Keep your hands away')
scene('keep your hands','panel',action='reach')
scene('your name may already','panel',action='avoid')
scene('look above the doors','screen',label='COLLECTION ACCEPTED',danger=True)
scene('do not press cancel','panel',action='cancel')
scene('rule two','rule',rule=2,label='Do not confirm your details')
scene('the screen may ask','screen',label='ARE YOU THE PERSON LISTED?',action='confirm')
scene('the question is not','screen',label='CAN THE CONTENTS RESPOND?',danger=True)
scene('the wait display','screen',label='WEIGHT',action='weight')
scene('do not remove your coat','cab',pose='stand',display='WEIGHT')
scene('weight adjustments','screen',label='MISSING ITEMS',danger=True)
scene('rule three','rule',rule=3,label='Face the doors')
scene('the mirror will show','cab',action='mirror')
scene('do not turn around','cab',action='mirror')
scene('a white rectangle','cab',action='label',label='↑')
scene('if you can make out','cab',action='label',label='↑')
scene('if the label changes','cab',action='label',label='!')
scene('someone has noticed','screen',label='MOVEMENT DETECTED',danger=True)
scene('rule four','rule',rule=4,label='Do not ask which floor')
scene('the elevator may travel','cab',display='…')
scene('hold the rail','cab',pose='rail',display='…')
scene('the floor display','screen',label='ROUTE',action='names')
scene('do not say that you know','screen',label='DO NOT IDENTIFY THEM',action='names')
scene('rule five','rule',rule=5,label='Do not help with the trolley')
scene('at the next opening','trolley')
scene('stay beside the panel','trolley',action='avoid',settled=True)
scene('if they ask you to hold','trolley',action='clipboard',settled=True)
scene('you will notice the first','clipboard')
scene('all were marked','clipboard',action='delivered')
scene('rule six','rule',rule=6,label='Do not leave when you hear arrived')
scene('the doors may open','hall',action='mat',shadow=True)
scene('someone will be waiting','hall',shadow=True)
scene('look at the number','hall',shadow=True,action='name')
scene('the person will look','cab',action='label',label='↑')
scene('rule seven','rule',rule=7,label='Say: wrong address')
scene('say wrong address','hall',shadow=True,action='wrong',after=207)
scene('do not explain','diagram',items=['NO DETAILS','NO APOLOGY','NO ADDRESS'])
scene('the person with a pen','hall',shadow=True)
scene('wait','hall',shadow=True,after=222)
scene('if they ask whether','hall',shadow=True)
scene('they will eventually draw','clipboard',action='strike')
scene('only then may you press','panel',name='blank',action='ground')
scene('leave the building','door',action='exit')
scene('before going home','label')
scene('fold it inward','label',action='fold')
scene('place it beneath','label',action='heavy')
scene('the office of household','screen',label='RETURN CONFIRMED')
scene('you may use the stairs','stairs')
scene('if someone knocks tonight','door',waves=True,action='close')
scene('they will ask when','door',action='close',waves=True)
scene('do not give them a time','end')
sc.sort(key=lambda x:x['start'])
duration=278.648163;fps=30;current=0
for i,s in enumerate(sc):
 s['id']=f'{i+1:02d}-{s["type"]}'
 s['end']=sc[i+1]['start'] if i+1<len(sc) else duration
 if s['type']=='rule':current=s['rule']
 else:s['rule']=current
 s['firstFrame']=math.ceil(s['start']*fps);s['endFrameExclusive']=math.ceil(s['end']*fps)
caps=[];group=[]
for i,x in enumerate(w):
 group.append(x);nxt=w[i+1] if i+1<len(w) else None
 if len(group)>=9 or (nxt and nxt['start']-x['end']>.22) or not nxt:
  if group:
   caps.append({'start':group[0]['start'],'end':min(duration,(nxt['start'] if nxt else x['end']+.5)),'text':' '.join(y['word'] for y in group)})
  group=[]
config={'title':"If Your Elevator Shows Your Name, Don't Press It",'fps':fps,'width':1920,'height':1080,'previewWidth':960,'previewHeight':540,'duration':duration,'frameCount':math.ceil(duration*fps),'intervalConvention':'[firstFrame, endFrameExclusive); no duplicated cut frames','seed':42017,'scenes':sc,'captions':caps,'captionMethod':'Local Whisper base.en transcription with local PocketSphinx word alignment. Automatic text; not a human-verified transcript.'}
json.dump(config,open('manifests/timeline.json','w'),indent=2)
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
with open('captions.srt','w') as f:
 for i,x in enumerate(caps):f.write(f'{i+1}\n{stamp(x["start"])} --> {stamp(x["end"])}\n{x["text"]}\n\n')
print(f'{len(sc)} scenes, {len(caps)} caption groups, {config["frameCount"]} frames')
for s in sc:print(s['id'],round(s['start'],2),round(s['end'],2),s.get('label',''))
