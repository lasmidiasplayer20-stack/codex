"""Place cached sound effects on the local timeline; never calls a service."""
import json,subprocess,wave,os,numpy as np
cfg=json.load(open('manifests/timeline.json'));sr=44100;n=int(np.ceil(cfg['duration']*sr));mix=np.zeros((n,2),np.float32)
events=[{'sound':'ding','time':28.21,'peak':.045},{'sound':'hum','time':113.65,'peak':.023}, {'sound':'doors','time':141.51,'peak':.042},{'sound':'ding','time':178.85,'peak':.035},{'sound':'doors','time':178.85,'peak':.038},{'sound':'click','time':239.2,'peak':.036},{'sound':'knock','time':267.0,'peak':.040}]
os.makedirs('work/decoded-sfx',exist_ok=True)
for e in events:
 p=f'work/decoded-sfx/{e["sound"]}.wav'
 if not os.path.exists(p):subprocess.run(['ffmpeg','-v','error','-y','-i',f'assets/audio/sfx/{e["sound"]}.mp3','-ar',str(sr),'-ac','2',p],check=True)
 with wave.open(p) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,2)/32768
 x*=e['peak']/max(np.max(np.abs(x)),1e-6)
 fade=min(len(x)//2,int(.03*sr));x[:fade]*=np.linspace(0,1,fade)[:,None];x[-fade:]*=np.linspace(1,0,fade)[:,None]
 a=round(e['time']*sr);ln=min(len(x),n-a);mix[a:a+ln]+=x[:ln]
with wave.open('assets/audio/effects.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
json.dump({'events':events,'referenceAudioUsed':False,'narrationCopies':1,'narrationSpeed':1,'apiCallsDuringMix':0},open('manifests/audio-mix.json','w'),indent=2)
print('Cached effects placed:',len(events))
