"""Original deterministic ambient score; standard wave + NumPy, seed 42017."""
import numpy as np,wave,json,os
T=278.648163;sr=22050;n=int(np.ceil(T*sr));t=np.arange(n)/sr;rng=np.random.default_rng(42017)
os.makedirs('assets/audio/music',exist_ok=True)
def save(name,x):
 x=np.asarray(x);x=np.stack([x,x],axis=1) if x.ndim==1 else x
 with wave.open('assets/audio/music/'+name+'.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
fade=np.minimum(np.clip(t/5,0,1),np.clip((T-t)/6,0,1))
pad=np.zeros(n);air=np.zeros(n);pulse=np.zeros(n)
for k,f in enumerate([55,82.4069,110,116.5409]):
 amp=(.003 if k==3 else .006)*(0.75+.25*np.sin(2*np.pi*(.013+k*.003)*t+k))
 pad+=amp*np.sin(2*np.pi*f*t+.6*np.sin(2*np.pi*.021*t+k))
air=.0018*(np.sin(2*np.pi*432*t)+np.sin(2*np.pi*436*t))*(.5+.5*np.sin(2*np.pi*.017*t))
for onset in np.arange(12,T-8,3.6):
 a=int(onset*sr);length=min(n-a,2*sr);u=np.arange(length)/sr
 pulse[a:a+length]+=.010*np.sin(2*np.pi*(44*u+8*(1-np.exp(-u*4))))*np.exp(-u*4)*(1-np.exp(-u*35))
pad*=fade;air*=fade;pulse*=fade
save('01-drone',pad);save('02-air',air);save('03-pulse',pulse)
save('music',np.stack([pad+air+pulse,pad+.92*air+pulse],axis=1))
json.dump({'seed':42017,'sampleRate':sr,'duration':T,'notesHz':[55,82.4069,110,116.5409],'peak':float(np.max(np.abs(pad+air+pulse))),'stems':['01-drone.wav','02-air.wav','03-pulse.wav'],'description':'Subdued original ambient drone, slow phase movement, restrained low pulse; 5s fade in / 6s fade out.'},open('manifests/music.json','w'),indent=2)
print('Music and three stems rendered locally.')
