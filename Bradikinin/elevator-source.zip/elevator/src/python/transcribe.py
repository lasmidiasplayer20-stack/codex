"""Local-only speech recognition. No recording leaves the execution environment."""
import json,re,os,sys,time
import numpy as np
import sherpa_onnx
import soundfile as sf
audio,sr=sf.read('work/narration16.wav')
root=os.environ.get('ELEVATOR_MODEL_DIR','work/model')
r=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=root+'/base.en-encoder.int8.onnx',decoder=root+'/base.en-decoder.int8.onnx',tokens=root+'/base.en-tokens.txt',num_threads=4,language='en',task='transcribe',tail_paddings=1000)
# Split on detected silence, no chunks over 22s. Whole words remain inside chunks.
s=open('work/silences.txt').read()
sil=[float(x) for x in re.findall(r'silence_end: ([0-9.]+)',s)]
ends=[];start=0;T=len(audio)/sr
while start<T:
 cand=[x for x in sil if start+12<x<start+23]
 end=max(cand) if cand else min(T,start+20)
 if T-end<3:end=T
 ends.append((start,end));start=end
out=[]
for a,b in ends:
 st=r.create_stream();st.accept_waveform(sr,audio[int(a*sr):int(b*sr)]);r.decode_stream(st)
 d={'start':a,'end':b,'text':st.result.text,'tokens':st.result.tokens,'timestamps':st.result.timestamps}
 out.append(d);print(f'{a:.2f}-{b:.2f}: {d["text"]}',flush=True)
 json.dump(out,open('manifests/transcript-local.json','w'),indent=2)
