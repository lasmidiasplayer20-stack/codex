import {EnvHttpProxyAgent,setGlobalDispatcher} from 'undici';
import fs from 'node:fs';
import crypto from 'node:crypto';
setGlobalDispatcher(new EnvHttpProxyAgent());
const plan=[
 {id:'ding',duration:2,prompt:'A single eerie old elevator arrival bell, short clean metallic ding with a soft decay, isolated sound effect, no speech, no music.'},
 {id:'doors',duration:4,prompt:'Heavy old elevator sliding doors opening then stopping, subdued mechanical rollers, metal friction and a small latch, isolated, no voices, no music.'},
 {id:'hum',duration:8,prompt:'Quiet unsettling elevator motor and fluorescent electrical hum, continuous steady soft low mechanical room tone, no voices, no music, no loud hits.'},
 {id:'knock',duration:3,prompt:'Three slow soft knocks against a thick metal elevator door, dry hollow metal taps, isolated sound effect, no voices, no music.'},
 {id:'click',duration:1,prompt:'One short clean elevator push button click with a tiny electrical relay tick, isolated, no speech, no music.'}
];
fs.mkdirSync('assets/audio/sfx',{recursive:true});fs.writeFileSync('manifests/effects-plan.json',JSON.stringify(plan,null,2));
for(const p of plan){const path=`assets/audio/sfx/${p.id}.mp3`;if(fs.existsSync(path)){console.log('cached',p.id);continue}const res=await fetch('https://api.elevenlabs.io/v1/sound-generation',{method:'POST',headers:{'xi-api-key':process.env.ELEVENLABS_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({text:p.prompt,duration_seconds:p.duration,prompt_influence:.4})});if(!res.ok)throw Error(`${p.id}: ${res.status} ${(await res.text()).slice(0,250)}`);const b=Buffer.from(await res.arrayBuffer());fs.writeFileSync(path,b);const meta={id:p.id,sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length,requestId:res.headers.get('request-id'),characterCost:res.headers.get('character-cost'),consumptionReported:res.headers.get('character-cost')!==null};fs.writeFileSync(`assets/audio/sfx/${p.id}.json`,JSON.stringify(meta,null,2));console.log('generated',p.id,b.length)}
