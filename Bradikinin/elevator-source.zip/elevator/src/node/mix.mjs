import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
const cfg=JSON.parse(fs.readFileSync('manifests/timeline.json'));
execFileSync('ffmpeg',['-v','error','-y','-i','assets/audio/narration.wav','-i','assets/audio/music/music.wav','-i','assets/audio/effects.wav','-filter_complex','[0:a]apad,atrim=duration='+cfg.duration+'[voice];[voice][1:a][2:a]amix=inputs=3:duration=longest:normalize=0,alimiter=limit=0.95:level=false:latency=true,atrim=duration='+cfg.duration+'[mix]','-map','[mix]','-ar','44100','-c:a','pcm_s16le','assets/audio/mix.wav'],{stdio:'inherit'});
console.log('Mixed original-speed narration once, music and cached effects.');
