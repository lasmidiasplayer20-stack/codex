import {execFileSync} from 'node:child_process';
const run=(cmd,args)=>execFileSync(cmd,args,{stdio:'inherit'});
// Intentionally uses cached effects. New API generation is a separate manual command.
run('python',['src/python/music.py']);run('python',['src/python/sfx_mix.py']);run('node',['src/node/mix.mjs']);run('node',['src/node/render.mjs']);run('node',['src/node/assemble.mjs']);run('python',['src/python/validate.py']);run('python',['src/python/delivery.py']);run('python',['src/python/package_delivery.py']);
