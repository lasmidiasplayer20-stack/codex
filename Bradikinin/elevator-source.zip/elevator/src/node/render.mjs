import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import puppeteer from 'puppeteer-core';
const config=JSON.parse(fs.readFileSync('manifests/timeline.json'));
const FPS=config.fps;
const args=process.argv.slice(2),preview=args.includes('--preview'),audit=args.includes('--audit'),draft=args.includes('--draft');
const mode=audit?'audit':preview?'preview':draft?'draft':'render';
const renderRoot=audit?'renders-audit':preview?'renders-preview':draft?'renders-draft':'renders-final';
const only=args.find(s=>s.startsWith('--scene='))?.split('=')[1];
const scenes=only?config.scenes.filter(s=>s.id===only):config.scenes;
fs.mkdirSync(renderRoot,{recursive:true});fs.mkdirSync('work/chromium-'+mode,{recursive:true});
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,pipe:true,userDataDir:path.resolve('work/chromium-'+mode),args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run'],env:{...process.env,XDG_CONFIG_HOME:path.resolve('work/config'),XDG_CACHE_HOME:path.resolve('work/cache')}});
const width=(preview||audit||draft)?960:1920,height=width*9/16;
const page=await browser.newPage();await page.setViewport({width,height,deviceScaleFactor:1});
await page.setContent('<!DOCTYPE html><meta charset="utf-8"><style>body{margin:0;background:#070808}canvas{display:block}</style><canvas width="960" height="540"></canvas>');
await page.addScriptTag({content:fs.readFileSync('node_modules/matter-js/build/matter.min.js','utf8')});
await page.addScriptTag({content:fs.readFileSync('src/node/renderer.js','utf8')});
await page.evaluate(({width,height})=>{canvas.width=width;canvas.height=height;c.setTransform(width/960,0,0,height/540,0,0)},{width,height});
let errors=0,maxLengthError=0,maxReachError=0;
try{
for(const s of scenes){
 fs.mkdirSync(`${renderRoot}/${s.id}`,{recursive:true});
 let frames=[];
 if(audit){for(let f=Math.ceil(s.start*FPS);f<Math.min(Math.ceil(s.end*FPS),Math.ceil(s.start*FPS)+180);f+=3)frames.push(f)}
 else if(preview){for(const p of [.05,.25,.5,.75,.95])frames.push(Math.floor((s.start+(s.end-s.start)*p)*FPS))}
 else{for(let f=Math.ceil(s.start*FPS);f<Math.ceil(s.end*FPS);f++)frames.push(f)}
 for(const f of frames){const dest=`${renderRoot}/${s.id}/${String(f).padStart(7,'0')}.png`;if(fs.existsSync(dest)&&!preview&&!audit)continue;const r=await page.evaluate(({time,scene,caps})=>{const g=window.draw(time,scene,caps);return {image:document.querySelector('canvas').toDataURL('image/png').split(',')[1],geometry:g}},{time:f/FPS,scene:s,caps:config.captions});
 for(const g of r.geometry){maxLengthError=Math.max(maxLengthError,Math.abs(g.length1-g.expected[0]),Math.abs(g.length2-g.expected[1]));maxReachError=Math.max(maxReachError,g.requestedError);if(g.requestedError>.05)errors++}
 fs.writeFileSync(dest,Buffer.from(r.image,'base64'));
 }
 console.log(s.id,frames.length,'frames',preview?'preview':audit?'audit':'render');
}
}finally{await browser.close()}
fs.writeFileSync(`manifests/rig-${mode}${only?'-'+only:''}.json`,JSON.stringify({maxLengthError,maxReachError,unreachableTargets:errors,mode,fps:FPS},null,2));
if(errors)throw Error(`Unreachable IK targets: ${errors}`);
