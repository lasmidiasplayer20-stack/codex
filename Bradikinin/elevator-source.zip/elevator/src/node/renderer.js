/* Deterministic 2D scene renderer. Every limb is a rigid, fixed-length segment. */
const canvas=document.querySelector('canvas'),c=canvas.getContext('2d',{alpha:false});
const W=960,H=540,WHITE='#f3f3ed',RED='#e84545',YELLOW='#edca65',GREEN='#78ce92',BG='#070808';
let geometry=[];
// Physics is restricted to the empty trolley. Human poses never use ragdoll physics.
const trolleyMotion=(()=>{const {Engine,Bodies,Body,Composite}=Matter,e=Engine.create({gravity:{x:0,y:0}}),b=Bodies.rectangle(0,0,139,12,{frictionAir:.035});Composite.add(e.world,b);Body.setVelocity(b,{x:-3.45,y:0});const a=[0];for(let i=0;i<180;i++){Engine.update(e,1000/60);a.push(-b.position.x)}const end=a[a.length-1];return a.map(x=>x/end)})();
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
const lerp=(a,b,t)=>a+(b-a)*t;
function line(a,b,color=WHITE,width=3){c.beginPath();c.moveTo(...a);c.lineTo(...b);c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke()}
function path(p,color=WHITE,width=3,fill=null){c.beginPath();p.forEach((v,i)=>i?c.lineTo(...v):c.moveTo(...v));if(fill){c.closePath();c.fillStyle=fill;c.fill()}c.strokeStyle=color;c.lineWidth=width;c.lineJoin='round';c.stroke()}
function box(x,y,w,h,col=WHITE,lw=3,r=3,fill=null){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill()}c.strokeStyle=col;c.lineWidth=lw;c.stroke()}
function circle(x,y,r,col=WHITE,fill=true,lw=3){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=col;c.strokeStyle=col;c.lineWidth=lw;fill?c.fill():c.stroke()}
function text(s,x,y,size=20,col=WHITE,align='center',font='Arial'){c.fillStyle=col;c.font=`${size>=24?'700':'500'} ${size}px ${font}`;c.textAlign=align;c.textBaseline='middle';c.fillText(s,x,y)}
function multiline(s,x,y,size=23,col=WHITE,max=800){const words=s.split(/\s+/),lines=[];let l='';c.font=`700 ${size}px Arial`;for(const w of words){if(c.measureText(l+' '+w).width>max&&l){lines.push(l);l=w}else l+=(l?' ':'')+w}if(l)lines.push(l);lines.forEach((v,i)=>text(v,x,y+(i-(lines.length-1)/2)*(size+8),size,col))}
function cross(x,y,r=16){line([x-r,y-r],[x+r,y+r],RED,4);line([x+r,y-r],[x-r,y+r],RED,4)}
function check(x,y){circle(x,y,17,GREEN);line([x-7,y],[x-1,y+6],BG,3);line([x-1,y+6],[x+9,y-7],BG,3)}
function ik(a,target,l1,l2,bend=1){const dx=target[0]-a[0],dy=target[1]-a[1],raw=Math.hypot(dx,dy),d=clamp(raw,Math.abs(l1-l2)+0.001,l1+l2-0.001),u=[dx/(raw||1),dy/(raw||1)],along=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-along*along));const joint=[a[0]+u[0]*along-u[1]*h*bend,a[1]+u[1]*along+u[0]*h*bend],end=[a[0]+u[0]*d,a[1]+u[1]*d];geometry.push({length1:Math.hypot(joint[0]-a[0],joint[1]-a[1]),length2:Math.hypot(end[0]-joint[0],end[1]-joint[1]),expected:[l1,l2],requestedError:Math.hypot(end[0]-target[0],end[1]-target[1])});return [a,joint,end]}
function limb(points,w){for(let i=1;i<points.length;i++){line(points[i-1],points[i],BG,w+4);line(points[i-1],points[i],WHITE,w)}circle(points[1][0],points[1][1],w/2,WHITE)}
function human(x,floor,t,{scale=1,pose='stand',motion=0,flip=false,dim=false}={}){
 c.save();c.translate(x,floor);c.scale((flip?-1:1)*scale,scale);if(dim)c.globalAlpha=.30;
 const walk=pose==='walk',speed=38,period=1.25,step=speed*period/2;
 let rootX=0,hipY=-88,feet=[[-10,0],[10,0]];
 if(walk){rootX=motion*speed;hipY=-83-1.4*Math.cos(motion/period*4*Math.PI);feet=[0,.5].map(offset=>{const cycles=motion/period+offset,k=Math.floor(cycles),p=cycles-k;const anchor=k*2*step-offset*2*step;return p<.5?[anchor,0]:[anchor+2*step*ease((p-.5)*2),-13*Math.sin((p-.5)*2*Math.PI)]})}
 const hip=[rootX,hipY],shoulder=[rootX,-147],head=[rootX,-177];
 const legs=feet.map(f=>ik(hip,f,46,43,-1));legs.forEach(p=>{limb(p,12);line(p[2],[p[2][0]+10,p[2][1]],WHITE,10)});
 const sway=walk?Math.sin(motion/period*2*Math.PI)*14:0;
 let hands=pose==='rail'?[[rootX-13,-77],[rootX+56,-131]]:pose==='stop'?[[rootX-13,-77],[rootX+51,-151]]:pose==='point'?[[rootX-13,-77],[rootX+66,-139]]:pose==='cover'?[[rootX-18,-167],[rootX+18,-167]]:pose==='knock'?[[rootX-13,-77],[rootX+54+3*Math.sin(t*7),-137]]:[[rootX-13+sway,walk?-84:-77],[rootX+13-sway,walk?-84:-77]];
 if(!walk){let u=ease(t/1.2);hands=hands.map((p,i)=>[lerp(rootX+(i?13:-13),p[0],u),lerp(-77,p[1],u)])}
 limb(ik([shoulder[0]-5,shoulder[1]+3],hands[0],35,33,1),9);
 line([rootX,-140],[rootX,-91],BG,27);line([rootX,-140],[rootX,-91],WHITE,23);
 limb(ik([shoulder[0]+5,shoulder[1]+3],hands[1],35,33,pose==='stand'||walk?-1:1),9);
 line([rootX,-152],[rootX,-159],WHITE,9);circle(...head,14,WHITE);c.restore();
}
function elevator(x=520,y=105,w=240,h=273,open=0,display='12',danger=false){
 box(x-12,y-12,w+24,h+12,'#3b4140',2,2);box(x,y,w,h,WHITE,3,1);c.save();c.beginPath();c.rect(x,y,w,h);c.clip();c.fillStyle='#121616';c.fillRect(x,y,w,h);box(x+25,y+28,w-50,h-28,'#444c49',2);line([x,y+h],[x+w,y+h],WHITE,3);
 c.fillStyle='#0c0e0e';const gap=w*.47*open;c.fillRect(x,y,w/2-gap,h);c.fillRect(x+w/2+gap,y,w/2-gap,h);line([x+w/2-gap,y],[x+w/2-gap,y+h],WHITE,2);line([x+w/2+gap,y],[x+w/2+gap,y+h],WHITE,2);c.restore();
 box(x+w/2-47,y-49,94,29,danger?RED:'#646c68',2,2,BG);text(display,x+w/2,y-34,display.length>6?12:17,danger?RED:YELLOW);box(x+w+24,y+112,27,61,'#6b726e',2);circle(x+w+37.5,y+131,5,YELLOW,false,2);circle(x+w+37.5,y+153,5,WHITE,false,2);
}
function panel(scene,t){box(319,85,322,306,'#5c6460',2,9,'#101312');text('FLOOR SELECT',480,110,11,'#7d8981','center','monospace');const labels=['12','11','10','09','08','07','06','05','G'];labels.forEach((v,i)=>{const x=380+(i%3)*100,y=151+Math.floor(i/3)*60;box(x-27,y-19,54,38,scene.action==='ground'&&v==='G'?GREEN:WHITE,2,5);text(v,x,y,19)});const active=scene.name!=='blank';box(348,319,264,43,active?RED:'#626b65',2,5);text(active?'YOUR NAME':'',480,341,22,active?RED:WHITE);if(scene.action==='avoid'){cross(694,341);line([650,341],[672,341],RED,2)}
}
function hallway(){box(385,85,444,293,WHITE,3,1);path([[385,378],[510,287],[758,287],[829,378]],'#303833',1);box(626,119,130,259,'#89918b',2,1);circle(739,260,3,WHITE);line([171,378],[385,378],'#5f6863',2);text('12',480,64,17,YELLOW);text('INSIDE',260,120,11,'#6d786e');}
function soundWaves(x,y,t,col=WHITE){for(let k=0;k<3;k++){c.beginPath();c.arc(x,y,24+k*19,Math.PI*1.72,Math.PI*2.28);c.strokeStyle=col;c.globalAlpha=.3+.45*(.5+.5*Math.sin(t*2-k));c.lineWidth=2;c.stroke()}c.globalAlpha=1}
function iconPhone(x,y){box(x-24,y-42,48,84,WHITE,3,7);line([x-7,y+30],[x+7,y+30],WHITE,2);circle(x,y-30,2,WHITE)}
function render(time,scene,captions){
 geometry=[];const t=time-scene.start,d=scene.end-scene.start,p=clamp(t/d),reveal=ease(t/.7);c.fillStyle=BG;c.fillRect(0,0,W,H);
 c.save();c.globalAlpha=.7;text('FILE 042  //  BRADIKININ',46,32,10,'#78837d','left','monospace');text(new Date(time*1000).toISOString().slice(11,19)+':'+String(Math.floor(time*30)%30).padStart(2,'0'),913,32,10,'#78837d','right','monospace');c.restore();
 let cutTitle=scene.type==='rule';
 if(scene.type==='title'){elevator(574,144,185,230,.12,'YOUR NAME',true);human(354,375,t,{pose:'stop',scale:1.02});text('IF YOUR ELEVATOR',480,76,25);text('SHOWS YOUR NAME',480,108,25,YELLOW);}
 else if(scene.type==='panel'){panel(scene,t);if(scene.action==='reach'){human(210,390,t,{pose:'stop',scale:.95});cross(300,237)}if(scene.action==='cancel'){box(663,198,96,73,RED,2);circle(739,234,6,WHITE);line([713,234],[728,234],WHITE,7);path([[713,234],[700,234],[685,234]],WHITE,4);path([[713,236],[700,245],[687,245]],WHITE,4);path([[725,235],[720,247],[709,247]],WHITE,3);cross(789,234)}}
 else if(scene.type==='rule'){text('RULE',410,182,58);box(511,148,70,70,WHITE,3,7,WHITE);text(String(scene.rule),546,185,57,BG);line([338,239],[622,239],RED,2);multiline(scene.label.toUpperCase(),480,278,24);for(let i=1;i<=7;i++){box(381+(i-1)*28,338,21,23,i===scene.rule?WHITE:'#555c57',1,2,i===scene.rule?WHITE:null);text(String(i),391+(i-1)*28,350,12,i===scene.rule?BG:'#758079')}}
 else if(scene.type==='hall'){hallway();if(scene.action==='mat'){box(642,373,148,25,'#8d9690',2,2,BG);text('WELCOME',716,385,12)}human(268,378,t,{pose:scene.pose||'stand'});if(scene.shadow){human(698,377,t,{scale:.94});line([730,236],[739,219],YELLOW,3)}if(scene.waves)soundWaves(580,195,t);if(scene.action==='name'){box(642,92,100,26,RED,2,1,BG);text('YOUR NAME',692,105,12,RED)}if(scene.action==='wrong')text('WRONG ADDRESS',268,140,23,YELLOW)}
 else if(scene.type==='screen'){
 box(242,118,476,229,WHITE,2,8,'#101613');multiline(scene.label||'COLLECTION ACCEPTED',480,178,26,scene.danger?RED:YELLOW,430);
 if(scene.action==='confirm'){box(335,249,111,47,'#828e84',2);box(514,249,111,47,'#828e84',2);text('YES',390,273,20);text('NO',570,273,20);cross(390,273,25);cross(570,273,25)}
 else if(scene.action==='weight'){text((74.8+.02*Math.sin(t)).toFixed(1)+' KG',480,262,39,YELLOW)}
 else if(scene.action==='names'){text('MORGAN',480,240,27);text('BENNETT',480,285,27,'#68766b')}
 }
 else if(scene.type==='trolley'){
 elevator(580,105,195,273,1,scene.display||'—');human(331,378,t,{pose:'stand'});human(750,378,t,{scale:.88,flip:true});box(732,233,36,21,'#151a16',2);line([736,212],[766,212],YELLOW,3);
 const roll=scene.settled?1:trolleyMotion[Math.min(180,Math.floor(t*60))],tx=lerp(568,470,roll);box(tx,312,139,12,WHITE,3,1);line([tx+10,324],[tx+10,359],WHITE,3);line([tx+129,324],[tx+129,359],WHITE,3);line([tx+139,312],[tx+139,246],WHITE,4);circle(tx+16,368,10,WHITE,false,3);circle(tx+121,368,10,WHITE,false,3);line([tx+16,368],[tx+16+7*Math.cos(roll*9.8),368+7*Math.sin(roll*9.8)],WHITE,1);if(scene.action==='avoid')cross(tx+67,278,18);if(scene.action==='clipboard'){box(432,127,91,124,WHITE,2,4,BG);box(459,119,37,13,WHITE,2,2,BG);line([446,158],[508,158],'#777f78',1);line([446,183],[508,183],'#777f78',1);text('YOUR NAME',478,211,11,RED)}
 }
 else if(scene.type==='cab'){
 box(255,81,450,307,WHITE,3,3);box(285,111,390,277,'#404a43',1);line([255,388],[285,349],'#49534b',2);line([705,388],[675,349],'#49534b',2);line([285,349],[675,349],'#49534b',2);line([282,244],[678,244],'#707e72',2);
 text(scene.display||'12',480,65,17,scene.danger?RED:YELLOW);human(scene.personX||471,375,t,{pose:scene.pose||'stand'});if(scene.shadow)human(602,375,t,{dim:true});if(scene.action==='mirror'||scene.action==='label'){line([590,125],[590,345],YELLOW,2);human(623,375,t,{dim:true,flip:true,scale:.86});if(scene.action==='label'){box(615,242,31,18,WHITE,1,1,WHITE);text(scene.label||'↑',630,251,10,BG)}}if(scene.action==='phone')iconPhone(355,208);if(scene.waves)soundWaves(548,192,t);
 }
 else if(scene.type==='door'){
 box(538,95,164,283,WHITE,3,1);line([620,95],[620,378],'#424b45',2);circle(674,251,4,WHITE);human(416,378,t,{pose:scene.pose||'stand'});if(scene.waves)soundWaves(692,209,t,YELLOW);if(scene.action==='close'){cross(752,248);text('DO NOT OPEN',623,73,15,RED)}
 }
 else if(scene.type==='label'){
 if(scene.action==='heavy'){box(547,197,173,173,WHITE,3,2,'#1e2420');text('HEAVY',633,284,22);box(579,369,111,5,WHITE,1,1,WHITE);human(346,376,t,{pose:'stand'});check(633,157)}
 else{human(350,378,t,{pose:'stand'});box(339,242,26,20,WHITE,1,1,WHITE);box(494,156,230,153,WHITE,2,4);text(scene.action==='fold'?'FOLD INWARD':'DO NOT READ',609,186,17,scene.action==='fold'?WHITE:RED);line([513,227],[703,227],'#626b63',1);line([513,250],[703,250],'#626b63',1);if(scene.action==='fold')line([609,208],[609,294],YELLOW,2);else cross(608,246,25)}
 }
 else if(scene.type==='clipboard'){
 box(369,102,222,274,WHITE,3,6);box(435,90,90,23,WHITE,2,3,BG);text('DELIVERY',480,143,18);for(let i=0;i<5;i++)line([396,185+i*35],[565,185+i*35],'#465047',1);text('YOUR NAME',480,187,23,RED);if(scene.action==='strike'){line([396,188],[lerp(396,566,ease((t-1)/2)),188],WHITE,4)}if(scene.action==='delivered')text('DELIVERED',480,315,25,RED);
 }
 else if(scene.type==='stairs'){for(let i=0;i<7;i++){line([240+i*65,380-i*26],[305+i*65,380-i*26],WHITE,3);line([305+i*65,380-i*26],[305+i*65,354-i*26],WHITE,3)}human(260,376,t,{pose:'stand'});path([[384,241],[495,197],[485,225]],GREEN,3);text('STAIRS',696,131,21,GREEN);}
 else if(scene.type==='diagram'){
 const n=scene.items||['YOUR FLOOR','YOUR NAME','DO NOT PRESS'];n.forEach((s,i)=>{box(177+i*219,155,168,139,i===1?RED:WHITE,2,5);text(s,261+i*219,225,16,i===1?RED:WHITE);if(i<2)line([355+i*219,224],[379+i*219,224],'#6d7770',2)});if(scene.action==='avoid')cross(480,337,19);
 }
 else if(scene.type==='end'){circle(480,195,52,WHITE,false,2);box(452,163,56,66,WHITE,3,1);line([480,163],[480,229],WHITE,2);line([460,194],[467,194],RED,3);multiline('TAKE THE STAIRS.',480,290,30);text('DEPT. OF VERTICAL ANOMALIES',480,343,11,'#8a958e','center','monospace')}
 else{
 const o=scene.action==='open'?ease((t-1)/2):scene.action==='close'?1-ease((t-1)/2):scene.action==='ajar'?.12:0;
 elevator(535,105,223,273,o,scene.display||'12',scene.danger);let px=345;
 if(scene.action==='walk'){px=270;human(px,378,t,{pose:'walk',motion:clamp(t,0,2.5)});}else human(px,378,t,{pose:scene.pose||'stand'});
 if(scene.waves)soundWaves(755,211,t,YELLOW);if(scene.action==='wait'){circle(397,123,27,WHITE,false,2);line([397,123],[397,103],WHITE,2);line([397,123],[412,131],WHITE,2)}
 }
 // Restrained display noise. Key instructions and captions stay clear.
 c.save();c.globalAlpha=.035;for(let y=2;y<433;y+=4)line([0,y],[960,y],'#9da89e',.5);c.restore();
 if(Math.floor(time*30)%211===0){c.save();c.globalAlpha=.2;line([84,61],[275,61],WHITE,1);line([730,411],[900,411],WHITE,1);c.restore()}
 if(scene.rule&&!cutTitle){text('RULE '+scene.rule+' / 07',480,415,11,'#929d94','center','monospace')}
 const cap=captions.find(a=>time>=a.start&&time<a.end);if(cap)multiline(cap.text.toUpperCase(),480,477,21,WHITE,820);
 return geometry;
}
window.draw=render;
