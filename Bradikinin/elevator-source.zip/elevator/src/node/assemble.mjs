import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const cfg=JSON.parse(fs.readFileSync('manifests/timeline.json'));
const out=process.env.ELEVATOR_OUTPUT||'/workspace/work/output/Bradikinin';fs.mkdirSync(out,{recursive:true});fs.mkdirSync('work/encoded',{recursive:true});
const title=cfg.title;
for(const s of cfg.scenes){
 const files=fs.readdirSync(`renders-final/${s.id}`).filter(x=>x.endsWith('.png'));
 const count=s.endFrameExclusive-s.firstFrame;
 if(files.length!==count)throw Error(`Frame count mismatch ${s.id}: ${files.length}/${count}`);
 for(let f=s.firstFrame;f<s.endFrameExclusive;f++){const p=`renders-final/${s.id}/${String(f).padStart(7,'0')}.png`;if(!fs.existsSync(p))throw Error('Missing '+p)}
 const dest=`work/encoded/${s.id}.mp4`;if(fs.existsSync(dest))continue;
 execFileSync('ffmpeg',['-v','error','-y','-framerate',String(cfg.fps),'-start_number',String(s.firstFrame),'-i',`renders-final/${s.id}/%07d.png`,'-frames:v',String(count),'-an','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','2','-r',String(cfg.fps),dest],{stdio:'inherit'});console.log('Encoded',s.id,count);
}
fs.writeFileSync('work/concat.txt',cfg.scenes.map(s=>`file '${path.resolve('work/encoded/'+s.id+'.mp4')}'`).join('\n'));
execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i','work/concat.txt','-c','copy','work/silent.mp4'],{stdio:'inherit'});
const probe=p=>JSON.parse(execFileSync('ffprobe',['-v','error','-show_format','-show_streams','-of','json',p]));
for(const p of ['work/silent.mp4','assets/audio/mix.wav'])if(Number(probe(p).format.duration)+.001<cfg.duration)throw Error('Insufficient duration: '+p);
execFileSync('ffmpeg',['-v','error','-y','-i','work/silent.mp4','-i','assets/audio/mix.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',String(cfg.duration),'-metadata','title='+title,'-movflags','+faststart',path.join(out,title+'.mp4')],{stdio:'inherit'});
fs.copyFileSync('captions.srt',path.join(out,title+'.srt'));
console.log('Final MP4 assembled:',path.join(out,title+'.mp4'));
