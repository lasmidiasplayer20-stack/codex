/* Binary-safe Git export. Run only after local validation. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const [checkout,source,branch='entrega-elevator-20261016']=process.argv.slice(2);
if(!checkout||!source)throw Error('Usage: node src/node/github-export.mjs CHECKOUT OUTPUT_FOLDER [BRANCH]');
const title="If Your Elevator Shows Your Name, Don't Press It",video=path.join(source,title+'.mp4');
const git=(...args)=>execFileSync('git',['-c','credential.helper=!gh auth git-credential','-C',checkout,...args],{encoding:'utf8'}).trim();
const remote=git('config','--get','remote.origin.url');if(remote!=='https://github.com/lasmidiasplayer20-stack/codex.git')throw Error('Unexpected destination.');
const meta=JSON.parse(execFileSync('ffprobe',['-v','error','-show_format','-show_streams','-of','json',video]));
const v=meta.streams.find(s=>s.codec_type==='video');if(v.width!==1920||v.height!==1080||Number(meta.format.duration)<278.59)throw Error('Invalid video.');
if(fs.statSync(video).size>80*1024*1024)throw Error('Video exceeds 80 MiB export budget.');
const sha256=crypto.createHash('sha256').update(fs.readFileSync(video)).digest('hex');
const names=[title+'.mp4',title+'-cover.png',title+'.srt','README.md','report.md','contact-sheet.jpg','preview.mp4','elevator-source.zip','SHA256SUMS.txt','validation.json'];
// This checkout was cloned with --no-checkout solely for this delivery.
const allowed=new Set(names.map(n=>'Bradikinin/'+n));
if(git('diff','--cached','--name-only','-z').split('\0').filter(Boolean).some(p=>!allowed.has(p)))throw Error('Unexpected staged changes.');
git('read-tree','HEAD');
fs.mkdirSync(path.join(checkout,'Bradikinin'),{recursive:true});
for(const name of names){const rel='Bradikinin/'+name;if(!fs.existsSync(path.join(source,name)))throw Error('Missing delivery '+name);try{git('cat-file','-e','HEAD:'+rel);throw Error('Existing file would be overwritten: '+rel)}catch(e){if(e.message?.startsWith('Existing'))throw e}fs.copyFileSync(path.join(source,name),path.join(checkout,rel));git('add','--',rel)}
// Commit the prepared index directly, preserving every base-tree entry without
// refreshing an intentionally empty worktree or fetching unrelated media blobs.
const tree=git('write-tree','--missing-ok'),parent=git('rev-parse','HEAD');
const commit=git('commit-tree',tree,'-p',parent,'-m','Add 1080p elevator horror episode, cover, preview and reproducible sources');
git('push','origin',commit+':refs/heads/'+branch);
fs.writeFileSync(path.join(source,'export.json'),JSON.stringify({repository:'lasmidiasplayer20-stack/codex',branch,commit,videoSha256:sha256,remotePayloadVerified:false},null,2));
console.log('Pushed to',branch,'sha256',sha256);
