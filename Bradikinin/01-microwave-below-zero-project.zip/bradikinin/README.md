# Bradikinin — Microwave Below Zero

Animação original em linguagem de diagrama de suspense: silhuetas brancas, fundo escuro, alertas vermelhos, câmera de monitoramento. 960×540, 30 fps, 275,644 s de áudio, 8270 quadros. A referência orienta o estilo; nenhum quadro nem áudio dela entra na montagem.

## Preparação

Node.js 24.19.0, Python 3.12.14, NumPy, FFmpeg/ffprobe 7.1.5 e Chromium do sistema. Dependências Node no `package-lock.json`: Canvas nativo 0.1.100, Matter.js 0.20.0 e Puppeteer Core 25.14.0. O Canvas nativo renderiza os PNGs finais; Puppeteer/Chromium renderiza uma prévia independente do mesmo código Canvas 2D. Isso evita exigir milhares de screenshots para a exportação final.

```sh
npm ci
python -m pip install -r requirements.txt
mkdir -p inputs
# Copie o MP3 original anexado para inputs/narration.mp3.
# Copie o MP4 de referência para inputs/reference.mp4 (análise apenas).
npm run analyse
npm run music
npm run qa
node src/node/audit-walk.mjs
npm run preview
npm run render
npm run mix
npm run validate
```

`npm run all` executa análise, música, QA, auditoria de caminhada, prévia, render, mix e validação. Defina o caminho do Chromium em `render.mjs` se não estiver em `/usr/bin/chromium`. Linux precisa de DejaVu Sans para reproduzir a tipografia.

Depois da validação, `python build-delivery.py` monta capa, folha de contato, relatório e ZIP. O bundle inclui os WAVs sintetizados para remixagem.

Para uma cena isolada: `node src/node/render.mjs all 20`. Os índices globais dos quadros estão em `timeline.json`, com intervalos semiabertos `[first,stop)`. Os PNGs já existentes são reutilizados; um MP4 de cena existente é considerado concluído. Ao alterar o desenho, remova o MP4 e a pasta de PNGs apenas das cenas afetadas antes de renderizar. Para remontar a concatenação após um render isolado, execute `npm run render`.

## Som

`music.py` compõe/sintetiza música original determinística com seed 1701 e produz três stems, o somatório musical e efeitos locais. Os WAVs estão no bundle para remixagem. A narração entra uma única vez, sem alteração de andamento; música e efeitos ficam em ganho baixo. `mix.mjs` associa explicitamente vídeo e mix, sem `-shortest`.

A chave ElevenLabs não estava configurada: a entrega usa efeitos sintetizados localmente, **não** efeitos gerados pela API. O passo opcional `npm run effects` exige `ELEVENLABS_API_KEY` no ambiente, usa cache por hash e grava custo apenas se informado pelo provedor. Ele produz um asset isolado em `audio/cache`; para usá-lo, edite o plano/mix explicitamente. Renderizar ou mixar não chama essa API. Nenhuma chamada paga foi feita.

## Rig e verificações

Torso rígido, cabeça de raio constante, braços 30+29 e pernas 34+34 unidades; IK analítica sem stretch. O reflexo infantil usa escala uniforme de um modelo separado. Joelhos e cotovelos usam lados de dobra definidos; o braço levantado usa solução que evita cruzar a cabeça. Pés apoiados ficam ancorados no mundo durante cada fase de apoio. Matter.js afeta somente a queda do telefone, não os ossos.

`qa/rig.json`, `qa/walk-audit.json` e `qa/validation.json` registram medidas. A folha de contato e sequências densas permitem conferir silhuetas e contatos. A análise de fala é automática e aproximada; os textos da tela são rótulos editoriais, não legendas literais. Não houve escuta humana nem garantia de sincronização fonema a fonema.

## Arquivos e publicação

`delivery/01-microwave-below-zero.mp4` é o filme completo. A prévia, folha de contato, plano, fontes e áudio sintetizado estão no projeto. Os originais ficam preservados fora do bundle e não são publicados no GitHub. Reproduzir a voz exige recolocar o MP3 fornecido em `inputs/narration.mp3`.

Após validar, `node src/node/github-export.mjs /caminho/do/checkout` copia somente os quatro arquivos listados no script para `Bradikinin/`, faz commit/push sem force e confere o SHA-256 dos bytes do MP4 recuperados pelo Git. O script recusa substituição de uma entrega diferente. O bundle reproduzível exclui inputs pessoais, mix com voz, caches, PNGs de render e node_modules.
