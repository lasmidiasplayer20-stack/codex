/* Deterministic Canvas 2D staging. All bone lengths are fixed in model space. */
function makeFilm(ctx,plan,Matter){
 const W=960,H=540,C={white:'#f3f4ef',gray:'#6c7577',dim:'#263033',red:'#ec3c48',yellow:'#e4cb74',bg:'#06090b'};
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v)},mix=(a,b,t)=>a+(b-a)*t;
 const stats={maxBoneError:0,maxContactError:0,maxReachExcess:0,minElbow:180,maxElbow:0,minKnee:180,maxKnee:0};
 function line(points,color=C.white,width=3){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.stroke()}
 function box(x,y,w,h,color=C.white,width=2,fill=null,r=0){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke()}
 function circle(x,y,r,col=C.white,fill=true){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx[fill?'fillStyle':'strokeStyle']=col;fill?ctx.fill():ctx.stroke()}
 function text(str,x,y,size=18,col=C.white,align='center',weight=500){ctx.fillStyle=col;ctx.font=`${weight} ${size}px DejaVu Sans`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(str,x,y)}
 function ik(a,b,L1,L2,side){let dx=b[0]-a[0],dy=b[1]-a[1],raw=Math.hypot(dx,dy),d=clamp(raw,Math.abs(L1-L2)+.001,L1+L2-.001);stats.maxReachExcess=Math.max(stats.maxReachExcess,raw-(L1+L2));if(L1===30){let angle=Math.acos(clamp((L1*L1+L2*L2-d*d)/(2*L1*L2),-1,1))*180/Math.PI;stats.minElbow=Math.min(stats.minElbow,angle);stats.maxElbow=Math.max(stats.maxElbow,angle)}let ux=dx/(raw||1),uy=dy/(raw||1),q=(L1*L1-L2*L2+d*d)/(2*d),h=Math.sqrt(Math.max(0,L1*L1-q*q));const end=[a[0]+ux*d,a[1]+uy*d],joint=[a[0]+ux*q-uy*h*side,a[1]+uy*q+ux*h*side];for(let [p1,p2,L] of [[a,joint,L1],[joint,end,L2]])stats.maxBoneError=Math.max(stats.maxBoneError,Math.abs(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])-L));return [a,joint,end]}
 function actor(x,y,t,opt={}){
  const scale=opt.scale||1.35,alpha=opt.alpha??1,dir=opt.dir||1;
  ctx.save();ctx.translate(x,y);ctx.scale(scale*dir,scale);ctx.globalAlpha*=alpha;
  let feet=[[-12,0],[13,0]],pelvis=[0,-67],walk=opt.walk;
  if(walk){ // stance feet are anchored in world coordinates; only swing feet leave the floor.
   const speed=28,period=.92;
   for(let i=0;i<2;i++){let phase=t/period+i*.5,cycle=Math.floor(phase),u=phase-cycle;let worldAnchor=(cycle-i*.5)*speed*period;let local=worldAnchor-t*speed;
    if(u<.62){feet[i]=[local,0]}else{let v=(u-.62)/.38;feet[i]=[local+speed*period*ease(v),-9*Math.sin(Math.PI*v)]}
   }
   pelvis=[0,-60+1.2*Math.cos(t/period*4*Math.PI)];
  }
  if(opt.pose==='seated'){pelvis=[0,-34];feet=[[28,0],[40,0]]}const shoulder=[pelvis[0],pelvis[1]-43],head=[shoulder[0],shoulder[1]-23];
  const legA=ik([pelvis[0]-6,pelvis[1]],feet[0],34,34,-1),legB=ik([pelvis[0]+6,pelvis[1]],feet[1],34,34,-1);
  for(let i=0;i<2;i++){const leg=[legA,legB][i];stats.maxContactError=Math.max(stats.maxContactError,Math.hypot(leg[2][0]-feet[i][0],leg[2][1]-feet[i][1]));line(leg,C.white,5.5);line([[leg[2][0]-3,leg[2][1]],[leg[2][0]+8,leg[2][1]]],C.white,5);let d=Math.hypot(leg[0][0]-leg[2][0],leg[0][1]-leg[2][1]);let knee=Math.acos(clamp((34*34*2-d*d)/(2*34*34),-1,1))*180/Math.PI;stats.minKnee=Math.min(stats.minKnee,knee);stats.maxKnee=Math.max(stats.maxKnee,knee)}
  // Fixed rigid torso, no squash, no stretch, no moving shoulder/hip offsets.
  ctx.fillStyle=C.white;ctx.beginPath();ctx.moveTo(shoulder[0]-8,shoulder[1]);ctx.lineTo(shoulder[0]+8,shoulder[1]);ctx.lineTo(pelvis[0]+8,pelvis[1]);ctx.lineTo(pelvis[0]-8,pelvis[1]);ctx.closePath();ctx.fill();
  line([[shoulder[0],shoulder[1]-3],[head[0],head[1]+10]],C.white,6);circle(...head,12);
  let near=[12,-51],far=[-12,-51];
  if(walk){near=[12+7*Math.sin(t/.92*2*Math.PI),-46];far=[-12-7*Math.sin(t/.92*2*Math.PI),-46]}
  if(opt.pose==='seated'){near=[29,-42];far=[-12,-30]}if(opt.pose==='hold')near=[34,-91];
  if(opt.pose==='reach')near=[54,-124];
  if(opt.pose==='raise'){let q=ease((opt.gestureTime??1)/.9);near=[mix(42,32,q),mix(-100,-145,q)]};
  if(opt.pose==='lookdown'){ // head stays the same size; eye direction communicates gaze.
   near=[12,-51];
  }
  if(opt.hand)near=opt.hand;
  line(ik([shoulder[0]-6,shoulder[1]+3],far,30,29,1),C.gray,4.5);
  line(ik([shoulder[0]+6,shoulder[1]+3],near,30,29,opt.pose==='raise'?1:-1),C.white,5.5);
  circle(head[0]+5,head[1]+(opt.pose==='lookdown'?3:0),1.6,C.bg);
  if(opt.pose==='hold'){box(near[0]-4,near[1]-13,10,16,C.white,1,C.bg,2);line([[near[0]-2,near[1]-10],[near[0]+3,near[1]-10]],C.red,1)}
  ctx.restore();return {feet,pelvis};
 }
 function timer(x,y,value,size=38){box(x-83,y-30,166,60,C.dim,1,'#0b1213',3);text(value,x,y,size,C.red,'center',600)}
 function microwave(x,y,s=1,time='−00:30',content='plate',t=0,controlsLeft=false){ctx.save();ctx.translate(x,y);ctx.scale(controlsLeft?-s:s,s);function label(str,x,y,...rest){ctx.save();if(controlsLeft){ctx.scale(-1,1);x=-x}text(str,x,y,...rest);ctx.restore()}box(-145,-82,290,164,C.white,3,C.bg,8);box(-130,-66,192,127,C.gray,2,'#0d1518',5);line([[75,-66],[75,65]],C.gray,2);label(time,109,-38,17,C.red,'center',600);box(86,-12,45,26,C.white,1,null,2);label('+30',109,1,12);circle(108,43,8,C.white,false);line([[-112,44],[46,44]],C.gray,1);
  ctx.save();ctx.beginPath();ctx.rect(-128,-64,187,107);ctx.clip();
  if(content==='plate'||content==='cheese'||content==='food'){ctx.fillStyle=C.white;ctx.beginPath();ctx.ellipse(-32,26,53,7,0,0,7);ctx.fill();if(content==='cheese'){box(-58,-4,54,25,C.yellow,1,C.yellow);for(let i=0;i<4;i++)circle(-48+i*11,4+(i%2)*8,2,C.bg);let q=ease((t%7)/7);box(-65+q*5,-13+q*5,68-q*10,46-q*10,C.white,1)}else{for(let i=0;i<4;i++)circle(-60+i*18,15+Math.sin(t+i)*2,6,C.yellow)}}
  if(content==='soup'){ctx.fillStyle=C.white;ctx.beginPath();ctx.arc(-32,12,40,0,Math.PI);ctx.fill();line([[-74,12],[10,12]],C.white,3);for(let i=0;i<6;i++){let q=ease(t/6);circle(-58+i*10,10-q*(18+(i%3)*9),3,i%2?C.yellow:C.white)}}
  if(content==='egg'){ctx.fillStyle=C.white;ctx.beginPath();ctx.ellipse(-30,13,19,27,0,0,7);ctx.fill();if(t%3>.7)line([[-31,-10],[-36,-2],[-28,5],[-33,12]],C.bg,2)}
  if(content==='package'){box(-77,-10,92,40,C.white,2,'#121b1e');label('FROZEN',-31,7,11);line([[-65,21],[2,21]],C.red,2)}
  ctx.restore();ctx.restore()}
 function plant(x,y,t){box(x-15,y-30,30,30,C.white,2);let q=ease(t/5);line([[x,y-30],[x+10*(1-q),y-62-30*q]],C.white,3);for(let i=0;i<4;i++){let yy=y-40-i*12,side=i%2?1:-1;line([[x,yy],[x+side*(18+6*q),yy-10*q]],C.white,3)}}
 function door(x,y,open=0,detail=true){box(x-58,y-175,116,175,C.white,3);let right=x+58-75*open;line([[x-58,y-175],[right,y-175],[right,y],[x-58,y]],C.gray,2);circle(right-17,y-84,4,C.yellow);if(detail)text('EXIT',x,y-193,12,C.gray)}
 function room(t,opt={}){box(100,142,760,268,C.dim,1);line([[100,410],[860,410]],C.gray,2);line([[100,175],[860,175]],C.dim,1);box(496,296,268,114,C.gray,2);line([[628,296],[628,410]],C.dim,1);microwave(633,242,.73,opt.time||'−00:30',opt.content||'plate',t,opt.controlsLeft||false);if(opt.plant)plant(799,296,t);if(opt.door)door(194,410,opt.open||0)}
 function receipt(x,y,t){box(x-45,y-65,90,130,C.white,2,C.bg);for(let i=0;i<5;i++)line([[x-31,y-42+i*14],[x+31-(i%2)*14,y-42+i*14]],C.gray,2);text(2026-Math.floor(t*2),x,y+39,19,C.red)}
 // Matter is used for the phone settling on a table, isolated from the anatomical rig.
 let phoneSamples=[];if(Matter){const e=Matter.Engine.create({gravity:{x:0,y:1}}),ground=Matter.Bodies.rectangle(0,30,300,20,{isStatic:true}),p=Matter.Bodies.rectangle(0,-25,26,48,{restitution:.08,friction:.8,angle:.08});Matter.Composite.add(e.world,[ground,p]);for(let i=0;i<180;i++){Matter.Engine.update(e,1000/60);phoneSamples.push({x:p.position.x,y:p.position.y,a:p.angle})}}
 function frame(time){let s=plan.scenes.find(s=>time>=s.start&&time<s.end)||plan.scenes.at(-1),t=time-s.start,p=clamp(t/(s.end-s.start)),k=s.kind;
  ctx.globalAlpha=1;ctx.fillStyle=C.bg;ctx.fillRect(0,0,W,H);
  // Low contrast monitoring grid, clean and subordinate to silhouettes.
  for(let i=0;i<16;i++){ctx.fillStyle=i%2?'#0b0f11':'#090d0f';ctx.fillRect(i*64,60,1,376)}
  text('OHC / DOMESTIC ANOMALIES',42,28,10,C.gray,'left');text('CASE 01   •   MICROWAVE',918,28,10,C.gray,'right');
  circle(47,61,3,C.red);text('REC',60,61,10,C.gray,'left');text(`${String(Math.floor(time/60)).padStart(2,'0')}:${String(Math.floor(time%60)).padStart(2,'0')}:${String(Math.floor(time*30)%30).padStart(2,'0')}`,918,61,10,C.gray,'right');
  if(k==='rule'){
   text(s.caption,480,175,17,C.gray);text(String(s.rule),480,267,105,C.white,'center',700);line([[403,333],[557,333]],C.red,3);text(s.title,480,380,s.title.length>25?24:29,C.white,'center',600);
  }else{
   if(['opening','timer','cheese','food','soup','package','egg','button','plant','reset'].includes(k)){
    if(['opening','button','plant','reset'].includes(k)){room(t,{content:k==='reset'?'plate':'cheese',time:k==='reset'?'12:00':k==='opening'?(t<1.2?'00:00':`−00:${String(Math.floor(t)).padStart(2,'0')}`):'−01:00',plant:k==='plant',controlsLeft:k==='button'});let pose=k==='button'?'reach':'neutral';actor(k==='button'?480:385,410,time,{pose,dir:1,hand:k==='button'?[mix(12,54,ease(t/.4)),mix(-51,-124,ease(t/.4))]:undefined});if(k==='plant'){circle(799,242,57,'#152021',false);text('RECOVERED',798,346,12,C.red)}}
    else{microwave(560,266,1.45,k==='timer'?'−00:01':'−00:30',k==='timer'?'plate':k,t);if(k==='egg'){actor(228-12*ease(t/2),410,time);let pulse=.5+.5*Math.sin(t*9);ctx.globalAlpha=pulse;for(let i=0;i<3;i++)line([[520+i*8,183-i*5],[524+i*8,176-i*5]],C.red,2);ctx.globalAlpha=1}}
   }else if(k==='office'){box(347,148,266,226,C.white,2);text('OHC',480,209,62,C.white,'center',700);line([[388,259],[572,259]],C.red,3);text('OFFICE OF HOUSEHOLD',480,292,14);text('CONTINUITY',480,315,14);text('READ / RETAIN / COMPLY',480,353,10,C.gray)}
   else if(k==='index'||k==='warning'){for(let i=1;i<=7;i++){box(219+(i-1)*78,225,53,59,C.white,2,null,3);text(i,245+(i-1)*78,255,26)}if(k==='warning'){line([[313,330],[647,330]],C.red,2);text('DO NOT PRESS IT TWICE',480,360,27,C.red,'center',600)}else{text('07',480,350,42,C.red)}}
   else if(k==='receipt'){receipt(480,260,t);line([[354,260],[391,260]],C.red,2);text('DATE',327,260,13,C.gray)}
   else if(['reflection','raised','child'].includes(k)){
    actor(281,407,time,{pose:k==='raised'?'lookdown':'neutral'});box(455,151,322,256,C.white,3,'#0e1519',7);line([[483,380],[749,380]],C.gray,2);
    actor(613,380,time,{dir:-1,pose:k==='raised'?'raise':'neutral',gestureTime:t,scale:k==='child'?.98:1.35,alpha:.83});if(k==='reflection'){line([[594,291],[624,291]],C.red,3)}if(k==='child'){text('…',613,180,26,C.red)}
   }else if(['leave','wallpaper','meal'].includes(k)){
    room(t,{door:true,open:.7});if(k==='wallpaper'){for(let i=0;i<8;i++)for(let j=0;j<4;j++)box(320+i*55,190+j*40,9,13,'#303339',1);for(let i=0;i<3;i++)line([[235,310-i*17],[249,310-i*17]],C.yellow,2)}
    const walkingTime=t,x=430-28*1.35*walkingTime;actor(x,410,walkingTime,{walk:true,dir:-1});if(k==='leave'){actor(525-28*1.2*walkingTime,410,walkingTime,{walk:true,dir:-1,scale:1.2});if(t>3){ctx.globalAlpha=.2;actor(778,410,time,{dir:-1});ctx.globalAlpha=1}}
    if(k==='meal'){ctx.globalAlpha=.35;line([[650,207],[646+Math.sin(t)*6,184],[652,164]],C.white,2);ctx.globalAlpha=1}
   }else if(['voice','silence'].includes(k)){
    door(610,410,.1,false);actor(330,410,time,{dir:1});for(let i=0;i<4;i++){let q=(t*.5+i*.25)%1;ctx.globalAlpha=.45*(1-q);ctx.beginPath();ctx.ellipse(610,261,69+q*60,86+q*45,0,-.8,.8);ctx.strokeStyle=C.red;ctx.lineWidth=2;ctx.stroke()}ctx.globalAlpha=1;if(k==='voice')text('THE FOOD IS GETTING COLD',610,144,15,C.white);else{box(255,169,150,42,C.gray,1);text('NO REPLY',330,190,13,C.white)}}
   else if(k==='objects'){receipt(293,260,t);line([[460,252],[529,252]],C.white,6);circle(452,252,15,C.white,false);line([[512,252],[512,267]],C.white,6);line([[523,252],[523,262]],C.white,6);box(644,189,74,138,C.white,3,C.bg,8);text('12:24',681,240,14);text('TODAY',681,280,11,C.gray)}
   else if(k==='phone'||k==='battery'){box(414,142,132,264,C.white,3,C.bg,13);line([[455,156],[506,156]],C.gray,2);if(k==='phone'){circle(480,223,25,C.red,false);text('HELLO',480,224,12);text('FINISH SETTING UP',480,283,11);line([[439,319],[521,319]],C.red,2)}else{box(450,223,60,28,C.white,2);box(512,230,6,13,C.white,1,C.white);box(454,227,52,20,C.gray,1,C.gray);text('100%',480,282,23);text('NO FURTHER DATA',480,327,10,C.red)}}
   else if(k==='putdown'){
    line([[340,350],[730,350]],C.white,3);line([[365,350],[365,410]],C.gray,3);line([[705,350],[705,410]],C.gray,3);actor(434,410,time,{hand:[mix(34,12,ease(t-1)),mix(-78,-51,ease(t-1))]});let a=phoneSamples[Math.min(179,Math.floor(Math.max(0,t-1)*60))]||{x:0,y:0,a:0};ctx.save();ctx.translate(480+a.x,330+a.y);ctx.rotate(a.a);box(-13,-24,26,48,C.white,2,C.bg,3);ctx.restore();if(t>2)text('DO NOT ENTER YOUR DATE OF BIRTH',540,183,16,C.red)
   }else if(['door','handle','outside','beep'].includes(k)){
    let opened=(k==='outside'||k==='beep')?.85:k==='handle'?.25*ease((t-4)/2):0;door(593,410,opened);
    if(k==='outside')actor(445+t*28*1.35,410,t,{walk:true});else actor(k==='handle'?585:439,410,time,{pose:k==='handle'?'reach':'neutral',hand:k==='handle'?[(634-75*opened-585)/1.35,-84/1.35]:undefined});
    if(k==='handle'){circle(634,326,13,C.red,false);text(t<2?'TURN':t<4?'PULL':'PUSH',480,155,26,C.white)}
    if(k==='beep'){let q=(t%1);ctx.globalAlpha=1-q;circle(593,192,20+q*40,C.yellow,false);ctx.globalAlpha=1}
   }else if(k==='fridge'){box(540,147,171,262,C.white,3);line([[540,224],[711,224]],C.gray,2);line([[550,244],[550,282]],C.white,3);box(581,259,91,102,C.white,2,'#0d1518');circle(601,274,4,C.red);actor(395,410,time,{pose:'neutral'})}
   else if(k==='photo'){box(341,126,278,294,C.white,2,'#161c20');ctx.save();ctx.beginPath();ctx.rect(355,139,250,247);ctx.clip();actor(496,385,time,{scale:1.45,alpha:.23});line([[440,307],[440,350],[483,350]],C.gray,2);line([[442,350],[442,385]],C.gray,2);actor(455,385,time,{scale:1.05,pose:'seated'});line([[365,336],[594,336]],C.white,3);ctx.restore();text('NO DATE',480,402,10,C.gray)}
   else if(k==='writing'){box(299,160,362,210,C.white,2,'#0c1012');text('Please let me stay',480,241,27);text('this time.',480,283,27);line([[366,317],[594,317]],C.red,1)}
   else if(k==='ending'){room(t,{time:'12:00'});actor(375,410,time);if(t>3){ctx.globalAlpha=ease((t-3)/2)*.28;actor(282,410,time,{scale:1.35});ctx.globalAlpha=1}text('REQUEST RECEIVED',480,134,13,C.red)}
   text(s.title,480,463,s.title.length>32?22:27,C.white,'center',600);text(s.caption,480,498,15,C.gray);
  }
  // Rule progress has the same quiet visual hierarchy as the reference.
  for(let n=1;n<=7;n++){box(397+(n-1)*25,76,18,17,n===s.rule?C.white:C.dim,1,n===s.rule?C.white:null,2);text(n,406+(n-1)*25,85,10,n===s.rule?C.bg:C.gray)}
  line([[42,520],[918,520]],C.dim,1);line([[42,520],[42+876*time/plan.duration,520]],C.red,1);
  return s.id;
 }
 return {frame,actor,stats};
}
if(typeof module!=='undefined')module.exports={makeFilm};
