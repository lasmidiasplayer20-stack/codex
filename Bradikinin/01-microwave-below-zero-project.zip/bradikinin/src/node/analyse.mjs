import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {execFileSync} from 'node:child_process';
process.chdir(path.resolve(import.meta.dirname,'../..'));fs.mkdirSync('inputs',{recursive:true});
let audio=process.argv[2]||'inputs/narration.mp3',video=process.argv[3]||'inputs/reference.mp4';
const inspect=p=>({file:path.basename(p),bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),probe:JSON.parse(execFileSync('ffprobe',['-v','error','-show_format','-show_streams','-of','json',p],{encoding:'utf8'}))});
const a=inspect(audio),v=inspect(video);for(const x of [a,v]){delete x.probe.format.filename;for(const s of x.probe.streams||[])delete s.tags?.filename}
fs.writeFileSync('inputs-manifest.json',JSON.stringify({audio:a,reference:v,reference_audio_used:false},null,2));console.log(JSON.stringify({duration:a.probe.format.duration,audio_sha256:a.sha256,reference_sha256:v.sha256},null,2));
