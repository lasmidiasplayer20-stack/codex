import json,math,subprocess,hashlib
from pathlib import Path
p=Path(__file__).parent
rough=json.load(open(p/'transcript.json'))
# Editorial captions are short scene labels, not a claimed verbatim transcription.
scenes=[
(0,7.8,'opening','IF IT KEEPS COUNTING','Do not open the door.'),
(7.8,11.64,'office','HOUSEHOLD CONTINUITY','FIELD BULLETIN / 01'),
(11.64,15.48,'timer','−00:01','Dinner still looks like dinner.'),
(15.48,19.68,'cheese','−00:30','The process is running backward.'),
(19.68,24.84,'index','SEVEN RULES','Read the last one while you can.'),
(24.84,28.83,'rule','LEAVE THE DOOR CLOSED','RULE 1'),
(28.83,33.51,'food','RETURNING, NOT HEATING','Keep the door closed.'),
(33.51,39.84,'soup','INGREDIENTS SEPARATE','Water. Vegetables. Confidence.'),
(39.84,46.68,'package','PACKAGING RETURNS','This is not a refund.'),
(46.68,49.8,'receipt','THE DATE IS CHANGING','Do not retrieve the receipt.'),
(49.8,57.99,'egg','IF SOMETHING KNOCKS','Step back. Keep it closed.'),
(57.99,62.76,'rule','DO NOT PRESS +30','RULE 2'),
(62.76,72.6,'button','THE EFFECT SPREADS','Yes, the button works.'),
(72.6,80.88,'plant','REMEMBER WHY','You stopped watering it.'),
(80.88,89.97,'warning','DO NOT PRESS IT TWICE','The print has been corrected.'),
(89.97,93.75,'rule','DO NOT WATCH THE GLASS','RULE 3'),
(93.75,102.99,'reflection','DO NOT MOVE CLOSER','A younger reflection is not an invitation.'),
(102.99,107.31,'raised','LOOK AT THE FLOOR','It moved before you did.'),
(107.31,119.01,'child','DO NOT WAVE','Do not answer the child.'),
(119.01,124.95,'rule','LEAVE THE KITCHEN','RULE 4 / WALK, DO NOT RUN'),
(124.95,132.09,'leave','TAKE WHO IS HERE NOW','Do not return for late arrivals.'),
(132.09,141.84,'wallpaper','KEEP WALKING','Some marks were not here before.'),
(141.84,150.84,'meal','YOU MAY MISS IT','You may not go back for a plate.'),
(150.84,154.68,'rule','DO NOT ANSWER THE VOICE','RULE 5'),
(154.68,167.82,'voice','THE FOOD IS GETTING COLD','Do not answer.'),
(167.82,179.76,'silence','DO NOT ANSWER','Even to say you are not hungry.'),
(179.76,184.95,'rule','KEEP ONE RECENT OBJECT','RULE 6'),
(184.95,192.99,'objects','CHECK IT REGULARLY','A receipt. A key. Your phone.'),
(192.99,198.72,'phone','FINISH SETTING UP','If this appears, put it down.'),
(198.72,204.36,'putdown','DO NOT ENTER YOUR BIRTH DATE','Put the phone down.'),
(204.36,211.89,'battery','EXCELLENT BATTERY LIFE','No further information.'),
(211.89,215.31,'rule','REMEMBER HOW A DOOR WORKS','RULE 7'),
(215.31,223.95,'door','STAND IN FRONT OF IT','The handle is next.'),
(223.95,231.39,'handle','TURN. PULL. PUSH.','If it does not open, push.'),
(231.39,240.81,'outside','GO OUTSIDE','Do not stop for your shoes.'),
(240.81,245.1,'beep','WAIT FOR AN ORDINARY BEEP','Then you may return.'),
(245.1,250.11,'reset','12:00','Do not correct it.'),
(250.11,256.65,'fridge','THE KITCHEN LOOKS NORMAL','Except for the photograph.'),
(256.65,261.96,'photo','SOMEONE IS BEHIND YOU','You do not remember this photograph.'),
(261.96,267.96,'writing','PLEASE LET ME STAY THIS TIME','In your handwriting.'),
(267.96,275.644082,'ending','DINNER IS READY','Your request has been received.')]
for i,s in enumerate(scenes):
 a,b,kind,title,caption=s
 rule=0
 for start,n in [(24.84,1),(57.99,2),(89.97,3),(119.01,4),(150.84,5),(179.76,6),(211.89,7)]:
  if a>=start:rule=n
 scenes[i]=dict(id=i,start=a,end=b,first=math.ceil(a*30),stop=math.ceil(b*30),kind=kind,title=title,caption=caption,rule=rule)
config=dict(duration=275.644082,fps=30,width=960,height=540,seed=1701,intervals='[first,stop), global frame indices; cuts never duplicate a frame',scenes=scenes)
(p/'timeline.json').write_text(json.dumps(config,indent=2))
print(len(scenes),'scenes',math.ceil(config['duration']*30),'frames')
