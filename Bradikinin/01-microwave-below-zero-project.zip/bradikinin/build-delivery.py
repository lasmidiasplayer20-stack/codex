from pathlib import Path
from PIL import Image,ImageDraw
import json,subprocess,zipfile,shutil
P=Path(__file__).parent;d=P/'delivery';d.mkdir(exist_ok=True);plan=json.load(open(P/'timeline.json'));v=json.load(open(P/'qa/validation.json'));q=json.load(open(P/'qa/rig.json'));walk=json.load(open(P/'qa/walk-audit.json'))
# Contact sheet comes from the actual encoded final film, not only renderer frames.
fs=[]
for s in plan['scenes']:
 f=P/f"qa/encoded-{s['id']:02d}.png";subprocess.run(['ffmpeg','-v','error','-y','-ss',str((s['start']+s['end'])/2),'-i',str(d/'01-microwave-below-zero.mp4'),'-frames:v','1',str(f)],check=True);fs.append(f)
out=Image.new('RGB',(1280,9*162),'#101417');dr=ImageDraw.Draw(out)
for i,f in enumerate(fs):
 x=(i%5)*256;y=(i//5)*162;out.paste(Image.open(f).convert('RGB').resize((256,144)),(x,y));dr.text((x+5,y+145),f'{i:02d} / {plan["scenes"][i]["start"]:.2f}s',fill='white')
out.save(P/'qa/contact-sheet.jpg',quality=92)
shutil.copy(fs[0],d/'01-microwave-below-zero-cover.png')
report=f'''# Relatório de produção

- Inputs: MP3 MiniMax anexado (275,644082 s) e MP4 de referência (272,788027 s). SHA-256 e metadados estão em inputs-manifest.json. Originais preservados por links locais somente; não incluídos no bundle nem no commit.
- O texto recebido começa no fim da seção anterior à 15; não havia as seções iniciais completas. As instruções disponíveis foram seguidas com decisões documentadas.
- Filme original: 41 cenas, 960×540, 30 fps, {v['read_frames']} quadros. Duração de vídeo {v['video_duration']:.6f} s, áudio {v['audio_duration']:.6f} s. Contêiner {v['container_duration']:.6f} s. H.264/yuv420p + AAC 192 kbps, faststart. Tamanho {v['bytes']} bytes.
- SHA-256 do MP4: `{v['sha256']}`.
- Estética: diagramas brancos sobre preto, alertas vermelhos, áreas de monitoramento, tipografia sem serifa, gestos pequenos. Não há quadros reaproveitados do vídeo de referência.
- Narração: importada uma vez, andamento e sequência preservados; nenhuma faixa sonora da referência foi usada. Música local em ganho 0,15 e efeitos em ganho 0,3 antes do somatório com voz em ganho 1.
- Música original: drones, pulsos e notas sintetizadas em Python/NumPy, seed 1701, com três stems e fades contínuos.
- Efeitos: sintetizados localmente. Zero chamadas à ElevenLabs; nenhum consumo cobrado informado pelo provedor. A chave não estava configurada. O módulo Node opcional tem cache e não é chamado pelo render/mix; assets opcionais da API exigem integração explícita ao plano.
- Render: Canvas 2D nativo em Node para os PNGs finais; Puppeteer/Chromium para prévia representativa do mesmo desenho. Render por cena e intervalos semiabertos; PNGs em cache fora do bundle. Uso observado de disco para frames: cerca de 250 MB; tempo por cena registrado no console, geralmente 2–9 s no ambiente atual.

## Verificações automáticas executadas

- Cobertura contínua da timeline e existência de cada PNG esperado; contagem do MP4 coincide com ceil(T×30).
- Decodificação integral do MP4 passou. Vídeo e mix cobrem toda a voz sem `-shortest`.
- Erro máximo de comprimento dos membros: {q['maxBoneError']:.3g} unidades; erro máximo do alvo dos pés: {q['maxContactError']:.3g}; excesso de alcance solicitado: {q['maxReachExcess']}.
- Ângulo interno dos cotovelos: {q['minElbow']:.2f}°–{q['maxElbow']:.2f}°. Joelhos: {q['minKnee']:.2f}°–{q['maxKnee']:.2f}°. Lados da solução IK definidos por pose, sem inversão aleatória.
- Deriva máxima do pé em apoio no mundo: {walk['max_world_foot_drift_px']:.3g} px, em {walk['samples']} comparações a 30 fps nos dois sentidos de caminhada. Não mede todos os possíveis contatos de cena.
- Mix tem exatamente a faixa de voz escolhida no grafo. Medição de pico/RMS está em qa/audio-stats.txt. Isso não equivale a escuta humana.

## Inspeção visual e limites

Folha de contato de todas as cenas e sequências densas de caminhada, reflexo e maçaneta examinadas. Foram corrigidos o repouso excessivamente agachado, alvos fora do alcance, orientação do cotovelo levantado, contato com o botão e maçaneta. As silhuetas mantêm cabeça e torso rígidos; objetos usam dimensões constantes em cada enquadramento. Mudanças de enquadramento e a escala uniforme do reflexo infantil são intencionais.

A fala foi analisada com PocketSphinx local. O download do modelo Whisper foi negado pela política de rede. A transcrição bruta tem erros e é identificada como automática; os títulos são rótulos editoriais, não legendas verbatim. A sincronização é por frases e ações, não por fonemas, e não recebeu escuta humana. Não se afirma naturalidade perfeita ou ausência absoluta de artefatos. A prévia em Chromium foi renderizada; a inspeção de movimento ocorreu por sequências densas, sem reprodução audiovisual humana.

Não havia chave ElevenLabs. O caminho de outputs solicitado pelo cliente não existe neste executor e seu diretório raiz é somente leitura; a entrega foi preparada em delivery/. Após autorização explícita do usuário, os quatro arquivos foram publicados na branch bradikinin-01-20261016. Commit inicial da entrega: 4e3b83bf043d8ffd9ca2e96c6da7648b4c3e9f42. O SHA-256 do MP4 recuperado via Git foi conferido e coincide com o arquivo local validado. Outros episódios não foram alterados. O bundle reproduzível não contém os inputs pessoais, a voz ou o mix com voz: o usuário deve recolocar o MP3 original em inputs/narration.mp3. Não foram geradas legendas literais a partir da transcrição incerta.

## GitHub

O exportador verifica tamanho, ffprobe e hash local antes do commit, adiciona apenas os arquivos listados, faz push comum e confirma branch/commit remoto e SHA-256 dos bytes do MP4 via fetch/Git. O registro da execução fica em qa/github-export.json após o envio; não se confunde criar o script com efetuar a publicação.
'''
(P/'report.md').write_text(report)
(d/'README.md').write_text(f'''# Bradikinin / Episode 01

**Microwave Below Zero** — filme completo original, com narração importada, música e efeitos locais.

- Duração: {v['audio_duration']:.3f} segundos (~4min36s).
- 960×540, 30 fps; H.264/yuv420p + AAC; MP4 faststart.
- SHA-256: `{v['sha256']}`.

Abra [o MP4](01-microwave-below-zero.mp4) e use **Download raw file** no GitHub para baixar. A capa está em [PNG](01-microwave-below-zero-cover.png).

[Projeto reproduzível, prévia e folha de contato](01-microwave-below-zero-project.zip). Extraia o ZIP e leia README.md e report.md. Inputs pessoais e voz original não são publicados: recoloque o MP3 fornecido em inputs/narration.mp3 para renderizar/mixar novamente.

Os efeitos foram sintetizados localmente porque não havia chave ElevenLabs. Verificações geométricas, temporais e de decodificação foram executadas; não houve escuta humana nem promessa de sincronização exata.
''')
# Dense final PNG sequences for motion/pose inspection.
for scene,t,crop in [(17,103.0,(190,160,780,420)),(20,125.0,(100,180,540,420)),(33,224.0,(480,180,700,420))]:
 sheet=Image.new('RGB',(1200,600),'#0c1113');draw=ImageDraw.Draw(sheet)
 for i in range(12):
  f=int((t+i*.12)*30);src=P/f'renders/scene-{scene:02d}/{f:06d}.png'
  im=Image.open(src).crop(crop);im.thumbnail((300,180));x=(i%4)*300;y=(i//4)*200;sheet.paste(im,(x,y));draw.text((x+6,y+184),f'{f/30:.3f}s',fill='white')
 sheet.save(P/f'qa/dense-{scene}.jpg')
items=['README.md','report.md','requirements.txt','package.json','package-lock.json','timeline.json','make-plan.py','music.py','inputs-manifest.json','effects-plan.json','transcript.json','guide.md','build-delivery.py']
items += [str(f.relative_to(P)) for f in (P/'src').rglob('*') if f.is_file()]
items += [str(f.relative_to(P)) for f in (P/'audio').glob('*.wav') if f.name!='mix.wav']
items += [str(f.relative_to(P)) for f in (P/'qa').glob('*') if f.is_file() and (f.suffix in ['.json','.jpg','.txt'] or f.name in ['preview.mp4','preview-final.mp4']) and f.name!='poses.jpg']
with zipfile.ZipFile(d/'01-microwave-below-zero-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for item in sorted(set(items)):
  if (P/item).is_file():z.write(P/item,'bradikinin/'+item)
print('Built delivery:',[(f.name,f.stat().st_size) for f in d.iterdir()])
