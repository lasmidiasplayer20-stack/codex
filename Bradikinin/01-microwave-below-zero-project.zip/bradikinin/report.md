# Relatório de produção

- Inputs: MP3 MiniMax anexado (275,644082 s) e MP4 de referência (272,788027 s). SHA-256 e metadados estão em inputs-manifest.json. Originais preservados por links locais somente; não incluídos no bundle nem no commit.
- O texto recebido começa no fim da seção anterior à 15; não havia as seções iniciais completas. As instruções disponíveis foram seguidas com decisões documentadas.
- Filme original: 41 cenas, 960×540, 30 fps, 8270 quadros. Duração de vídeo 275.666667 s, áudio 275.612000 s. Contêiner 275.666667 s. H.264/yuv420p + AAC 192 kbps, faststart. Tamanho 8985097 bytes.
- SHA-256 do MP4: `658355b27abe62b99dd3c5bfdd4b66841a83299be0e87a6dbf01561e8984aec5`.
- Estética: diagramas brancos sobre preto, alertas vermelhos, áreas de monitoramento, tipografia sem serifa, gestos pequenos. Não há quadros reaproveitados do vídeo de referência.
- Narração: importada uma vez, andamento e sequência preservados; nenhuma faixa sonora da referência foi usada. Música local em ganho 0,15 e efeitos em ganho 0,3 antes do somatório com voz em ganho 1.
- Música original: drones, pulsos e notas sintetizadas em Python/NumPy, seed 1701, com três stems e fades contínuos.
- Efeitos: sintetizados localmente. Zero chamadas à ElevenLabs; nenhum consumo cobrado informado pelo provedor. A chave não estava configurada. O módulo Node opcional tem cache e não é chamado pelo render/mix; assets opcionais da API exigem integração explícita ao plano.
- Render: Canvas 2D nativo em Node para os PNGs finais; Puppeteer/Chromium para prévia representativa do mesmo desenho. Render por cena e intervalos semiabertos; PNGs em cache fora do bundle. Uso observado de disco para frames: cerca de 250 MB; tempo por cena registrado no console, geralmente 2–9 s no ambiente atual.

## Verificações automáticas executadas

- Cobertura contínua da timeline e existência de cada PNG esperado; contagem do MP4 coincide com ceil(T×30).
- Decodificação integral do MP4 passou. Vídeo e mix cobrem toda a voz sem `-shortest`.
- Erro máximo de comprimento dos membros: 2.13e-14 unidades; erro máximo do alvo dos pés: 3.97e-15; excesso de alcance solicitado: 0.
- Ângulo interno dos cotovelos: 68.36°–147.96°. Joelhos: 90.00°–164.32°. Lados da solução IK definidos por pose, sem inversão aleatória.
- Deriva máxima do pé em apoio no mundo: 1.14e-13 px, em 700 comparações a 30 fps nos dois sentidos de caminhada. Não mede todos os possíveis contatos de cena.
- Mix tem exatamente a faixa de voz escolhida no grafo. Medição de pico/RMS está em qa/audio-stats.txt. Isso não equivale a escuta humana.

## Inspeção visual e limites

Folha de contato de todas as cenas e sequências densas de caminhada, reflexo e maçaneta examinadas. Foram corrigidos o repouso excessivamente agachado, alvos fora do alcance, orientação do cotovelo levantado, contato com o botão e maçaneta. As silhuetas mantêm cabeça e torso rígidos; objetos usam dimensões constantes em cada enquadramento. Mudanças de enquadramento e a escala uniforme do reflexo infantil são intencionais.

A fala foi analisada com PocketSphinx local. O download do modelo Whisper foi negado pela política de rede. A transcrição bruta tem erros e é identificada como automática; os títulos são rótulos editoriais, não legendas verbatim. A sincronização é por frases e ações, não por fonemas, e não recebeu escuta humana. Não se afirma naturalidade perfeita ou ausência absoluta de artefatos. A prévia em Chromium foi renderizada; a inspeção de movimento ocorreu por sequências densas, sem reprodução audiovisual humana.

Não havia chave ElevenLabs. O caminho de outputs solicitado pelo cliente não existe neste executor e seu diretório raiz é somente leitura; a entrega foi preparada em delivery/. Após autorização explícita do usuário, os quatro arquivos foram publicados na branch bradikinin-01-20261016. Commit inicial da entrega: 4e3b83bf043d8ffd9ca2e96c6da7648b4c3e9f42. O SHA-256 do MP4 recuperado via Git foi conferido e coincide com o arquivo local validado. Outros episódios não foram alterados. O bundle reproduzível não contém os inputs pessoais, a voz ou o mix com voz: o usuário deve recolocar o MP3 original em inputs/narration.mp3. Não foram geradas legendas literais a partir da transcrição incerta.

## GitHub

O exportador verifica tamanho, ffprobe e hash local antes do commit, adiciona apenas os arquivos listados, faz push comum e confirma branch/commit remoto e SHA-256 dos bytes do MP4 via fetch/Git. O registro da execução fica em qa/github-export.json após o envio; não se confunde criar o script com efetuar a publicação.
