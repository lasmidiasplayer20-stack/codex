Renderize em 960×540, mantendo o frame rate final. Examine o começo, o meio e o fim do gesto; use uma sequência densa de quadros para conferir pés, mãos e articulações. Se for possível reproduzir o trecho, avalie também a fluidez em movimento.

Corrija problemas e continue até o vídeo completo. A prévia é uma etapa de verificação; não exige aprovação conversacional por padrão. Se o usuário pediu revisão antes do render final, respeite esse pedido.

## 15. Renderize e monte o vídeo final

Renderize por cena em uma sequência de PNGs, com intervalos e nomes de frames consistentes. Isso permite retomar uma falha sem refazer todo o vídeo. Evite guardar múltiplas cópias desnecessárias dos frames; estime espaço em disco e tempo de render antes da execução completa.

Defina a duração pelo áudio real. Para `T` segundos a `fps` frames por segundo, use pelo menos `ceil(T * fps)` frames para cobrir a gravação. Na timeline, documente se os intervalos são fechados ou semiabertos; não duplique o frame do corte entre duas cenas.

Crie um vídeo silencioso com a resolução e o frame rate definidos. Depois associe explicitamente o mix já concluído. Exemplo de montagem em JavaScript; os caminhos pressupõem que os arquivos já foram produzidos:

```javascript
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

const probe = JSON.parse(execFileSync('ffprobe', [
  '-v', 'error', '-show_format', '-show_streams', '-of', 'json',
  'inputs/narration.m4a'
], { encoding: 'utf8' }));
const stream = probe.streams.find(s => s.codec_type === 'audio');
if (!stream) throw new Error('A narração não contém uma faixa de áudio.');
const duration = Number(stream.duration ?? probe.format.duration);
if (!Number.isFinite(duration) || duration <= 0) {
  throw new Error('Duração de áudio inválida.');
}
mkdirSync('output', { recursive: true });
execFileSync('ffmpeg', [
  '-y', '-i', 'renders/silent.mp4', '-i', 'audio/mix.wav',
  '-map', '0:v:0', '-map', '1:a:0',
  '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k',
  '-t', duration.toFixed(6), '-movflags', '+faststart', 'output/final.mp4'
], { stdio: 'inherit' });
```

Antes dessa montagem, verifique que tanto o vídeo silencioso quanto o mix cobrem a duração da narração. O vídeo silencioso deve usar H.264, `yuv420p` e dimensões pares. O exemplo copia esse vídeo sem recodificar e codifica o mix em AAC; não promete identidade binária com o áudio original. Durações de contêiner podem variar alguns milissegundos por quantização e codec.

Não use `-shortest` para esconder um render visual incompleto. Não corte o fim da fala. Se houver silêncio final que precise ser removido, trate isso como uma decisão explícita de edição.

## 16. Verifique o resultado

### Personagens e objetos

- Proporções e comprimentos dos membros permanecem constantes.
- Cabeças e troncos não esticam durante os gestos.
- Cotovelos e joelhos mantêm uma dobra consistente.
- Pés não deslizam durante apoio; mãos mantêm os contatos planejados.
- Objetos não atravessam superfícies nem mudam de tamanho sem motivo narrativo.
- O estado dos personagens continua coerente entre cenas consecutivas.

### Imagem e som

- O texto cabe no enquadramento e pode ser lido em tamanho reduzido.
- A sequência visual acompanha a fala correspondente.
- A narração aparece uma única vez e segue na velocidade original.
- A faixa do vídeo de referência não foi misturada ao resultado.
- Música e efeitos não mascaram as instruções da voz.
- Efeitos correspondem aos pontos de contato, cliques e mudanças de estado.
- A trilha possui progressão e suas transições não têm cliques ou emendas bruscas.
- O fim do áudio está presente e o vídeo cobre sua duração.
- Não há frames faltantes, pretos acidentais ou cortes duplicados.
- Interferências não ocultam informação essencial.

### Reprodutibilidade

- Código, configuração, seed e versões utilizadas estão registrados.
- É possível renderizar uma cena isolada e retomar a produção.
- O relatório distingue verificações automáticas de inspeção visual/auditiva.
- Limitações ou etapas não executadas aparecem claramente.
- Segredos não estão no bundle nem nos arquivos entregues.
- Os efeitos em cache evitam novas chamadas cobradas ao renderizar outra vez.
- O projeto inclui o plano de efeitos e os stems musicais para remixagem.

Faça verificações direcionadas: constância dos segmentos, erro de contato dos pés, cobertura da timeline, existência de frames e integridade do MP4. Inspecione poses extremas e transições. Não considere um render aprovado apenas porque o FFmpeg terminou sem erro.

## 17. Entregue

Forneça o MP4 final, uma prévia, as legendas quando geradas, uma folha de contato, o código JavaScript, o script Python da música, os manifests e os arquivos de áudio usados. Preserve os originais do usuário.

O `README.md` deve conter os comandos realmente implementados, dependências e versões. Ofereça etapas separadas de análise, geração de efeitos, música, prévia, render e mixagem, além de uma orquestração completa. Reexecutar apenas o render ou o mix não deve disparar novas gerações na API. Não invente comandos de um renderizador que ainda não existe. O `report.md` deve registrar inputs, duração, decisões visuais, efeitos gerados/reutilizados, consumo informado pelo provedor, validações e limitações.

Na resposta final, diga o que foi produzido, onde baixar e qualquer limitação material. Não anuncie naturalidade, sincronização exata ou avaliação sonora sem ter realizado as verificações correspondentes.

## 18. Render completo e exportação ao GitHub

### Identifique o destino

Use o repositório conectado ao projeto do Codex. Quando houver um checkout Git, inspecione seu estado, a identidade do remoto e a branch de trabalho, sem revelar tokens eventualmente presentes na URL. Confirme acesso pelo mecanismo de autenticação disponível. Não crie outro repositório nem suponha um nome de conta.

Se existir um único destino inequívoco no contexto do projeto, use-o. Se vários repositórios estiverem conectados e não houver seleção de projeto/remoto, peça apenas a identificação do destino; enquanto isso, conclua o render local. Conexão de um aplicativo GitHub não prova que o processo local tem credenciais de push.

### Produza o artefato antes de exportar

A execução completa deve terminar em um MP4 real, com imagem, narração importada, efeitos e música. Não entregue apenas uma pasta de código, um storyboard ou um vídeo de título como se fossem o episódio final. Se faltar a narração correspondente ao roteiro, conclua o projeto e sinalize esse input específico; não use por engano o áudio de outro episódio nem gere uma voz sem solicitação.

Depois da revisão, copie o MP4 para o checkout do repositório, com o caminho relativo exato:

```text
Bradikinin/
  01-microwave-below-zero.mp4
  01-microwave-below-zero-cover.png
  README.md
```

O MP4 é a entrega obrigatória. Inclua a capa já fornecida/produzida e um README curto com duração, resolução, frame rate e instrução de download. Para outros episódios, mantenha a pasta `Bradikinin` e use nomes distintos. Preserve arquivos existentes e não substitua um episódio diferente.

Os fontes podem ser entregues localmente junto ao projeto; enviar todos ao GitHub exige escopo compatível com o pedido. Não envie inputs de referência, áudios originais, caches, logs, `node_modules`, segredos ou arquivos pessoais apenas porque estão no mesmo diretório.

### Tamanho e formato

Use H.264 com `yuv420p`, áudio AAC, resolução final definida e `+faststart`. Verifique o tamanho antes do commit. A meta inicial de 80 MB oferece margem para o fluxo Git comum, mas não substitui verificar os limites atuais do host e do método de envio.

O GitHub bloqueia arquivos acima de seu limite de arquivo comum, normalmente 100 MiB. Se o MP4 estiver grande, avalie uma recodificação com qualidade aceitável e confira textos, linhas e interferências. Para uma duração T, o orçamento aproximado de bits por segundo é `bytes_alvo * 8 / T`, descontando áudio e contêiner; CRF sozinho não garante tamanho máximo.

Se o vídeo precisar continuar acima do limite, use Git LFS somente quando disponível, autorizado e com armazenamento/banda suficientes. Restrinja a regra de LFS ao artefato ou padrão relevante dentro de `Bradikinin`; não altere o tratamento de todos os arquivos do repositório sem necessidade. Envie o objeto LFS, não apenas seu ponteiro. Não troque silenciosamente o MP4 solicitado por um link de Release ou de outro serviço.

### Envie por um caminho que aceite binário

Implemente `src/node/github-export.mjs` usando Git CLI autenticado ou uma API que aceite bytes/base64 de arquivo binário. Não use uma ferramenta que cria apenas texto UTF-8 para enviar um MP4: transformar bytes de vídeo em texto corrompe o arquivo.

O fluxo deve:

1. Conferir `ffprobe`, duração, tamanho e hash SHA-256 do MP4 local.
2. Confirmar o destino e a branch de trabalho identificados no projeto.
3. Criar a pasta `Bradikinin`, preservando os demais arquivos e alterações do usuário.
4. Copiar o MP4, a capa e o README para os caminhos definidos.
5. Adicionar ao Git apenas os arquivos da entrega, mais `.gitattributes` se o LFS o exigir. Não usar `git add .` indiscriminadamente.
6. Fazer um commit descritivo e push comum, sem force push nem reescrita de histórico.
7. Tratar rejeições de push sem descartar mudanças locais ou remotas.
8. Verificar o artefato remoto e fornecer o link do arquivo na branch enviada.

Quando possível, baixe o payload remoto e compare seu SHA-256 ao arquivo local. Um SHA de commit ou blob Git não é o SHA-256 do MP4. Em LFS, confirme que o conteúdo de mídia está disponível; obter apenas um arquivo-texto de ponteiro não comprova a entrega.

Se a autenticação ou o tamanho bloquear o envio, preserve o vídeo local, conclua as demais entregas e explique o motivo. Não declare que o vídeo está no GitHub só porque o commit local foi criado. Gerar código de exportação também não equivale a realizar o push.

### Se a execução usar GitHub Actions

Guarde a nova chave em um segredo chamado `ELEVENLABS_API_KEY` e injete-a somente no processo de geração de efeitos. Use as permissões mínimas necessárias para o envio solicitado, mantenha os originais fora dos artifacts e não habilite geração paga automaticamente em eventos externos. No fluxo padrão, renderizar novamente a partir de assets em cache não deve gerar efeitos pagos outra vez.

## Pedido curto para reutilizar com este guia

> Crie um vídeo original a partir do áudio importado e da referência visual anexada. Siga este documento. Use JavaScript com Node.js, Canvas 2D, Puppeteer e Matter.js para cenário, personagens, física e renderização. Use a API da ElevenLabs pelo Node.js para efeitos sonoros, com cache e chave em segredo de ambiente; use Python para compor e sintetizar a música original localmente. Use peças rígidas articuladas, proporções constantes, IK sem stretch, pés com contato estável e física leve para objetos. Faça a encenação acompanhar a narração, com movimentos de intenção e peso. Analise a referência, planeje a timeline, renderize um trecho representativo, corrija os problemas e conclua o vídeo com FFmpeg. Preserve a voz e a duração do áudio. Envie o MP4 final para `Bradikinin/01-microwave-below-zero.mp4` no repositório GitHub conectado ao projeto, com a capa e um README, e verifique o envio. Entregue também o projeto reproduzível. Resolva decisões rotineiras sem pedir confirmação; registre limitações reais e respeite qualquer revisão prévia que eu tenha pedido.