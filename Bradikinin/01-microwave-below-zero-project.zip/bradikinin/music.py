"""Original deterministic suspense score + local foley. No remote generation."""
import json,wave
from pathlib import Path
import numpy as np
P=Path(__file__).parent;sr=24000;D=json.load(open(P/'timeline.json'))['duration'];N=int(np.ceil(D*sr));rng=np.random.default_rng(1701)
(P/'audio').mkdir(exist_ok=True)
def write(name,a):
 a=np.clip(a,-.98,.98)
 with wave.open(str(P/'audio'/name),'wb') as w:w.setnchannels(1 if a.ndim==1 else a.shape[1]);w.setsampwidth(2);w.setframerate(sr);w.writeframes((a*32767).astype('<i2').tobytes())
def add(a,time,sound,gain=1):
 i=round(time*sr);n=min(len(sound),len(a)-i)
 if n>0:a[i:i+n]+=sound[:n]*gain
n=np.arange(N,dtype=np.float64)/sr
fade=np.minimum(np.clip(n/3,0,1),np.clip((D-n)/4,0,1))
# Smooth additive drone, phase continuous; subtle motion follows the seven rules.
roots=[36.7081,41.2034,43.6535,36.7081,32.7032,34.6478,36.7081]
starts=[0,57.99,89.97,119.1,150.84,180.1,211.89,D]
freq=np.full(N,roots[0])
for j in range(1,7):
 q=np.clip((n-starts[j])/3,0,1);q=q*q*(3-2*q);freq=freq*(1-q)+roots[j]*q
phase=2*np.pi*np.cumsum(freq)/sr
drone=(np.sin(phase)*.15+np.sin(phase*1.501)*.07+np.sin(phase*2+.05*np.sin(n*.3))*.045)*(1+.13*np.sin(n*.23))*fade
write('stem-drone.wav',drone)
pulse=np.zeros(N,dtype=np.float32);tones=np.zeros(N,dtype=np.float32)
for time in np.arange(2,D-3,1.5):
 x=np.arange(int(sr*.55))/sr;env=np.sin(np.pi*np.clip(x/.55,0,1))**2*np.exp(-x*7)
 add(pulse,time,np.sin(2*np.pi*(53*x-13*x*x))*env,.12)
notes=[146.832,174.614,220,164.814,130.813,196,138.591]
for i,time in enumerate(np.arange(9,D-5,6)):
 x=np.arange(sr*4)/sr;env=(1-np.exp(-x*40))*np.exp(-x*1.4)*np.clip((4-x)*8,0,1);f=notes[i%len(notes)]
 sound=(np.sin(2*np.pi*f*x)+.25*np.sin(2*np.pi*2.003*f*x))*env*.1
 add(tones,time,sound)
 for delay,g in [(0.32,.25),(.67,.12)]:add(tones,time+delay,sound,g)
write('stem-pulse.wav',pulse*fade);write('stem-tones.wav',tones*fade)
write('music.wav',(drone+pulse+tones)*.45)
fx=np.zeros(N,dtype=np.float32);events=[]
def event(time,kind):
 if kind=='knock':
  x=np.arange(int(sr*.22))/sr;s=(np.sin(2*np.pi*180*x)+rng.normal(0,.3,len(x)))*np.exp(-x*30);s*=np.clip(x/.003,0,1);gain=.15
 elif kind=='beep':
  x=np.arange(int(sr*.16))/sr;s=np.sin(2*np.pi*880*x)*np.sin(np.pi*x/.16)**2;gain=.12
 elif kind=='click':
  x=np.arange(int(sr*.035))/sr;s=rng.normal(0,1,len(x))*np.exp(-x*160)*np.clip(x/.002,0,1);gain=.09
 else:
  x=np.arange(int(sr*.8))/sr;s=(np.sin(2*np.pi*(120*x+90*x*x))*.3+rng.normal(0,.1,len(x)))*np.sin(np.pi*x/.8)**2;gain=.06
 add(fx,time,s,gain);events.append(dict(time=time,kind=kind,source='local-synthesis',gain=gain))
for time in [54.5,55.4,56.2]:event(time,'knock')
for time in [1.25,12,16,63.2,226,228.8]:event(time,'click')
for time in [241.2,241.55,241.9]:event(time,'beep')
for time in [28.9,65.95,93.8,107.4,132.2,195.9,250.2,261.98]:event(time,'transition')
write('effects.wav',fx)
(P/'effects-plan.json').write_text(json.dumps(dict(seed=1701,sample_rate=sr,provider='local fallback; ElevenLabs key not configured',events=events),indent=2))
print('Score, 3 stems and local effects:',N,'samples')
