# V4 — animação com rig próprio

Os bonecos desta versão são modelos com articulações nomeadas e 33 poses-base.
A coreografia tem 176 keyframes escritos em `author-choreography.py`; não são
contornos extraídos do vídeo. O renderer usa os ossos e controles de pose para
desenhar círculos e curvas próprias. O áudio original é preservado.

A referência orientou posição, escala, cortes e sequência das ações. Os objetos
usam modelos geométricos e parâmetros de cenário calibrados na referência,
armazenados em `stage-data.json`. O projeto não contém frames, imagens, máscaras
raster, contornos vetorizados, fluxos ópticos ou o MP4 original como camada visual.
A coreografia e os detalhes de cenário são aproximações dirigidas, não uma cópia
pixel a pixel nem uma simulação física autônoma de toda a cena.

## Movimento

`authored-rig.js` anima um esqueleto 2.5D com comprimentos 3D constantes. A projeção
pode encurtar um segmento em poses inclinadas; os ossos não mudam sua dimensão 3D.
Câmera e proporções são controles explícitos, sem heurística que confunda um pé
com uma cabeça. Curvas arredondadas tornam o corpo mais flexível.

As pernas usam apoio de pés e IK durante a caminhada. Pulos e objetos soltos usam
trajetórias balísticas; impactos usam molas amortecidas analíticas. As armas são
presas à mão; keyframes de golpe alinham a arma ao alvo. A espada solta continua
sua posição de lançamento e cai com gravidade e arrasto. Há contatos próprios
para o bloqueio da lâmina e para segurar o pé do adversário. Os efeitos e objetos
são modelos desenhados por código. Motion 14.1.0 fornece easing e mistura.

## Abrir, editar e exportar

Para abrir o player, sirva esta pasta por HTTP, por exemplo:

```
python3 -m http.server 8000
```

Para editar, altere as poses e keyframes em `author-choreography.py` e regenere:

```
python3 author-choreography.py
```

Para conferir e renderizar, instale Node, FFmpeg e Chromium e execute:

```
npm ci
node inspect-authored.mjs validation-authored
node render.mjs --output recriacao-codigo-v4-1080p60.mp4
python3 validate-export.py recriacao-codigo-v4-1080p60.mp4
```

Os scripts usam `/usr/bin/chromium`; adapte o caminho no seu ambiente. A geração
foi feita na máquina em nuvem, sem instalar nada no computador do usuário.

## Verificação

O relatório verifica o rig durante toda a duração a 60 fps, comprimentos 3D,
contato da arma, bloqueio da lâmina, golpes, soltura sem teleporte, parte cortada,
retorno dos personagens no final e controles do player. Prévia codificada e
comparação visual são necessárias: matemática consistente não prova fidelidade.
A exportação é verificada por decodificação integral, duração e pacotes AAC.
