import {chromium} from '@playwright/test';import{createServer}from'node:http';import{readFile,writeFile,mkdir}from'node:fs/promises';import{dirname,resolve,extname}from'node:path';import{fileURLToPath}from'node:url';import{once}from'node:events';import assert from'node:assert/strict';
const root=dirname(fileURLToPath(import.meta.url)),out=resolve(process.argv[2]||resolve(root,'validation-authored'));await mkdir(out,{recursive:true});
const server=createServer(async(req,res)=>{try{const p=resolve(root,'.'+(req.url==='/'?'/index.html':req.url));if(!p.startsWith(root+'/'))throw Error();res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.m4a':'audio/mp4'})[extname(p)]||'application/octet-stream');res.end(await readFile(p));}catch{res.writeHead(404);res.end();}});server.listen(0,'127.0.0.1');await once(server,'listening');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const page=await browser.newPage(),errors=[],requests=[];page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>requests.push(r.url()));await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>Boolean(window.film));
 const times=[.5,2,3,3.1,5,7.5,9.4,10.5,11.9,12.45,15.1,17.7,20,22.1,23,25,31,34,38.75,41.5,42,45,50,53.42,55,55.65,57.4,59,62.2,65,67.8,69,72,75.1,76,77.5,79,82,84,84.6,87,89,90.1,92,93,94.5];
 const report=await page.evaluate(times=>{let poses=0,maxBoneError=0,finite=true,maxGripError=0;
  for(let t=0;t<film.duration;t+=1/60)for(const name of Object.keys(FILM_DATA.tracks)){
   const p=film.rigAt(name,t);if(!p)continue;poses++;finite&&=[p.r,...p.nodes3.flat()].every(Number.isFinite);
   for(let j=1;j<11;j++){const a=p.nodes3[j],b=p.nodes3[ElasticRig.parents[j]],len=Math.hypot(...a.map((v,k)=>v-b[k]));maxBoneError=Math.max(maxBoneError,Math.abs(len/(p.profile[j]*p.r)-1));}
   const kind=name==='red'?(t<13?'sword':'mace'):name==='green'?'knife':null,o=kind?film.weaponAt(kind,t):null;
   if(o?.grip){const grip=p.nodes[p.pose==='stomp'?6:4];maxGripError=Math.max(maxGripError,Math.hypot(grip[0]-o.grip[0],grip[1]-o.grip[1]));}
  }
  const crop=film.rigAt('red',62.2),hand=film.rigAt('orange',65).nodes[4],foot=film.rigAt('red',65).nodes[8],interactionDistance=Math.hypot(hand[0]-foot[0],hand[1]-foot[1]);
  const finalActors=['red','cyan'].map(name=>{const p=film.rigAt(name,92);return{name,visible:Boolean(p&&p.nodes[2][0]>0&&p.nodes[2][0]<960&&p.nodes[2][1]>0&&p.nodes[2][1]<540)};});
  const deterministic=times.every(t=>{film.draw(t);const a=film.canvas.toDataURL();film.draw(t+.037);film.draw(t);return a===film.canvas.toDataURL();});
  const impactDistances=[53.42,55.65,57.4].map(t=>{const h=film.rigAt('orange',t).nodes[2],o=film.weaponAt('mace',t);return{t,distance:Math.hypot(h[0]-o.a[0],h[1]-o.a[1])};});
  const before=film.weaponAt('sword',12.25-.00001),after=film.weaponAt('sword',12.25),releaseJump=Math.max(...['a','b'].map(k=>Math.hypot(before[k][0]-after[k][0],before[k][1]-after[k][1])));
  return {posesAt60fps:poses,finite,maxBoneError,maxGripError,interactionDistance,impactDistances,releaseJump,greenAbsentInCloseup:film.rigAt('green',34)===null,croppedHeadOutside:Boolean(crop&&crop.nodes[2][1]<0),cropFoot:crop.nodes[8],finalActors,deterministic,authoredKeys:Object.fromEntries(Object.entries(FILM_DATA.tracks).map(([k,v])=>[k,v.length])),namedPoses:Object.keys(FILM_DATA.poseLibrary).length,metrics:film.metrics};
 },times);
 assert(report.finite&&report.deterministic);assert(report.maxBoneError<1e-7,'An anatomical bone changed its 3D length');assert(report.maxGripError<1e-6,'A weapon left its hand');assert(report.interactionDistance<6,'The hand missed the attacking foot');assert(report.croppedHeadOutside);assert(report.finalActors.every(p=>p.visible));
 assert(report.impactDistances.every(p=>p.distance<6),'An authored strike missed its target');assert(report.releaseJump<.1,'The released sword teleported');assert(report.greenAbsentInCloseup);assert(Math.hypot(report.cropFoot[0]-701.54,report.cropFoot[1]-337.59)<2,'A cropped foot changed its authored staging');
 for(const t of times){const data=await page.evaluate(t=>{film.draw(t);return film.canvas.toDataURL('image/png').split(',')[1];},t);await writeFile(resolve(out,`frame-${t}.png`),Buffer.from(data,'base64'));}
 await page.locator('#seek').fill('25');await page.locator('#play').click();await page.waitForTimeout(200);assert.equal(await page.locator('#play').textContent(),'Pausar');await page.locator('#play').click();assert.equal(await page.locator('#play').textContent(),'Reproduzir');assert.equal(errors.length,0);
 assert(requests.every(r=>!r.endsWith('.mp4')&&!/\.(png|jpg|webp)/.test(r)));assert(requests.every(r=>!/(vector-data|prop-flow|motion-data|capture)/.test(r)));
 report.assetRequests=requests.map(r=>new URL(r).pathname);report.errors=errors;report.playerControlsVerified=true;await writeFile(resolve(out,'player-validation.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await browser.close();await new Promise(r=>server.close(r));}
