/* All visuals are generated from bones and named object parameters. */
(()=>{'use strict';
const D=FILM_DATA,W=D.width,H=D.height,T=D.duration,canvas=document.querySelector('#film'),ctx=canvas.getContext('2d',{alpha:false});
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),mix=(a,b,u)=>Motion.mix(a,b)(u),ease=Motion.cubicBezier(.25,.1,.25,1),TAU=Math.PI*2,rand=x=>{const y=Math.sin(x*127.1+311.7)*43758.5453;return y-Math.floor(y);};
const metrics={finite:true,sourceVideoPixelsUsed:0,motionVersion:'14.1.0',method:'Authored named-joint 2.5D rigs, semantic keyframes, IK contacts, analytic springs and code-generated props; no vectorized outlines'};
function indexAt(v,t){return ElasticRig.indexAt(v,t);}
function rect(x,y,w,h,fill){ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);}
function line(points,color,width=2){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.lineCap=ctx.lineJoin='round';ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
function circle(x,y,r,color,stroke=null,width=2){ctx.beginPath();ctx.arc(x,y,Math.max(.1,r),0,TAU);if(color){ctx.fillStyle=color;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}}
function curve(a,b,c,color,width){ctx.beginPath();ctx.moveTo(...a);for(const segment of ElasticGeometry.curveControls(a,b,c))ctx.bezierCurveTo(...segment[1],...segment[2],...segment[3]);ctx.lineWidth=width;ctx.strokeStyle=color;ctx.lineCap='round';ctx.lineJoin='round';ctx.stroke();}
function text(s,x,y,size,color='#fff'){ctx.font=`500 ${size}px "DejaVu Sans",sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=color;ctx.fillText(s,x,y);}
function sceneAt(t){const i=indexAt(D.scenes,t),a=D.scenes[i],b=D.scenes[Math.min(i+1,D.scenes.length-1)],u=clamp((t-a.t)/Math.max(.001,b.t-a.t),0,1);const cut=Math.abs(a.floor-b.floor)>100||Math.hypot(...a.color.map((x,j)=>x-b.color[j]))>70;return {a,b,u,cut,color:a.color.map((x,j)=>cut?(t<b.t?x:b.color[j]):mix(x,b.color[j],u)),floor:cut?(t<b.t?a.floor:b.floor):mix(a.floor,b.floor,u)};}
function background(s){const [r,g,b]=s.color;const gradient=ctx.createLinearGradient(0,0,W,H);gradient.addColorStop(0,`rgb(${r*.8},${g*1.04},${b*1.03})`);gradient.addColorStop(1,`rgb(${r*.6},${g*.76},${b*.84})`);ctx.fillStyle=gradient;ctx.fillRect(0,0,W,H);
 for(let i=0;i<45;i++){const x=rand(i*7)*W,y=rand(i*11)*H;ctx.globalAlpha=.007;circle(x,y,40+rand(i*9)*100,i%2?'#001821':'#60b4c3');}ctx.globalAlpha=1;rect(0,s.floor,W,H-s.floor,'#0b0c0d');}
function drawingRig(name,t){return ElasticRig.at(name,t);}
function actor(name,t){const p=drawingRig(name,t);if(!p)return;const n=p.nodes,r=p.r,color=D.cast[name].rgb,width=r*(name==='orange'?.47:.39);
 ctx.save();if(name==='green'&&t>26&&t<41.95){ctx.shadowColor='#bc1936';ctx.shadowBlur=r*.55;}
 if(p.partialChains){for(const chain of p.partialChains)curve(...chain,color,width);ctx.restore();return p;}
 for(const joints of [[0,7,8],[0,9,10],[1,3,4],[1,5,6]])if(!p.partial||joints[0]===1)curve(n[joints[0]],n[joints[1]],n[joints[2]],color,width);
 if(p.partial){if(p.partialHead)circle(n[2][0],n[2][1],p.partialHead,color);ctx.restore();return p;}
 ctx.save();if(D.cast[name].hollow){ctx.beginPath();ctx.rect(-W,-H,W*3,H*3);ctx.ellipse(n[2][0],n[2][1],Math.max(r*.65,p.shape[0]),Math.max(r*.65,p.shape[1]),(p.shape[2]||0)*Math.PI/180,0,TAU);ctx.clip('evenodd');}curve(n[0],n[1],n[2],color,r*(name==='orange'?.51:.43));ctx.restore();
 ctx.save();ctx.translate(...n[2]);ctx.rotate((p.shape[2]||0)*Math.PI/180);ctx.beginPath();ctx.ellipse(0,0,Math.max(r*.65,p.shape[0]),Math.max(r*.65,p.shape[1]),0,0,TAU);
 if(D.cast[name].hollow){ctx.strokeStyle=color;ctx.lineWidth=r*.34;if(name==='orange'&&t>=74.7){ctx.beginPath();ctx.arc(0,0,r,-Math.PI/6,Math.PI*7/6);ctx.stroke();const points=Array.from({length:13},(_,i)=>[-r*.866+i*r*1.732/12,-r*(.46+rand(i+31)*.20)]);line(points,color,r*.28);}else ctx.stroke();}else{ctx.fillStyle=color;ctx.fill();}ctx.restore();
 if(name==='orange'&&t>74.4){ctx.globalAlpha=.72;for(let i=0;i<7;i++){const x=n[2][0]+(rand(i+1)-.5)*r*1.4,y=n[2][1]-r*.45;line([[x,y],[x+r*.07,y+r*.30],[x-r*.07,y+r*.44]],'#1a1110',Math.max(.8,r*.045));}ctx.globalAlpha=1;}
 ctx.restore();return p;}
function bed(o){const{x,y,w,h}=o;const pillow=Math.min(w*.25,h*.8+w*.02),base=y+h,leg=o.legHeight??h*.65;rect(x,y-4,w,h+8,'#703f17');rect(x-2,base,w+4,7,'#8e642a');rect(x,base,5,leg,'#8b632d');rect(x+w-5,base,5,leg,'#8b632d');rect(x+2,y,pillow,h,'#dadacf');rect(x+4,y+2,pillow*.85,h*.45,'#f7f5e8');rect(x+pillow,y,w-pillow,h,'#aa071e');for(let i=0;i<12;i++)rect(x+pillow+i*(w-pillow)/12,y+rand(i)*h*.3,(w-pillow)/12,h*(.6+rand(i+1)*.4),i%3?'#96051a':'#bc122c');
 if(h>70)return;const pole=x-w*.30;line([[pole,y-4],[pole,y-h*3.8],[pole+w*.56,y-h*3.8]],'#233137',Math.max(1,w*.014));rect(pole+w*.53,y-h*3.8,w*.055,h*.65,'#8c0715');curve([pole+w*.57,y-h*3.2],[pole+w*.55,y-h*.9],[x+w*.47,y], '#400912',Math.max(1,w*.013));}
function pixelFlesh(o){const{x,y,w,h}=o;ctx.save();ctx.beginPath();ctx.ellipse(x+w*.5,y+h*.5,w*.54,h*.47,0,0,TAU);ctx.clip();const colors=['#631919','#a32d36','#d16453','#e6a084','#854a24','#497c16'];for(let i=0;i<95;i++){const size=Math.max(1,Math.min(w,h)*(.08+rand(i*5)*.16));rect(x+rand(i*13)*w,y+rand(i*19)*h,size,size,colors[Math.floor(rand(i*7)*colors.length)]);}ctx.restore();for(let i=0;i<4;i++)circle(x+w*(.25+i*.17),y+h*.55,h*.21,'#9e112c','#e1535b',Math.max(1,h*.025));}
function ribs(o){const{x,y,w,h}=o;if(w>=h*.45){curve([x,y+h*.4],[x+w*.5,y+h*.6],[x+w,y+h*.45],'#31e51c',h*.45);for(let i=0;i<Math.max(5,Math.min(24,w/h*3));i++){const xx=x+w*i/Math.max(5,Math.min(24,w/h*3));ctx.save();ctx.translate(xx,y+h*.5);ctx.rotate(.1);ctx.beginPath();ctx.ellipse(0,0,Math.max(1,h*.12),h*.36,0,0,TAU);ctx.strokeStyle=i%4?'#7b0019':'#ea173b';ctx.lineWidth=Math.max(1,h*.11);ctx.stroke();ctx.restore();}}
 else{ctx.save();ctx.translate(x+w*.5,y+h*.5);ctx.scale(w,h);circle(0,0,.45,'#2fe30c');for(let i=0;i<5;i++)rect(-.35+i*.17,-.42,.065,.84,'#5b0217');circle(-.12,-.05,.09,'#191208');circle(.15,-.05,.09,'#191208');rect(-.2,.13,.4,.1,'#511318');ctx.restore();}}
function prop(o,t){const{x,y,w,h}=o;
 if(o.kind==='bed')bed(o);
 else if(o.kind==='patient'){circle(x+w*.10,y+h*.37,h*.42,'#ecd421');curve([x+w*.19,y+h*.74],[x+w*.43,y+h*.45],[x+w*.91,y+h*.80],'#e8cf18',h*.32);}
 else if(o.kind==='yellow'){if(o.headCircle){const [cx,cy,r]=o.headCircle;ctx.beginPath();ctx.moveTo(x,y+h);ctx.lineTo(x+w,y+h);ctx.quadraticCurveTo(x+w*1.04,y+h*.76,x+w*.72,y+h*.80);ctx.quadraticCurveTo(x+w*.48,y+h*.20,x+w*.22,y+h*.75);ctx.closePath();ctx.fillStyle='#edca12';ctx.fill();circle(cx,cy,r,'#f0cf13');}else if(w>h*4)line([[x+h*.4,y+h*.5],[x+w-h*.4,y+h*.5]],'#f0cf15',h);else{circle(x+h*.35,y+h*.36,h*.34,'#f2cf13');curve([x+h*.5,y+h*.56],[x+w*.62,y+h*.72],[x+w,y+h*.66],'#ebc914',h*.32);}}
 else if(o.kind==='flesh')pixelFlesh(o);
 else if(o.kind==='ribs')ribs(o);
 else if(o.kind==='blood'){circle(x+w*.5,y+h*.5,Math.max(1,Math.min(w,h)*.40),'#700516');for(let i=0;i<18;i++){const xx=x+rand(i*11)*w,yy=y+rand(i*17)*h;rect(xx,yy,Math.max(1,w*.04),Math.max(1,h*.06),i%3?'#80051c':'#a80d21');}for(let i=0;i<5;i++)line([[x+w*.5,y+h*.5],[x+w*rand(i*9),y+h*rand(i*13)]],'#910a24',Math.max(.6,h*.045));}}
function props(t,s){const layer={bed:0,blood:1,yellow:2,flesh:3,ribs:4},items=[];
 if(s.cut){items.push(...(t<s.b.t?s.a:s.b).props);}else{
  const used=new Set();for(const p of s.a.props){let best=-1,cost=Infinity;
   s.b.props.forEach((q,j)=>{if(used.has(j)||p.kind!==q.kind)return;const c=Math.hypot((p.x+p.w/2)-(q.x+q.w/2),(p.y+p.h/2)-(q.y+q.h/2))+Math.abs(Math.log(Math.max(1,p.w)/Math.max(1,q.w)))*30;if(c<cost){cost=c;best=j;}});
   if(best>=0&&cost<Math.max(100,p.w*1.2)){const q=s.b.props[best];used.add(best);const o={...p};for(const k of ['x','y','w','h'])o[k]=mix(p[k],q[k],s.u);if(p.legHeight!==undefined&&q.legHeight!==undefined)o.legHeight=mix(p.legHeight,q.legHeight,s.u);if(p.headCircle&&q.headCircle)o.headCircle=p.headCircle.map((x,j)=>mix(x,q.headCircle[j],s.u));items.push(o);}else if(s.u<.5)items.push(p);
  }s.b.props.forEach((p,j)=>{if(!used.has(j)&&s.u>=.5)items.push(p);});
 }for(const o of items.sort((x,y)=>layer[x.kind]-layer[y.kind]))prop(o,t);}
function weaponAt(kind,t){
 if(kind==='sword'&&12.25<=t&&t<15.041667){
  const launch=ElasticRig.at('red',12.25),c=launch.control,hand=launch.nodes[4],half=c.weaponLength*launch.r/2,base=hand.map((v,k)=>v+[Math.cos(c.weaponAngle),Math.sin(c.weaponAngle)][k]*half),u=t-12.25,duration=.79,ground=439,landingAngle=c.weaponAngle+9*duration,landingY=ground-Math.abs(Math.sin(landingAngle)*half),vy=(landingY-base[1]-700*duration*duration)/duration,falling=u<duration,dt=Math.max(0,u-duration),angle=falling?c.weaponAngle+9*u:landingAngle+9*(1-Math.exp(-8*dt))/8,x=falling?80+(base[0]-80)*Math.exp(-6*u):80,y=falling?base[1]+vy*u+700*u*u:ground-Math.abs(Math.sin(angle)*half),v=[Math.cos(angle)*half,Math.sin(angle)*half];
  return{kind,a:[x+v[0],y+v[1]],b:[x-v[0],y-v[1]],width:launch.r*.15,released:true};
 }
 if(kind==='sword'&&30.916667<=t&&t<44)return{kind,a:[36,465],b:[10,424],width:4};
 if(kind==='knife'&&41.75<=t&&t<62)return{kind,a:[70,405],b:[50,451],width:5};
 const name=kind==='knife'?'green':'red',p=ElasticRig.at(name,t);if(!p)return null;
 if((kind==='sword')!==(t<13)&&name==='red')return null;
 if(kind==='knife'&&t>=41.75)return null;
 const c=p.control,j=p.pose==='stomp'?6:4,grip=p.nodes[j],angle=c.weaponAngle,length=c.weaponLength*p.r,dir=[Math.cos(angle),Math.sin(angle)];
 if(kind==='mace')return {kind,a:grip.map((v,k)=>v+dir[k]*length*c.gripFraction),b:grip.map((v,k)=>v-dir[k]*length*(1-c.gripFraction)),width:p.r*.32,headSize:p.r*1.7,grip:grip.slice(),physicalLength:8*p.r};
 return {kind,a:grip.map((v,k)=>v+dir[k]*length),b:grip.slice(),width:p.r*(kind==='sword'?.15:.12),grip:grip.slice()};
}
function weapon(o){if(!o)return;const a=o.a,b=o.b,dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy),angle=Math.atan2(dy,dx);if(o.kind==='mace'&&44<=window.filmTime&&window.filmTime<47.7){const r=o.headSize/1.7;for(let j=0;j<3;j++){const points=Array.from({length:8},(_,i)=>[a[0]-i*r*.48,a[1]+(j-1)*r*.1+Math.sin(i*.8-window.filmTime*11+j)*r*.09+i*r*.018]);line(points,'#080c0f',r*.065);}}ctx.save();ctx.translate(...a);ctx.rotate(angle);
 if(o.kind==='mace'){const size=o.headSize||clamp(length*.10,9,55),shaft=clamp(o.width,2,40);rect(0,-shaft*.6,length,shaft*1.2,'#74334d');rect(0,-shaft*.45,length,shaft*.45,'#cc7499');rect(0,-shaft*.13,length,shaft*.17,'#f3aac7');for(let j=0;j<5;j++)rect(length*(.84+j*.028),-shaft*.9,length*.015,shaft*1.8,'#a55e80');rect(-size*.4,-size*.65,size*.85,size*1.3,'#532e40');rect(-size*.28,-size*.53,size*.65,size*1.05,'#718075');rect(-size*.25,-size*.48,size*.60,size*.95,'#465b51');for(let j=0;j<6;j++){rect(size*.20,-size*.25+j*size*.10,size*(.5+rand(j)*.35),size*.06,'#ae1734');rect(-size*.15,-size*.20+j*size*.09,size*.4,size*.05,'#253930');}}
 else if(o.kind==='sword'){const size=clamp(o.width,2,9);for(let j=0;j<Math.max(4,length/size);j++)rect(j*size*.8,-size*(j%2?.45:.15),size,size, j%2?'#33cfc1':'#90fff1');rect(length*.83,-size*1.4,size*.4,size*2.8,'#286d67');rect(length*.83,-size*.3,length*.16,size*.6,'#553d2b');}
 else{const size=clamp(o.width,2,8);rect(0,-size*.5,length*.72,size,'#8fc3c6');rect(0,-size*.5,length*.72,size*.25,'#d5e9da');rect(length*.72,-size*.6,length*.28,size*1.2,'#51554a');}ctx.restore();}
function effects(t){
 const p=ElasticRig.at('orange',t);if(p&&((2<=t&&t<12.2)||(30.916667<=t&&t<44))){const n=p.nodes[2],r=p.r*.24,x=n[0]+p.r*(p.pose==='headHold'?-.2:.75),y=n[1]+p.r*(p.pose==='headHold'?.92:.27);ctx.save();ctx.translate(x,y);ctx.rotate(Math.sin(t*7)*.10);ctx.shadowColor='#bcff8b';ctx.shadowBlur=r*.7;ctx.beginPath();for(let j=0;j<12;j++){const a=j*TAU/12,d=j%2?r*.22:r;ctx[j?'lineTo':'moveTo'](Math.cos(a)*d,Math.sin(a)*d);}ctx.closePath();ctx.fillStyle='#e7ffd1';ctx.fill();ctx.restore();}
 if(p&&38.1<t&&t<44){const a=[p.nodes[2][0]-p.r*.2,p.nodes[2][1]+p.r*.92],target=t<40.55?[a[0]-25,515]:(t<41.8?[430,428]:[a[0]+160,-120]),width=4+Math.sin(t*37);const points=Array.from({length:12},(_,i)=>{const u=i/11;return[mix(a[0],target[0],u)+Math.sin(i*9+t*31)*width*Math.sin(u*Math.PI),mix(a[1],target[1],u)];});ctx.save();ctx.shadowColor='#65ff28';ctx.shadowBlur=15;line(points,'#59fb1f',width*2);line(points,'#eeffd9',1.5);ctx.restore();}
 for(const at of [53.42,55.65,57.4,62.0,68.3,70.9,74.7]){const dt=t-at;if(dt>=0&&dt<.20){const target=ElasticRig.at('orange',at);if(!target)continue;const h=target.nodes[2];for(let j=0;j<8;j++){const a=rand(j+at)*TAU,speed=35+rand(j*5+at)*100;circle(h[0]+Math.cos(a)*speed*dt,h[1]+Math.sin(a)*speed*dt+250*dt*dt,1.2+rand(j)*1.4,'#951331');}}}
}
function intro(t){rect(0,0,W,H,'#000');ctx.globalAlpha=1;const grow=.09+.91*ease(clamp(t/.38,0,1));ctx.save();ctx.translate(W/2,156);ctx.scale(grow,grow);text('WARNING',0,-68,111,'#f5141c');text('THE FOLLOWING VIDEO CONTAINS SCENES OF',0,18,25);text('VIOLENCE AND BRUTAL FIGHTS WITH EXPLICIT BLOOD CONTENT.',0,45,25);text('VIEWER DISCRETION IS ADVISED',0,72,25);ctx.restore();ctx.globalAlpha=1;}
function draw(t){t=clamp(t,0,T-1e-6);window.filmTime=t;ctx.reset();ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);if(t<2){intro(t);return;}const s=sceneAt(t);background(s);props(t,s);for(const name of ['green','orange','red','cyan'])actor(name,t);for(const kind of ['sword','knife','mace'])weapon(weaponAt(kind,t));effects(t);if(t>=93.708333)rect(0,0,W,H,'#000');}
const audio=document.querySelector('#audio'),play=document.querySelector('#play'),seek=document.querySelector('#seek'),label=document.querySelector('#time');let playing=false,current=0,startTime=0,raf;const fmt=x=>`${Math.floor(x/60)}:${String(Math.floor(x%60)).padStart(2,'0')}`;
seek.max=T;
function ui(){seek.value=current;label.textContent=`${fmt(current)} / ${fmt(T)}`;}
function tick(now){if(!playing)return;current=Math.min(T,(now-startTime)/1000);draw(current);ui();if(current>=T){playing=false;play.textContent='Reproduzir';audio.pause();return;}raf=requestAnimationFrame(tick);}
play.addEventListener('click',async()=>{if(playing){playing=false;cancelAnimationFrame(raf);audio.pause();play.textContent='Reproduzir';}else{if(current>=T)current=0;audio.currentTime=current;if(audio.getAttribute('src')){try{await audio.play();}catch{}}playing=true;startTime=performance.now()-current*1000;play.textContent='Pausar';raf=requestAnimationFrame(tick);}});seek.addEventListener('input',()=>{current=+seek.value;audio.currentTime=current;startTime=performance.now()-current*1000;draw(current);ui();});
window.film={draw,rigAt:drawingRig,rawRigAt:ElasticRig.at,weaponAt,metrics,canvas,duration:T,version:'authored-rig-4.0',stages:[{start:0,end:2,mode:'intro'},{start:2,end:T,mode:'directed'}]};draw(0);ui();})();
