# Exemplo sintético

Sirva esta pasta por HTTP e abra o player. A cena mostra um rig de código e não
usa mídia da referência. Para conferir, rode `node inspect-template.mjs`.
Para uma nova referência, escreva dados/poses próprios e adicione a trilha
solicitada. Antes de usar `render.mjs` com áudio, configure o arquivo e o `src`
do elemento de áudio. Consulte `../references/workflow.md`.
