/* Authored 2.5D skeleton. Constant anatomical lengths in 3D; orthographic
   foreshortening, named pose keys, planted feet and analytic impact springs. */
(()=>{'use strict';
const D=FILM_DATA,parents=[-1,0,1,1,3,1,5,0,7,0,9],TAU=Math.PI*2,clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function indexAt(v,t){let l=0,h=v.length-1;while(l<h){const m=Math.ceil((l+h)/2);if(v[m].t<=t)l=m;else h=m-1;}return l;}
const mix=(a,b,u)=>a+(b-a)*u,short=(a,b,u)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*u;
function channel(v,t,get){const i=indexAt(v,t),a=v[i],b=v[Math.min(i+1,v.length-1)],dt=b.t-a.t;
 if(dt<=0||a.segment!==b.segment)return get(t<b.t?a:b);
 const u=clamp((t-a.t)/dt,0,1),p=v[Math.max(0,i-1)],q=v[Math.min(v.length-1,i+2)],delta=(get(b)-get(a))/dt;
 const bound=x=>x*delta<=0?0:Math.sign(delta)*Math.min(Math.abs(x),3*Math.abs(delta)),slope=(x,y)=>(get(y)-get(x))/Math.max(.00001,y.t-x.t);
 const m0=p.segment===a.segment?bound((slope(p,a)+delta)/2):delta,m1=q.segment===b.segment?bound((delta+slope(b,q))/2):delta;
 return (2*u**3-3*u*u+1)*get(a)+(u**3-2*u*u+u)*dt*m0+(-2*u**3+3*u*u)*get(b)+(u**3-u*u)*dt*m1;}
const cache={};
for(const [name,keys]of Object.entries(D.tracks)){
 cache[name]=keys.map(k=>{const n=D.poseLibrary[k.pose],profile=D.profiles[name],angles=[0],elevations=[0];
  for(let j=1;j<11;j++){const a=n[parents[j]],b=n[j],x=b[0]-a[0],y=b[1]-a[1],len=Math.hypot(x,y);angles[j]=Math.atan2(y,x);elevations[j]=Math.acos(clamp(len/profile[j],0,1))*(j%2?-1:1);}
  return {...k,angles,elevations};
 });
}
function control(name,t){const v=cache[name],i=indexAt(v,t),a=v[i],b=v[Math.min(i+1,v.length-1)],cut=a.segment!==b.segment,u=cut?0:clamp((t-a.t)/Math.max(.00001,b.t-a.t),0,1),e=Motion.cubicBezier(.3,0,.65,1)(u);
 const head=[0,1].map(k=>channel(v,t,p=>p.head[k])),r=channel(v,t,p=>p.r),angles=a.angles.map((v,j)=>short(v,b.angles[j],e)),elevations=a.elevations.map((v,j)=>mix(v,b.elevations[j],e));
 return {name,t,head,r,angles,elevations,a,b,u:e,cut,pose:a.pose,weaponAngle:short((a.weaponAngle||0)*Math.PI/180,(b.weaponAngle||0)*Math.PI/180,e),weaponLength:mix(a.weaponLength||0,b.weaponLength||0,e),gripFraction:mix(a.gripFraction||.43,b.gripFraction||.43,e)};
}
const impacts=[10.02,10.53,11.1,12.18,40.6,53.42,55.65,57.40,62.0,64.8,68.3,70.9,74.7];
function recoil(t){return impacts.reduce((s,t0)=>{const dt=t-t0;return s+(dt>=0&&dt<.45?Math.exp(-dt*12)*Math.sin(dt*29):0);},0);}
function support(name,t){if(name==='orange')return t<8.2?374:(t<15.04?437:(t<33.33?422:(t<36.75?null:(t<39?438:(t<44?null:(t<53.25?445:null))))));if(name==='red')return t<13?437:(t>=90.083333?510:(48.25<=t&&t<62.083333?451:(63.583333<=t&&t<67.791667?455:null)));if(name==='green')return 30.916667<=t&&t<40.3?432:null;return null;}
const walks={orange:[[8.85,9.85,1],[49,51.2,-1]],red:[[8.25,9.7,-1],[48.7,52.5,-1],[54.45,55.3,-1],[58.6,59.4,1]],green:[[16.4,18.2,-1]]};
function at(name,t){if(!D.intervals[name].some(([a,b])=>a<=t&&t<b))return null;const c=control(name,t),r=c.r,L=D.profiles[name],nodes3=[[0,0,0]],nodes=[[0,0]],projected=[0];
 // Ballistic launch/landing is independent of render fps.
 const airborne=name==='orange'&&12.12<=t&&t<=12.8;
 if(airborne){const start=control(name,12.12).head,end=control(name,12.8).head,dt=.68,u=(t-12.12)/dt,g=1500;c.head=[mix(start[0],end[0],u),mix(start[1],end[1],u)-.5*g*dt*dt*u*(1-u)];}
 const kick=recoil(t);
 for(let j=1;j<11;j++){const parent=parents[j],angle=c.angles[j]+(j===1?kick*.045:0),el=c.elevations[j],d=L[j]*r,z=Math.sin(el)*d,xy=Math.cos(el)*d;
  nodes3[j]=[nodes3[parent][0]+Math.cos(angle)*xy,nodes3[parent][1]+Math.sin(angle)*xy,nodes3[parent][2]+z];nodes[j]=nodes3[j].slice(0,2);projected[j]=xy;}
 const shift=c.head.map((v,k)=>v-nodes[2][k]);for(let j=0;j<11;j++){nodes[j]=nodes[j].map((v,k)=>v+shift[k]);nodes3[j][0]=nodes[j][0];nodes3[j][1]=nodes[j][1];}
 function solveLeg(j,target,pole){
  const distance=Math.hypot(target[0]-nodes[0][0],target[1]-nodes[0][1]),total=projected[j]+projected[j+1];
  // Restore a little depth projection for contact, rather than stretching bones.
  if(distance>total*.9999){const factor=Math.min(1.18,(distance+.01)/Math.max(.01,total));projected[j]=Math.min(L[j]*r,projected[j]*factor);projected[j+1]=Math.min(L[j+1]*r,projected[j+1]*factor);}
  const ik=ElasticGeometry.twoBone(nodes[0],pole,nodes[j+1],target,projected[j],projected[j+1]);nodes[j]=ik.joint;nodes[j+1]=ik.end;
  nodes3[j][2]=nodes3[0][2]+Math.sign(c.elevations[j]||1)*Math.sqrt(Math.max(0,(L[j]*r)**2-projected[j]**2));
  nodes3[j+1][2]=nodes3[j][2]+Math.sign(c.elevations[j+1]||1)*Math.sqrt(Math.max(0,(L[j+1]*r)**2-projected[j+1]**2));
 }
 let floor=airborne?null:support(name,t),walk=walks[name]?.find(([a,b])=>a<=t&&t<b);
 if(walk){const[start,,facing]=walk,freq=2.35;
  for(let leg=0;leg<2;leg++){const phase=(t-start)*freq+leg*.5,cycle=Math.floor(phase),u=phase-cycle,j=leg?9:7,hip=nodes[0];let x,y=floor??nodes[j+1][1];
   if(u<.38){const z=u/.38;x=hip[0]+facing*r*mix(-.82,.82,Motion.cubicBezier(.2,0,.6,1)(z));y-=Math.sin(z*Math.PI)*r*.45;}
   else{const plantedAt=start+(cycle+.38-leg*.5)/freq,pc=control(name,clamp(plantedAt,start,t));x=pc.head[0]+(hip[0]-c.head[0])+facing*r*.82;}
   const pole=[hip[0]+facing*r,hip[1]+r];solveLeg(j,[x,y],pole);
  }
 }else if(floor!==null){for(let leg=0;leg<2;leg++){const j=leg?9:7;if(Math.abs(nodes[j+1][1]-floor)<r*1.25)solveLeg(j,[nodes[j+1][0],floor],nodes[j]);}}
 if(name==='orange'&&((11.55<=t&&t<12.10)||(65<=t&&t<66.7))){
  const other=at('red',t),j=t<13?5:3;let target;
  if(t<13){const b=other.nodes[4],angle=other.control.weaponAngle,len=other.control.weaponLength*other.r,a=[b[0]+Math.cos(angle)*len,b[1]+Math.sin(angle)*len],axis=[b[0]-a[0],b[1]-a[1]],u=clamp(((nodes[j+1][0]-a[0])*axis[0]+(nodes[j+1][1]-a[1])*axis[1])/Math.max(.001,len*len),0,1);target=a.map((v,k)=>v+axis[k]*u);}
  else target=other.nodes[8];
  const ik=ElasticGeometry.twoBone(nodes[1],nodes[j],nodes[j+1],target,projected[j],projected[j+1]);nodes[j]=ik.joint;nodes[j+1]=ik.end;
 }
 // Preserve z while moving projected joints: IK never increases bone lengths.
 for(let j=0;j<11;j++){nodes3[j][0]=nodes[j][0];nodes3[j][1]=nodes[j][1];}
 return {name,t,nodes,nodes3,r,shape:[r,r,0],profile:L,projected,pose:c.pose,quality:1,partial:false,control:c,ground:floor,walk:Boolean(walk)};
}
window.ElasticRig={at,indexAt,parents,control,cache,recoil};
})();
