/* Bounded limb curves and rigid two-bone constraints, independent of the frame. */
(()=>{'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(v,s)=>v.map(x=>x*s),length=v=>Math.hypot(...v),unit=v=>mul(v,1/Math.max(1e-9,length(v)));
function curveControls(a,b,c){
 const ab=sub(b,a),bc=sub(c,b),l1=length(ab),l2=length(bc),u=unit(ab),v=unit(bc),dot=clamp(u[0]*v[0]+u[1]*v[1],-1,1),tangent=unit(add(u,v));
 const handle=Math.min(l1,l2)*.22*Math.sqrt(Math.max(0,(1+dot)/2));
 return [[a,add(a,mul(u,l1/3)),sub(b,mul(tangent,handle)),b],[b,add(b,mul(tangent,handle)),sub(c,mul(v,l2/3)),c]];
}
function twoBone(start,joint,end,target,l1,l2){
 const delta=sub(target,start),d0=length(delta),lo=Math.abs(l1-l2)+1e-5,hi=(l1+l2)*.9999,d=clamp(d0,lo,hi),fallback=length(sub(end,start))>1e-6?sub(end,start):(length(sub(joint,start))>1e-6?sub(joint,start):[1,0]),direction=d0>1e-6?unit(delta):unit(fallback),base=Math.atan2(direction[1],direction[0]);
 const pole=sub(joint,start),cross=direction[0]*pole[1]-direction[1]*pole[0],side=cross<0?-1:1;
 const alpha=Math.acos(clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1)),angle=base+side*alpha;
 return {joint:add(start,[Math.cos(angle)*l1,Math.sin(angle)*l1]),end:add(start,mul(direction,d)),reached:d0>=lo&&d0<=hi};
}
window.ElasticGeometry={curveControls,twoBone};})();
