# reference-animation V4

Esta revisão mantém o método de personagens e movimentos criados por código:
rigs, keyframes, contatos e dinâmica. Não inclui vetorização como substituto.

Anexe o ZIP ou `SKILL.md` em um novo chat junto da referência e peça para seguir
as instruções. Isso permite ler a skill como instrução; registro persistente
depende do aplicativo. O template é sintético e não contém a referência real.
