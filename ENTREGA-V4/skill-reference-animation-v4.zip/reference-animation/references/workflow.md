# Fluxo

1. Inspecione a referência e anote ações/câmera/poses difíceis.
2. Defina geometria própria, perfis anatômicos e poses com articulações nomeadas.
3. Escreva keyframes e contatos. Use Motion para easing e funções próprias para IK
   e dinâmica. Dados de posição/escala são calibração; contornos traçados do vídeo
   não são uma alternativa automática a este método.
4. Renderize prévias representativas e compare com a referência.
5. Verifique integridade do rig, contato da arma, impacto, pé plantado, soltura,
   cortes e final. Adapte testes à cena; não preserve fixtures de outro vídeo.
6. Exporte e valide MP4 e áudio.

O template é uma demonstração sintética de um personagem. Não contém o vídeo,
trilha, contornos nem a coreografia da referência real. Para abrir, sirva a pasta
por HTTP. Para inspecionar, `node inspect-template.mjs`. O renderer usa Chromium
em `/usr/bin/chromium` e FFmpeg. Adapte a biblioteca de poses e o player ao seu
vídeo; não confunda o exemplo pequeno com o resultado esperado para nova tarefa.
